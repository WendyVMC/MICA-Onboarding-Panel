"""Empaqueta solo una lista blanca; escanea secretos y deja hashes verificables."""
from pathlib import Path
import json,hashlib,shutil,re,zipfile,csv
P=Path(__file__).resolve().parents[1];D=P/'entregables/Miranda_Wendy_AI_Tools_ProyectoFinal';
if D.exists():shutil.rmtree(D)
D.mkdir(parents=True,exist_ok=True)
private=json.loads((P/'privado/telegram_usuario_autorizado.json').read_text())
private_ids={str(private[k]) for k in ['usuario_id','chat_id'] if private.get(k)}
black={'usuario_id','user_id','chat_id','first_name','last_name','username','openai-platform','defaultHeaders'}
def clean_data(x):
 if isinstance(x,dict):return {k:clean_data(v) for k,v in x.items() if k not in black}
 if isinstance(x,list):return [clean_data(v) for v in x]
 if isinstance(x,str):
  for v in private_ids:x=x.replace(v,'REEMPLAZAR_ID_AUTORIZADO')
 return x
def clean_workflow(w):
 w=clean_data(w)
 for k in ['id','versionId','activeVersionId','versionCounter','meta','createdAt','updatedAt','shared','tags']:w.pop(k,None)
 w['active']=False;w['pinData']={}
 for n in w.get('nodes',[]):
  creds=n.pop('credentials',{})
  managed={k:{'id':'REEMPLAZAR_GATEWAY','name':'Gateway credits','__aiGatewayManaged':True} for k,v in creds.items() if v.get('__aiGatewayManaged')}
  if managed:n['credentials']=managed
 return w
def copytext(src,relative=None):
 rel=Path(relative or src.relative_to(P));dst=D/rel;dst.parent.mkdir(parents=True,exist_ok=True)
 text=src.read_text()
 for v in private_ids:text=text.replace(v,'REEMPLAZAR_ID_AUTORIZADO')
 if src.suffix=='.json':
  try:
   obj=json.loads(text);obj=clean_workflow(obj) if isinstance(obj,dict) and 'nodes' in obj and 'connections' in obj else clean_data(obj);text=json.dumps(obj,ensure_ascii=False,indent=2)+'\n'
  except json.JSONDecodeError:pass
 dst.write_text(text)

for folder in ['agentes','datos','skills','loops','runtime','tests','tools','voz','costos','n8n']:
 for f in (P/folder).rglob('*'):
  if f.is_file() and f.suffix.lower() in ['.md','.json','.js','.py','.csv','.m','.txt'] and '__pycache__' not in str(f):copytext(f)
for f in ['index.html','estilos.css','app.js','metricas.js','datos.json']:copytext(P/'panel'/f)
for f in ['costos.csv','pruebas.csv','.env.example']:copytext(P/f)
for f in ['MANUAL_REPRODUCCION.md','INFORME_FINAL.md','DECLARACION_IA_Y_FUENTES.md','CONTROL_CALIDAD_FINAL.md','GUION_VIDEO_Y_DEFENSA.md','CHECKLIST_ENTREGA.md','AUTOEVALUACION_SKILLS_LOOPS.md','ESTADO_VIGENTE.md','ENSAYO_CLASE_004.md','AUDITORIA_FINAL_2026-11-26.md','INDICE_RUBRICA.md']:copytext(P/'docs'/f)
for f in (P/'evidencias').glob('*.json'):
 # Evitar instantáneas remotas redundantes, que hacen crecer el ZIP sin nueva evidencia.
 if f.name.startswith(('panel_archivos_','panel_commit_')):continue
 copytext(f)
copytext(P/'.github/workflows/pages.yml')
main=clean_workflow(json.loads((P/'privado/flujo_cierre_ensayo004.json').read_text()))
(D/'n8n/MICA_Principal_Entrega.json').write_text(json.dumps(main,ensure_ascii=False,indent=2)+'\n')
voice=clean_workflow(json.loads((P/'n8n/MICA_Voz_Consolidado.json').read_text()))
(D/'n8n/MICA_Voz_Entrega.json').write_text(json.dumps(voice,ensure_ascii=False,indent=2)+'\n')
assert 'const HABILITAR_IA=false;' in next(n for n in main['nodes'] if n['name']=='Enrutar y deduplicar')['parameters']['jsCode']
for name in ['panel_tres_casos_publicado.png','voz_consulta_exitosa.png','voz_revision_exitosa.png','actions_bloqueo_real.png','actions_recuperacion_real.png','skills_loops_n8n_exitoso.png','telegram_pruebas_sanitizado.png','qa_final_390.png','qa_final_1366.png','ensayo_clase_004_ejecucion.png','ensayo_clase_004_consulta_autenticada.png']:
 src=P/'entregables'/name
 if src.exists():(D/'evidencias/capturas').mkdir(parents=True,exist_ok=True);shutil.copy2(src,D/'evidencias/capturas'/name)
for folder,files in [('output/pdf',['MICA_Informe_Final.pdf']),('output/video',['MICA_Respaldo.mov','video_metadata.json'])]:
 for name in files:
  src=P/folder/name
  if src.exists():(D/folder).mkdir(parents=True,exist_ok=True);shutil.copy2(src,D/folder/name)

readme='''# MICA - Proyecto final individual de AI Tools

Wendy Miranda · entrega académica · 26/11/2026 · rama main; mediciones operativas hasta el 21/11/2026.

## Abrir primero

- Índice por rúbrica: [docs/INDICE_RUBRICA.md](docs/INDICE_RUBRICA.md).

- Panel público: https://wendyvmc.github.io/MICA-Onboarding-Panel/
- Informe: [output/pdf/MICA_Informe_Final.pdf](output/pdf/MICA_Informe_Final.pdf), 10 páginas.
- Manual reproducible: [docs/MANUAL_REPRODUCCION.md](docs/MANUAL_REPRODUCCION.md).
- Registro: [costos.csv](costos.csv), [costos/RESUMEN_Y_METODO.md](costos/RESUMEN_Y_METODO.md) y [costos/escenarios.csv](costos/escenarios.csv).
- Matriz obligatoria: [pruebas.csv](pruebas.csv). Revisa la columna tipo_evidencia: hay pruebas reales, mixtas y simulaciones controladas.
- Respaldo: [output/video/MICA_Respaldo.mov](output/video/MICA_Respaldo.mov). Recorrido narrado de evidencias, no grabación continua de nuevas ejecuciones. Voz local de sistema, no clonación ni nueva llamada ElevenLabs.

## Resultado y alcance

Cuatro casos ficticios completos: Tecnología remota (8 actividades en piloto y 8 en ensayo), Comercial híbrido (9) y Administración presencial (8). Cinco roles trazables, dos skills y dos loops integrados, aprobaciones humanas explícitas, registro privado y publicación sanitizada. Una conversación real en español usó ambas herramientas del mismo folio. No hay operaciones reales de empleo, nómina ni accesos.

El KPI de completitud incluye una solicitud incompleta real: cuatro completas de cinco recibidas, 80%. Aprobación inicial 4/4; preparación media 0.082243 h/caso, que incluye esperas. Tres casos tienen marcas directas y el legado conserva reconstrucciones auditadas. No se afirma representatividad, ahorro ni ROI.

Se midieron 42 llamadas Gateway, con fallos y recuperación conservados; la voz consumió 831 créditos. El costo calculado Gateway es USD 0.00617610. El cargo final y los tokens reales del desarrollo no están disponibles; se incluye una sensibilidad reproducible separada en costos/DESARROLLO_ESTIMACION.md. La usuaria reportó una recarga de USD 5, separada del consumo. Los escenarios son proyecciones con cuotas y supuestos, no una contratación.

## Reproducir sin llamadas de pago

Node 22 recomendado; también probado con Node 24.22.1. Python 3.9+ para exportación. Desde raíz:

```sh
node tests/panel.test.js
node tests/voz_preflight.test.js
node tests/guardrails_entrega.test.js
node tests/kpi_registro.test.js
node tests/skills_loops.test.js
python3 -m http.server 8765 --bind 127.0.0.1 --directory panel
```

Abrir http://127.0.0.1:8765/; parar con Ctrl+C. Estos tests usan datos ficticios y no llaman APIs. La voz del agente publicado solo admite su host autorizado. La prueba de permisos denegados/servicio caído es una simulación del manejador real; no se presenta como un incidente externo real.

## Importar y operar

Importar `n8n/MICA_Principal_Entrega.json` y `n8n/MICA_Voz_Entrega.json`. Están inactivos y sin secretos/pinData/IDs de autorización personales. Crear tabla y volver a vincular Telegram, Gateway y Header Auth en los nodos descritos en el manual. Reemplazar `REEMPLAZAR_ID_AUTORIZADO` por el ID propio, verificado de forma privada. Un solo receptor de Telegram por bot.

El flujo se entrega con `HABILITAR_IA=false`: registrar y consultar no llama modelos. Para una ejecución nueva, registrar `/nuevo`, obtener folio, permitir solo ese folio y habilitar IA con presupuesto aprobado; publicar y enviar `/generar FOLIO 0`. Revisar la versión 2 y aprobar o rechazar explícitamente. Desactivar IA al terminar. No regenerar casos cerrados. El manual detalla fecha futura, resultado esperado, límites, parada y diagnóstico.

La tabla de esta entrega es una instantánea, no una conexión de datos en vivo. Actualizar desde CSV privado con el exportador de lista blanca, hacer commit y esperar Actions. Pages no ejecuta n8n. Las credenciales y fuentes privadas de auditoría no se entregan: para repetir la exportación se usa un CSV propio, no se inventan datos faltantes.

## Enlaces de evidencia

- Bot del proyecto: https://t.me/mica_wvmc_onboarding_bot . El acceso operativo requiere autorización privada; solicitarlo a Wendy por el canal del curso, sin enviar tokens.
- Actions correcto: https://github.com/WendyVMC/MICA-Onboarding-Panel/actions/runs/44667092748
- Actions bloqueado: https://github.com/WendyVMC/MICA-Onboarding-Panel/actions/runs/44666974987
- Actualización tres casos: https://github.com/WendyVMC/MICA-Onboarding-Panel/actions/runs/44981577796
- Índice: [evidencias/INDICE.md](evidencias/INDICE.md).

`MANIFEST_SHA256.json` identifica el árbol de entrega. La rama y el commit final se indican en el recibo de publicación externo; no se incrusta un hash autorreferencial dentro del propio archivo. El repositorio publica este mismo archivo de entrega; el código completo organizado está dentro del ZIP y el panel está además desplegado por separado. La carpeta `privado/`, tokens, claves, exportaciones completas de conversaciones y audios personales están excluidos.

## Límites, autoría y defensa

IA desactivada tras los ensayos; límites de voz 60 s/tres llamadas diarias y una simultánea. La vigencia se comprueba al intentar una acción; deduplicación secuencial sin garantía concurrente. Se necesita n8n disponible y cuotas vigentes en la evaluación. No se cambia de plan ni recarga automáticamente.

Revisar [docs/DECLARACION_IA_Y_FUENTES.md](docs/DECLARACION_IA_Y_FUENTES.md), fuentes y licencias de terceros. Datos ficticios propios para evaluación; no se declara una licencia abierta no elegida. La estudiante debe revisar el informe y realizar su defensa individual, máximo 12 minutos. El video no sustituye acceso funcional ni una explicación propia.
'''
readme+='\n\n## Cortes y cierre\n\nLeer docs/ESTADO_VIGENTE.md. El video es respaldo histórico de tres casos; informe y panel consolidan cuatro. La conversación real histórica consultó el 069; el único folio actual documentado es el 082, cuya voz se reserva para presentación. Los estados y saldos del servicio son observaciones históricas, no certificación actual. docs/AUTOEVALUACION_SKILLS_LOOPS.md contiene las puntuaciones por cinco aspectos. La auditoría del 26/11 documenta el estado previo a esta consolidación; el estado vigente aclara las correcciones.\n'
(D/'README.md').write_text(readme)
(D/'.gitignore').write_text('.env\n.env.*\n!.env.example\nprivado/\nnode_modules/\n__pycache__/\n*.pyc\ntmp/\n_site/\npanel/_qa/\n')
index=['# Índice de evidencias\n','Los JSON describen origen y límites. Las capturas complementan, no sustituyen logs ni acceso. No se atribuyen como reales las simulaciones.\n']
for f in sorted((D/'evidencias').glob('*.json')):index.append(f'- [{f.name}]({f.name})')
index+=['\n## Capturas\n']+[f'- [{f.name}](capturas/{f.name})' for f in sorted((D/'evidencias/capturas').glob('*.png'))]
(D/'evidencias/INDICE.md').write_text('\n'.join(index)+'\n')
patterns=[re.compile(r'\b\d{8,12}:[A-Za-z0-9_-]{25,}\b'),re.compile(r'\bsk-[A-Za-z0-9_-]{20,}\b')]
files=[]
for f in sorted(D.rglob('*')):
 if not f.is_file() or f.name=='MANIFEST_SHA256.json':continue
 if f.suffix.lower() in ['.json','.js','.md','.py','.csv','.yml','.html','.m','.txt'] or f.name=='.env.example':
  t=f.read_text()
  assert not any(v in t for v in private_ids),f'ID privado en {f}'
  assert not any(p.search(t) for p in patterns),f'Posible secreto en {f}'
 files.append({'ruta':str(f.relative_to(D)),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
assert not (D/'privado').exists()
manifest={'version':'entrega-v2-20261126','fecha':'2026-11-26','archivos':files,'reglas':'No incluye su propio hash. Fuentes privadas y credenciales excluidas. Las simulaciones se identifican por su tipo de evidencia.'}
(D/'MANIFEST_SHA256.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
zip_path=P/'entregables/Miranda_Wendy_AI_Tools_ProyectoFinal.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(D.rglob('*')):
  if f.is_file():z.write(f,Path(D.name)/f.relative_to(D))
print(json.dumps({'carpeta':str(D),'zip':str(zip_path),'archivos':len(files)+1,'bytes_zip':zip_path.stat().st_size,'sha256_zip':hashlib.sha256(zip_path.read_bytes()).hexdigest()},ensure_ascii=False))
