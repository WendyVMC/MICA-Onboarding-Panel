"""Valida datos de referencia y fixtures localmente, sin APIs."""
import json
from datetime import date, timedelta
from pathlib import Path
from itertools import product

OUT=Path(__file__).resolve().parents[1]/'datos'/'bases_mica_v1'
def load(name): return json.loads((OUT/name).read_text(encoding='utf-8'))
cat=load('catalogos.json')
acts=load('actividades.json')['registros']
owners=load('responsables.json')['registros']
rules=load('politicas.json')['registros']
fixtures=load('casos_prueba.json')['registros']
deps={x['departamento_id'] for x in cat['departamentos']}
jobs={x['puesto_id']:x for x in cat['puestos']}
resp={x['responsable_id']:x for x in owners}
pol={x['regla_id'] for x in rules}
checks=[]
def check(label,condition):
    if not condition: raise ValueError(label)
    checks.append(label)
for rows,key in [(acts,'actividad_id'),(owners,'responsable_id'),(rules,'regla_id'),(cat['puestos'],'puesto_id'),(cat['departamentos'],'departamento_id'),(fixtures,'prueba_id')]:
    check('IDs únicos: '+key,len({r[key] for r in rows})==len(rows))
check('Puestos vinculados a departamentos existentes',all(x['departamento_id'] in deps for x in jobs.values()))
for a in acts:
    check(a['actividad_id']+' referencias, ámbito, fechas y modalidad',
        a['regla_id'] in pol and a['fuente_version']==cat['version'] and
        a['responsable_id'] in resp and resp[a['responsable_id']]['activo'] and
        (a['departamento_id'] is None or a['departamento_id'] in deps) and
        (a['puesto_id'] is None or a['puesto_id'] in jobs and jobs[a['puesto_id']]['departamento_id']==a['departamento_id']) and
        resp[a['responsable_id']]['departamento_id'] in ['TRANSVERSAL',a['departamento_id']] and
        isinstance(a['desfase_dias'],int) and -3<=a['desfase_dias']<=6 and
        a['fase']==('preingreso' if a['desfase_dias']<0 else 'primer_dia' if a['desfase_dias']==0 else 'primera_semana') and
        bool(a['modalidades']) and set(a['modalidades'])<=set(cat['modalidades']))

def selected(e):
    return [a for a in acts if a['departamento_id'] in (None,e['departamento_id']) and a['puesto_id'] in (None,e['puesto_id']) and e['modalidad'] in a['modalidades']]

required={'departamento_id','puesto_id','fecha_ingreso','modalidad','tipo_incorporacion','responsable_rh_id'}
def validate(e):
    if set(e)-required: return 'rechazar'
    if required-set(e) or any(e.get(k) is None or e.get(k)=='' for k in required): return 'solicitar_aclaracion'
    if any(not isinstance(e[k],str) for k in required): return 'rechazar'
    try:
        if date.fromisoformat(e['fecha_ingreso']).isoformat()!=e['fecha_ingreso']: return 'rechazar'
    except ValueError: return 'rechazar'
    if e['departamento_id'] not in deps or e['puesto_id'] not in jobs or jobs[e['puesto_id']]['departamento_id']!=e['departamento_id']: return 'rechazar'
    if e['modalidad'] not in cat['modalidades'] or e['tipo_incorporacion'] not in cat['tipos_incorporacion']: return 'rechazar'
    r=resp.get(e['responsable_rh_id'])
    if not r or not r['activo'] or r['rol']!='Coordinación People & Culture': return 'rechazar'
    return 'valido'

coverage=[]
for j,m in product(jobs.values(),cat['modalidades']):
    chosen=selected({'departamento_id':j['departamento_id'],'puesto_id':j['puesto_id'],'modalidad':m})
    ids={a['actividad_id'] for a in chosen}
    expected={f'ACT-G{i:02}' for i in range(1,6)}|{f"ACT-{j['departamento_id'][4:]}-01",f"ACT-{j['puesto_id']}"}
    if m in ['remota','hibrida']: expected.add('ACT-G06')
    if m in ['presencial','hibrida']: expected.add('ACT-G07')
    check(j['puesto_id']+'/'+m+' cobertura exacta',ids==expected and len(ids)==len(chosen))
    check(j['puesto_id']+'/'+m+' tres fases', {a['fase'] for a in chosen}=={'preingreso','primer_dia','primera_semana'})
    coverage.append({'puesto_id':j['puesto_id'],'modalidad':m,'actividades':len(chosen)})

results=[];examples=[]
for f in fixtures:
    got=validate(f['entrada'])
    check(f['prueba_id']+' expectativa de validación',got==f['esperado']['estado_validacion'])
    results.append({'prueba_id':f['prueba_id'],'esperado':f['esperado']['estado_validacion'],'obtenido':got,'aprobado_local':True})
    if got=='valido':
        e=f['entrada'];day=date.fromisoformat(e['fecha_ingreso'])
        examples.append({'prueba_id':f['prueba_id'],'naturaleza':'ESPERADO_CALCULADO_NO_EJECUTADO_POR_AGENTES',
            'entrada':e,'estado':'ejemplo_sin_aprobacion','actividades':[{**a,'fecha':(day+timedelta(days=a['desfase_dias'])).isoformat()} for a in selected(e)]})
for f in ['politicas_onboarding.md','checklist_actividades.md','guia_bienvenida.md','diccionario_datos.md','LEEME.md']:
    check('Documento no vacío: '+f,len((OUT/f).read_text(encoding='utf-8'))>100)
for r in rules: check('Referencia documental: '+r['regla_id'],r['regla_id'] in (OUT/'politicas_onboarding.md').read_text(encoding='utf-8'))
for a in acts: check('Actividad documental: '+a['actividad_id'],a['actividad_id'] in (OUT/'checklist_actividades.md').read_text(encoding='utf-8'))
report={'fecha':'2026-11-04','version':'1.0.0','alcance':'Integridad local de fuentes y fixtures; NO prueba de agentes, guardrails del servidor o integraciones.',
        'resultado':'APROBADO_LOCAL','total_controles':len(checks),'controles':checks,
        'conteos':{'departamentos':len(deps),'puestos':len(jobs),'responsables':len(owners),'politicas':len(rules),'actividades':len(acts),'casos_prueba':len(fixtures)},
        'cobertura_puesto_modalidad':coverage,'resultados_fixtures':results,
        'pendiente':['Revisión humana de las reglas sintéticas','Configuración e implementación','Matriz P01–P14 con evidencia funcional']}
(OUT/'validacion_local.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(OUT/'ejemplos_esperados.json').write_text(json.dumps({'version':'1.0.0','ejemplos':examples},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'resultado':report['resultado'],'controles':len(checks),'conteos':report['conteos'],'combinaciones_cubiertas':len(coverage)},ensure_ascii=False))
