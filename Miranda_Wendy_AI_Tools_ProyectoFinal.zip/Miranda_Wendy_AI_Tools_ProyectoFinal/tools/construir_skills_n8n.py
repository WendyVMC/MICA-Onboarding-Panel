"""Lee SKILL.md y compila adaptador embebido para n8n, sin APIs."""
from pathlib import Path
import json,hashlib,re,uuid
P=Path(__file__).resolve().parents[1]
nombres=['mica-preparar-onboarding','mica-verificar-propuesta']
skills={n:{'texto':(P/'skills'/n/'SKILL.md').read_text(),'sha256':hashlib.sha256((P/'skills'/n/'SKILL.md').read_bytes()).hexdigest()}for n in nombres}
helper=(P/'agentes/herramientas_mica.js').read_text().split("if(typeof module!==")[0]
adapt=(P/'runtime/skills_adapter.js').read_text();adapt=adapt[adapt.index('function validarContexto'):adapt.index('module.exports=')]
load='''function cargarSkill(nombre){
 const s=SKILLS[nombre];if(!s)throw Error('SKILL_NO_PERMITIDO');const texto=s.texto;
 const bloque=texto.match(/```mica-policy\\s*\\n([\\s\\S]*?)\\n```/);if(!bloque)throw Error('SKILL_SIN_POLITICA');
 const politica=JSON.parse(bloque[1]);if(politica.version!=='1.0.0'||politica.modo!=='SIMULADO'||politica.fuente_version!=='1.0.0'||politica.aprobacion_humana_requerida!==true)throw Error('POLITICA_SKILL_INVALIDA');
 return {nombre,texto,politica,carga:{skill:nombre,version:politica.version,archivo:'skills/'+nombre+'/SKILL.md',sha256:s.sha256,mecanismo:'SKILL_md_leido_al_compilar_y_politica_aplicada_en_n8n'}};
}
'''
loops=(P/'runtime/loops.js').read_text();loops=loops[loops.index('function loopSeguridad'):loops.index('module.exports=')]
bundle='const SKILLS='+json.dumps(skills,ensure_ascii=False)+';\n'+helper+'\nconst H={validarSolicitud,calcularPlan,equivalente};\nconst performance={now:()=>Date.now()};\n// Huella no criptográfica de propuesta; SHA-256 de SKILL.md calculado al compilar.\nconst hash=x=>{let h=2166136261;for(const c of JSON.stringify(x)){h^=c.charCodeAt(0);h=Math.imul(h,16777619);}return "fnv1a32:"+(h>>>0).toString(16);};\n'+load+adapt+loops
(P/'runtime/n8n_skills_bundle.js').write_text(bundle+'\n')
bases={k:json.loads((P/'datos/bases_mica_v1'/f'{k}.json').read_text())for k in ['catalogos','actividades','politicas','responsables']}
def ctx(id,dep,puesto,modalidad):return {'caso_id':id,'canal':'prueba_n8n_sin_IA','usuario_seudonimo':'RH-PRUEBA','usuario_autorizado':True,'objetivo':'Validar skills y loops del onboarding simulado','modo':'SIMULADO','fecha_recepcion_local':'2026-11-16','limite_costo_usd':0,'datos':{'departamento_id':dep,'puesto_id':puesto,'fecha_ingreso':'2026-12-01','modalidad':modalidad,'tipo_incorporacion':'nuevo_ingreso','responsable_rh_id':'RH-01'},'bases':bases}
casos=[ctx('MICA-N8N-SKILL-001','DEP-TEC','P-TEC-01','remota'),ctx('MICA-N8N-SKILL-002','DEP-COM','P-COM-02','hibrida')]
code=bundle+'''
const casos=$input.all().map(x=>x.json);const resultados=[];
for(let i=0;i<casos.length;i++){
 const c=casos[i];let propuesta_inicial;
 if(i===0){propuesta_inicial=ejecutarNegocio(c).resultado;propuesta_inicial.actividades=propuesta_inicial.actividades.filter(a=>a.actividad_id!=='ACT-G04');}
 const r=loopCalidad(c,{propuesta_inicial});
 const bloqueado=loopSeguridad(c,[{accion:'preparar_plan',reserva_usd:0.02,llamadas_reservadas:2,ejecutar:()=>{throw Error('NO_DEBE_EJECUTARSE')}}]);
 if(r.estado!=='pendiente_aprobacion'||bloqueado.estado!=='presupuesto_agotado')throw Error('PRUEBA_SKILLS_LOOP_FALLIDA');
 resultados.push({json:{...r,bloqueo_presupuesto:bloqueado,tipo_evidencia:'prueba_n8n_determinista_sin_modelos',fallo_V1:i===0?'omision_deliberada_ACT-G04':'no_inyectado',advertencia:'No es caso completo de cuatro agentes ni prueba Telegram. No altera registros privados.'}});
}
return resultados;
'''
nodes=[{'id':str(uuid.uuid4()),'name':'Inicio controlado sin IA','type':'n8n-nodes-base.manualTrigger','typeVersion':1,'position':[0,0],'parameters':{}},{'id':str(uuid.uuid4()),'name':'Dos casos sinteticos','type':'n8n-nodes-base.code','typeVersion':2,'position':[240,0],'parameters':{'jsCode':'return '+json.dumps([{'json':c}for c in casos],ensure_ascii=False)+';'}},{'id':str(uuid.uuid4()),'name':'Cargar skills y ejecutar loops','type':'n8n-nodes-base.code','typeVersion':2,'position':[480,0],'parameters':{'jsCode':code}}]
conn={nodes[i]['name']:{'main':[[{'node':nodes[i+1]['name'],'type':'main','index':0}]]}for i in range(2)}
w={'name':'MICA - Prueba skills y loops sin IA','nodes':nodes,'connections':conn,'active':False,'settings':{'executionOrder':'v1','timezone':'America/Mexico_City','executionTimeout':30},'pinData':{}}
(P/'n8n/mica_skills_loops_prueba.json').write_text(json.dumps(w,ensure_ascii=False,indent=2)+'\n')
print('Adaptador y workflow manual preparados; sin modelos, credenciales, webhook ni escritura en tablas.')
