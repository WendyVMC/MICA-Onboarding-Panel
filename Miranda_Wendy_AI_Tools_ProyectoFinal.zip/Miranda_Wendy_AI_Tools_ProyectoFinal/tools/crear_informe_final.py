"""Informe de diez páginas, con cifras de archivos de evidencia y sin APIs."""
from pathlib import Path
import json,statistics,datetime,html
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,PageBreak,Flowable,KeepTogether
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.pagesizes import A4
P=Path(__file__).resolve().parents[1]
O=P/'output/pdf';O.mkdir(parents=True,exist_ok=True)
def read(f):return json.loads((P/f).read_text())
d=read('panel/datos.json');cost=read('costos/resumen_auditable.json');sc=read('costos/escenarios.json')
fontdir=Path('/System/Library/Fonts/Supplemental')
if (fontdir/'Arial.ttf').exists():
 pdfmetrics.registerFont(TTFont('Mica',str(fontdir/'Arial.ttf')));pdfmetrics.registerFont(TTFont('MicaBold',str(fontdir/'Arial Bold.ttf')))
else:
 from reportlab.pdfbase.pdfmetrics import registerFontFamily
 pdfmetrics.registerFontFamily('Mica',normal='Helvetica',bold='Helvetica-Bold');pdfmetrics.registerFontFamily('MicaBold',normal='Helvetica-Bold')
FONT='Mica' if (fontdir/'Arial.ttf').exists() else 'Helvetica';BOLD='MicaBold' if FONT=='Mica' else 'Helvetica-Bold'
INK=colors.HexColor('#302B38');PURPLE=colors.HexColor('#765782');PINK=colors.HexColor('#F6B6C8');LAV=colors.HexColor('#CDB4DB');BLUE=colors.HexColor('#A9D6E5');MINT=colors.HexColor('#BDE0C4');CREAM=colors.HexColor('#FFF9F0')
styles={
 'body':ParagraphStyle('body',fontName=FONT,fontSize=11,leading=15.2,textColor=INK,spaceAfter=9),
 'small':ParagraphStyle('small',fontName=FONT,fontSize=9.2,leading=12.3,textColor=INK,spaceAfter=7),
 'h1':ParagraphStyle('h1',fontName=BOLD,fontSize=23,leading=27,textColor=INK,spaceAfter=16),
 'h2':ParagraphStyle('h2',fontName=BOLD,fontSize=12.7,leading=16,textColor=PURPLE,spaceBefore=9,spaceAfter=8),
 'lead':ParagraphStyle('lead',fontName=FONT,fontSize=12.2,leading=17,textColor=INK,spaceAfter=14),
 'cell':ParagraphStyle('cell',fontName=FONT,fontSize=9,leading=12,textColor=INK),
 'head':ParagraphStyle('head',fontName=BOLD,fontSize=9,leading=12,textColor=INK),
 'ref':ParagraphStyle('ref',fontName=FONT,fontSize=8.1,leading=10.4,textColor=INK,spaceAfter=5)
}
story=[];md=[]
def par(t,style='body'):story.append(Paragraph(t,styles[style]));md.append(t.replace('<b>','**').replace('</b>','**'))
def heading(t):par(t,'h2');md.append('')
def page(num,title,lead=None):
 if num>1:story.append(PageBreak())
 md.append('\n\n---\n\n# '+str(num)+'. '+title+'\n');par(title,'h1')
 if lead:par(lead,'lead')
def table(headers,rows,widths):
 data=[[Paragraph(str(x),styles['head']) for x in headers]]+[[Paragraph(html.escape(str(x)).replace('\n','<br/>'),styles['cell']) for x in row] for row in rows]
 t=Table(data,colWidths=widths,hAlign='LEFT',repeatRows=1)
 t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),LAV),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#F6F3F7')]),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),8),('RIGHTPADDING',(0,0),(-1,-1),8),('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7),('LINEBELOW',(0,0),(-1,0),.6,PURPLE)]));story.append(t);story.append(Spacer(1,10))
 md.append('| '+' | '.join(headers)+' |\n|'+'---|'*len(headers));md.extend('| '+' | '.join(map(str,r))+' |' for r in rows)
def notice(t):
 z=Table([[Paragraph(t,styles['body'])]],colWidths=[499]);z.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,-1),CREAM),('BOX',(0,0),(-1,-1),.7,LAV),('TOPPADDING',(0,0),(-1,-1),12),('BOTTOMPADDING',(0,0),(-1,-1),5),('LEFTPADDING',(0,0),(-1,-1),12),('RIGHTPADDING',(0,0),(-1,-1),12)]));story.append(z);story.append(Spacer(1,10));md.append('> '+t)
class Architecture(Flowable):
 def __init__(self):Flowable.__init__(self);self.width=499;self.height=218
 def draw(self):
  c=self.canv
  rows=[(['Telegram','Entrada y validación','Orquestador'],[BLUE,LAV,MINT]),(['A1: recepción','A2: fuentes','A3: planificación','A4: revisión'],[BLUE,BLUE,PINK,MINT]),(['Propuesta','Aprobación humana','Tabla privada'],[PINK,LAV,MINT]),(['CSV sanitizado','Actions valida','Pages y voz'],[MINT,LAV,BLUE])]
  for ri,(labels,cs) in enumerate(rows):
   y=176-ri*53;gap=12;w=(499-gap*(len(labels)-1))/len(labels)
   for j,(lab,col) in enumerate(zip(labels,cs)):
    x=j*(w+gap);c.setFillColor(col);c.roundRect(x,y,w,34,7,fill=1,stroke=0);c.setFillColor(INK);c.setFont(BOLD,8.7);c.drawCentredString(x+w/2,y+13,lab)
    if j<len(labels)-1:c.setStrokeColor(PURPLE);c.line(x+w+1,y+17,x+w+gap-1,y+17)
   if ri<3:c.setStrokeColor(PURPLE);c.line(249,y-2,249,y-16)

page(1,'MICA\nAsistente de onboarding','Informe técnico y empresarial - Proyecto final individual de AI Tools')
par('<b>Wendy Miranda</b> · People &amp; Culture · 21 de noviembre de 2026','lead')
heading('Problema y decisión')
par('MICA es una empresa ficticia. Su proceso de incorporación necesita convertir una solicitud breve en un plan coherente con el puesto, la modalidad y la fecha de ingreso. La solución apoya a Recursos Humanos para revisar qué actividades deben proponerse, cuándo corresponden y quién es responsable. La decisión final es humana: aprobar o rechazar una propuesta concreta y su versión.')
par('El alcance empieza con el registro de un nuevo ingreso y termina con un plan revisado y un registro exclusivamente simulado. No se automatizan contratación, nómina, firma, compras, mensajes a terceros ni accesos reales. La voz permite consultar el mismo registro y solicitar una revisión humana; no sustituye a los especialistas ni autoriza el plan.')
table(['Resultado del piloto','Evidencia'],[['3 casos completos','Tecnología remota, Comercial híbrido y Administración presencial'],['25 actividades propuestas','8 + 9 + 8; ninguna se presenta como realizada'],['Voz real en el sitio','Consulta y revisión exitosas antes del límite de duración'],['Control y publicación','Aprobaciones por caso/versión; Actions bloqueó una falla y publicó su corrección']],[177,322])
notice('Las integraciones y los consumos son reales; las operaciones empresariales y los datos son ficticios. El primer caso requirió recuperación manual. Los resultados de tres pruebas no demuestran ahorro, representatividad ni viabilidad de operación a escala.')
par('La construcción, las pruebas y la documentación se apoyaron en IA. La estudiante configuró sus cuentas, introdujo secretos en almacenes privados, probó la voz y aprobó los planes. La declaración de uso y el manual acompañan este informe.','small')

page(2,'Arquitectura e integración','Una solicitud conserva el mismo folio entre el canal, los especialistas, la decisión y el registro.')
story.append(Architecture());md.append('Telegram -> n8n -> orquestador -> A1/A2/A3/A4 -> revisión humana -> tabla -> exportación -> Actions -> Pages; voz -> herramienta autenticada -> la misma tabla.')
heading('Responsabilidad de cada servicio')
par('n8n Cloud recibe una sola entrada de Telegram, comprueba acceso, asigna folio, conserva estado y coordina los agentes. La tabla privada MICA_registros usa una clave para eventos y otra para casos. El orquestador es determinista: valida, organiza cuatro especialistas, reserva presupuesto y cierra cuando los controles lo permiten. Los cuatro especialistas usan el mismo modelo, con instrucciones, herramientas y resultados distintos.')
par('GitHub Pages solo sirve HTML, CSS, JavaScript y una exportación sanitizada. No ejecuta n8n ni mantiene un servidor Python. Actions comprueba datos y reglas antes de publicar; el despliegue depende de la validación. La actualización del panel es manual y reproducible: exportar, sanitizar, hacer commit y esperar el workflow. Por ello tiene fecha de corte y un retraso explícito.')
par('ElevenLabs es una interfaz adicional. Desde el widget público llama a consultar_caso o solicitar_revision mediante POST al servicio de voz en n8n. La cabecera secreta se conserva en ambos servicios, nunca en el navegador. La voz pública solo puede acceder al folio ficticio de demostración; no consulta usuarios ni datos personales.')
heading('Ejemplos de trazabilidad')
par('MICA-TG-479895074 produjo la propuesta Comercial de nueve actividades, pasó revisión y quedó registrado_simulado, versión 3, tras la aprobación de la usuaria. La conversación de voz consultó MICA-TG-479895069 y solicitó su revisión. Los costos y las evidencias conservan estos mismos folios.','small')

page(3,'Agentes y contratos','Cada especialista aporta un resultado verificable antes de que una persona decida.')
table(['Rol','Entrada y aporte','Herramienta/salida'],[
 ['Orquestador','Solicitud validada, contexto, modo y presupuesto','Orden A1-A4; estados, reserva y detención'],
 ['A1 Recepción','Seis campos del nuevo ingreso','Valida esquema; solicitud estructurada o rechazo'],
 ['A2 Fuentes','Solicitud y bases permitidas','Recupera políticas, reglas, actividades y responsables'],
 ['A3 Planificación','Fuentes y solicitud','Calcula fechas y plan; carga skills y aplica loops'],
 ['A4 Revisión','Plan propuesto y fuentes','Compara con plan canónico; conforme o bloqueo']],[91,205,203])
heading('Contrato compartido y control de salida')
par('La entrada conserva caso_id, datos, canal Telegram, modo SIMULADO, autorización y presupuesto; el contexto de A3 añade objetivo y seudónimo para el adaptador. La salida de cada especialista exige exactamente caso_id, agente, estado y resultado. El control incorpora fuentes, advertencias, duración observada y referencia de consumo. La traza del orquestador registra una decisión determinista; no se le atribuyen tokens de un modelo que no invoca.')
par('Las salidas se contrastan contra funciones de negocio: campos permitidos, puesto/departamento, actividades pertinentes, fechas, responsables y referencias. Un JSON plausible no basta. A4 bloquea si el plan difiere del resultado canónico. El registro definitivo real nunca se habilita: toda propuesta exige aprobación humana y la salida conserva el rótulo simulado.')
heading('Incidencia y corrección conservadas')
par('En Tecnología, A3 devolvió un arreglo con una cadena response en lugar del objeto esperado. El flujo produjo error controlado y no aprobó el caso. Se conservó la salida, se añadió normalización estricta del envoltorio permitido y se recuperó solo el tramo necesario hasta A4. Las llamadas previas no se repitieron. Comercial y Administración recorrieron después el flujo completo sin esa recuperación.')
notice('El normalizador no acepta campos arbitrarios ni relaja las reglas de negocio. Los modelos proponen o formatean; el servidor comprueba el contenido antes de utilizarlo.')

parse=lambda x:datetime.datetime.fromisoformat(x.replace('Z','+00:00'))
hours=[(parse(c['metricas']['primera_propuesta_revisada_en'])-parse(c['metricas']['recibido_en'])).total_seconds()/3600 for c in d['casos']]
complete_initial=sum(s['completa_al_recibir'] for s in d['solicitudes']);reqs=len(d['solicitudes'])
page(4,'Datos, indicadores y visualización','El panel responde preguntas del proceso; las cifras no son metas ni beneficios estimados.')
par('Las bases contienen departamentos, puestos, modalidades, políticas, reglas de actividad y responsables ficticios. Las fechas se calculan con días naturales y America/Mexico_City. No se cambian fechas vencidas para aparentar cumplimiento: se conserva la propuesta y se deriva a RH. No se incluye un padrón de empleados reales.')
table(['Indicador mensual','Fórmula y cohorte','Resultado'],[
 ['Preparación media','Horas desde recepción a primera propuesta revisada; mes de propuesta',f'{statistics.mean(hours):.6f} h/caso; {statistics.mean(hours)*60:.2f} min; n=3'],
 ['Completitud inicial','Solicitudes válidas iniciales / solicitudes autorizadas no duplicadas; mes de recepción',f'{complete_initial}/{reqs} = {100*complete_initial/reqs:.0f}%'],
 ['Aprobación inicial','Aprobadas sin cambios / primeras revisiones humanas concluidas; mes de revisión','3/3 = 100%']],[125,235,139])
par('La solicitud incompleta real se incluye en el denominador de completitud: excluirla habría mostrado un 100% engañoso. Las barras cuentan actividades propuestas por responsable, con escala desde cero; no son actividades concluidas. La tabla y sus detalles ofrecen el equivalente textual. Los filtros de folio/estado afectan tabla y barras; el mes filtra únicamente los tres KPI.')
heading('Procedencia y límites de las marcas')
par('Comercial y Administración registraron directamente recepción, primera propuesta revisada y primera decisión humana. En el caso legado de Tecnología la propuesta se reconstruyó restando 24 horas al vencimiento persistido; completitud y primera aprobación se contrastaron con eventos y versiones. El tiempo incluye esperas de operación y recuperación manual: no es latencia pura del modelo ni tiempo de trabajo humano.')
par('El censo cubre esta instancia del 16 al 21 de noviembre: cuatro solicitudes de canal, tres planes y tres primeras revisiones. Excluye usuario interno 0 e instancia anterior. Con denominador cero o evidencia insuficiente se muestra Sin datos; nunca se sustituye desconocido por cero. El corte es una instantánea del piloto, no todo el mes ni el desempeño de la empresa.','small')

page(5,'Seguridad y estados','Los controles están en el servidor y en el flujo, además de las instrucciones de los modelos.')
table(['Riesgo','Control aplicado','Prueba o límite'],[
 ['Acceso','Usuario permitido y chat privado; voz sobre un folio ficticio','Usuario/grupo ajenos simulados bloqueados'],
 ['Esquema e inyección','Campos/longitud y comandos admitidos; fuentes como datos','Entrada incompleta e instrucción de extraer claves rechazadas en bot'],
 ['Herramientas','Funciones permitidas y destino fijo; sin URLs del usuario','Campos/acciones arbitrarias rechazados en unidades'],
 ['Acción humana','Dueño, caso, versión y vigencia; rechazo y vencimiento','Aprobaciones reales; variantes adversas sobre código exportado'],
 ['Costo y fallas','Ocho llamadas/caso, salida 1800, timeout 30 s, retry 0','Reserva previa, límite agotado y error controlado'],
 ['Datos y duplicados','Tabla privada, claves por evento y revisión caso/versión','Mismo evento no agrega filas; una sola revisión de voz persistida']],[96,232,171])
par('Los estados operativos son recibido_sin_procesar, procesando, pendiente_aprobacion y registrado_simulado, con alternativas rechazado, vencido y error_controlado. Cada transición incrementa versión cuando corresponde. La aprobación no se infiere de una respuesta casual: requiere el comando explícito del usuario autorizado y la versión de la propuesta.')
par('La vigencia se evalúa al intentar una acción; no hay un barrido programado que cambie automáticamente todos los registros vencidos. La deduplicación es secuencial y no garantiza atomicidad bajo concurrencia. Estas limitaciones se declaran en lugar de atribuir controles que no se implementaron.')
notice('Después del lote se publicó IA=false. Registro y consulta permanecen disponibles. Generar un caso nuevo exige presupuesto, un folio permitido y habilitación deliberada; los casos cerrados no se regeneran por rutina.')

page(6,'Skills y loops reutilizables','Las instrucciones se cargan y sus políticas se aplican; no son archivos guardados sin uso.')
table(['Componente','Función','Autoevaluación'],[
 ['Skill de negocio','mica-preparar-onboarding: prepara propuesta desde fuentes autorizadas','18/20'],
 ['Skill de calidad','mica-verificar-propuesta: revisa campos, evidencia y límites','18/20'],
 ['Loop de calidad','Generar, medir, diagnosticar, corregir, validar; máximo tres iteraciones','18/20'],
 ['Loop de seguridad/costo','Comprobar permiso y reserva, ejecutar paso autorizado, conciliar o detener','17/20']],[126,286,87])
par('Cada skill cuenta con nombre, descripción, activador, entradas, herramientas, límites, salidas, errores y ejemplos válido e inválido. El adaptador lee los MD al compilar el bundle para n8n Cloud; aplica la política incluida durante la ejecución y registra ruta, versión y SHA256. No se afirma que Cloud abra el filesystem de la computadora de la estudiante en cada evento.')
heading('Mejora, reutilización y costo adicional')
par('La prueba de calidad conserva una V1 con actividad omitida, su diagnóstico y una V2 corregida con el mismo folio. El segundo caso reutiliza el método. Se registraron 41 comprobaciones locales y una ejecución n8n de componentes (ID 11, 1.764 s), sin modelos. El costo API adicional de esa corrección determinista fue cero; tiempo de cómputo y cuota de plataforma no se monetizaron.')
par('Las rutas completas de Comercial y Administración cargaron ambos skills y dejaron la traza de loops en A3, con hashes cotejados contra los archivos. Pasaron en una iteración porque sus planes ya eran conformes; no se inventa una V2 innecesaria en esos casos. La demostración V1-V2 es el ensayo controlado separado y etiquetado.')
par('La autoevaluación usa cinco aspectos de 0 a 4: propósito/claridad, contexto/secuencia, evidencia, control/retorno y utilidad. Todos superan 16/20 y ningún aspecto queda por debajo de 3. Es una autoevaluación del proyecto, no una calificación otorgada por la docente.','small')

page(7,'Sitio público y voz integrada','Una conversación consultó el mismo caso y pidió revisión sin aprobarlo por voz.')
par('Pages muestra datos sanitizados, fecha de corte, tres KPI, barras, detalle y filtros. Antes de publicar, Actions valida esquema, cálculos y reglas. Una omisión deliberada de regla hizo fallar la validación y dejó el despliegue omitido; al restaurarla, ambos pasos pasaron. Los enlaces exactos están en el índice, con actualizaciones posteriores verificadas.')
table(['Momento de la llamada','Evidencia'],[['Inicio','MICA se identifica como IA y solicita consentimiento; la página exige aceptación previa'],['0:35','consultar_caso: Exitoso; recupera versión 3 y ocho actividades'],['0:39','solicitar_revision: Exitoso; petición pendiente de RH del mismo folio'],['Cierre','Aviso explícito por duración máxima; metadatos 61 s, reproductor 59 s'],['Consumo','831 créditos: 667 plataforma y 164 LLM; seis turnos facturados']],[144,355])
par('La autenticación falló en un primer ensayo manual y se conservó el rechazo. Tras introducir la misma clave en n8n y en un nuevo secreto de ElevenLabs, ambas herramientas pasaron. El modelo de voz no recibe la clave. El dominio permitido es el del Pages público; esta restricción de host no equivale a autenticar individualmente al visitante, por lo que solo se expone información ficticia.')
par('El control final del panel comprueba el permiso del micrófono después del consentimiento y detiene esa captura antes de cargar el widget; el usuario inicia la llamada aparte. Ante permiso denegado o carga fallida, muestra un mensaje y Telegram. Estos manejadores se probaron con NotAllowedError y fallo de servicio simulados, sin otra llamada pagada. No se presentan como una caída real de ElevenLabs.')
par('Límites publicados: 60 s, cierre por 20 s de silencio, tres llamadas diarias, una simultánea, sin ráfagas, cola ni archivos. La conversación real terminó después de las dos acciones. El retiro de consentimiento recarga la página y cierra sus conexiones.','small')

page(8,'Pruebas y resultados','La matriz acompaña cada resultado con su origen y conserva los fallos y sus correcciones.')
table(['ID','Cobertura','Tipo de evidencia'],[
 ['P01','Tecnología completa tras recuperación A3','Real, con alerta'],['P02','Comercial y Administración completos','Real'],['P03','Voz y dos herramientas del mismo caso','Real'],['P04','Aprobación, rechazo y vencimiento','Real + controlada'],['P05','Vacío e incompleto','Bot real + unidad'],['P06','Inyección y extracción de secretos','Bot real + unidad'],['P07','Actor y chat sin permiso','Código exportado, simulada'],['P08','Timeout/cuota y servicio caído','Simulación controlada'],['P09','Límite de dinero, llamadas e iteraciones','Local y componente n8n'],['P10','Evento/revisión duplicados','Local + registro persistido'],['P11','Carga, corrección V1-V2 y reutilización','Local, n8n y casos reales'],['P12','Actions bloquea y recupera','Real'],['P13','390/1366, teclado, estados y micrófono','Interfaz + fallo simulado'],['P14','Trazas, llamadas, costos y panel','Real y documental']],[40,285,174])
par('Los anchos se verificaron con viewports de contenido en iframes locales: 390 y 1366 píxeles, sin desbordamiento interno. Este método se declara porque el control del tamaño de la ventana no modificó inicialmente el ancho observado. No se afirma certificación WCAG ni compatibilidad con todos los navegadores.')
par('pruebas.csv contiene fecha de auditoría, versión, folio, entrada, esperado, obtenido, estado, tipo y evidencia. Una prueba negativa se aprueba cuando bloquea de forma controlada. Las simulaciones verifican rutas del código exportado, pero no sustituyen una prueba de carga, de otro usuario real ni de disponibilidad del proveedor.','small')

page(9,'Costos y escenarios','Consumo medido, costo calculado y dinero aportado son conceptos distintos.')
table(['Componente','Uso','Costo calculado/observado'],[
 ['Tres casos completos','24 llamadas n8n',f"USD {cost['tres_casos_completos_llm_usd']:.8f}; media {cost['promedio_llm_por_caso_usd']:.8f}/caso"],
 ['Todos los ensayos Gateway','34 llamadas medidas',f"USD {cost['subtotal_llm_n8n_calculado_usd']:.8f}; incluye ensayo A1 fallido"],
 ['Voz','61 s; 831 créditos','667 plataforma + 164 LLM; LLM mostrado 0.0154 $'],
 ['Recarga reportada','USD 5 aportados por la usuaria','No equivale a consumo; proveedor/saldo sin conciliar']],[135,139,225])
par('C_llamada=(Tentrada×Pentrada + Tsalida×Psalida)/1,000,000. Gateway verificado: 0.15 USD/millón entrada y 0.60 salida. No se presume descuento de caché no desglosada. Los prompts del desarrollo y cargos finales no disponibles se registran desconocidos, no cero. El subtotal conocido no es costo total del proyecto.','small')
table(['Ruta / casos mes','Voz min / n8n ejec.','USD + EUR al mes','USD si EUR=1.10*'],[[f"{x['escenario']} / {x['casos_mes']:,}",f"{x['minutos_voz']:.0f} / {x['ejecuciones_n8n']:,}",f"{x['subtotal_usd']:.2f} + {x['fijo_n8n_eur']:.0f}",f"{x['total_usd_si_eur_usd_1_10_supuesto']:.2f}"] for x in sc],[110,130,145,114])
par('*Conversión didáctica, no cotización. Base: 20% de casos con 1 min de voz y 3.4 ejecuciones/caso. Alto: 50% con 2 min, contexto doble, salida 1.5 veces y corrección parcial en 10%; 6.1 ejecuciones/caso. Incluye cuotas de planes y exceso de voz. El cupo custom de 100K usado para 61K ejecuciones es un supuesto por confirmar. Precios sin promociones ni impuestos. No se contrataron planes.','small')
par('Optimización implementada: loops deterministas corrigen reglas sin otra llamada LLM. V1 falla y V2 pasa con API adicional 0. Una corrección hipotética de 1000/300 tokens costaría USD 0.00033; es ahorro potencial, no medido. Para escalar se requieren más cuotas y validación de carga; los límites de prueba actuales no soportan estos volúmenes.','small')

page(10,'Decisión, límites y referencias','Piloto funcional para evaluación académica, con alertas de operación y conciliación.')
heading('Conclusión y reflexión para la defensa')
par('MICA convierte una solicitud en una propuesta revisada y trazable; la decisión que mejora es la revisión de onboarding por RH. A1 evita campos inconsistentes, A2 limita las fuentes, A3 calcula y aplica skills, y A4 impide liberar un plan no conforme. El control que evitó una acción incorrecta fue la revisión de contrato/plan junto con la aprobación vinculada a versión: el error A3 no se presentó como un plan aprobado.')
par('El componente LLM de voz mostrado (0.0154 $) supera al subtotal calculado de Gateway (0.00503595 USD), aunque ninguno equivale al costo integral facturado. Los créditos no se comparan directamente con dinero sin tarifa de cuenta. Multiplicar volumen exige revisar minutos incluidos, ejecuciones, soporte humano y concurrencia; no basta multiplicar el costo de una prueba gratuita. Antes de usar datos reales se necesitan autorización, minimización, autenticación individual, retención, atomicidad y validación de impacto laboral. No se ha demostrado ROI ni ahorro de tiempo humano.')
par('El informe, el registro de costos y la matriz no sustituyen la defensa individual. Wendy debe mantener los servicios disponibles, revisar su declaración de IA y explicar cómo habilitar un nuevo folio con presupuesto. El paquete importa inactivo y sin secretos; el sitio conserva consulta y voz, mientras el flujo está publicado con IA=false.','small')
heading('Referencias y fuentes de implementación')
refs=[
 'Morales, E. C. (2026, 30 de octubre). <i>Proyecto final individual de AI Tools: Guía del estudiante</i>. Consigna proporcionada en clase, 16 páginas.',
 'n8n. (s. f.). <i>Service pricing</i>. https://app.n8n.cloud/service-pricing#openai (tarifa revisada 21/11/2026).',
 'n8n. (s. f.). <i>Plans and pricing</i>. https://n8n.io/pricing/ (cuotas y precios mensuales revisados 21/11/2026).',
 'n8n. (2026, 27 de agosto). <i>How can I add more workflow executions?</i> https://support.n8n.io/article/can-i-add-more-executions',
 'GitHub. (s. f.). <i>Using custom workflows with GitHub Pages</i>. https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages',
 'ElevenLabs. (s. f.). <i>Widget customization</i>; <i>Webhook tools</i>. https://elevenlabs.io/docs/eleven-agents/customization/widget ; /customization/tools/webhook-tools',
 'ElevenLabs. (s. f.). <i>Conversation flow</i>; <i>ElevenAgents pricing</i>. https://elevenlabs.io/docs/eleven-agents/customization/conversation-flow ; https://elevenlabs.io/pricing/agents',
 'W3C. (s. f.). <i>How to meet WCAG 2.2</i>. https://www.w3.org/WAI/WCAG22/quickref/'
]
for r in refs:par(r,'ref')

def chrome(c,doc):
 c.saveState();w,h=A4;c.setFillColor(CREAM);c.rect(0,h-32,w,32,fill=1,stroke=0);c.setFillColor(PURPLE);c.setFont(BOLD,8);c.drawString(48,h-21,'MICA / AI TOOLS / INFORME TÉCNICO Y EMPRESARIAL');c.setStrokeColor(LAV);c.line(48,38,w-48,38);c.setFont(FONT,8);c.setFillColor(INK);c.drawString(48,24,'© Wendy Miranda · 2026 · Datos y acciones empresariales simulados');c.drawRightString(w-48,24,str(doc.page));c.restoreState()
dst=O/'MICA_Informe_Final.pdf'
doc=SimpleDocTemplate(str(dst),pagesize=A4,rightMargin=48,leftMargin=48,topMargin=51,bottomMargin=50,title='MICA - Informe técnico y empresarial',author='Wendy Miranda',pageCompression=1)
doc.build(story,onFirstPage=chrome,onLaterPages=chrome)
(P/'docs/INFORME_FINAL.md').write_text('\n\n'.join(md)+'\n')
from pypdf import PdfReader
pages=len(PdfReader(dst).pages)
assert 8<=pages<=12,f'Informe fuera del requisito: {pages} páginas'
print(json.dumps({'pdf':str(dst),'paginas':pages,'esperadas':10,'palabras_fuente':len(' '.join(md).split())},ensure_ascii=False))
