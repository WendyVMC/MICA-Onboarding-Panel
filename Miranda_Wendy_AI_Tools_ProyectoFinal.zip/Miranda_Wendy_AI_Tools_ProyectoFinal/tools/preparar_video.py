"""Respaldo narrado con voz local: no APIs ni nuevas ejecuciones del sistema."""
from pathlib import Path
import json,subprocess,textwrap
from PIL import Image,ImageDraw,ImageFont,ImageOps
P=Path(__file__).resolve().parents[1];T=P/'tmp/video';T.mkdir(parents=True,exist_ok=True)
fontdir=Path('/System/Library/Fonts/Supplemental')
def font(s,b=False):return ImageFont.truetype(str(fontdir/('Arial Bold.ttf' if b else 'Arial.ttf')),s)
chapters=[
('MICA: onboarding con revisión humana', ['Empresa ficticia · People & Culture','Datos sintéticos, servicios conectados','Decisión final a cargo de RH'],
'''Este es el respaldo narrado del proyecto individual MICA, un asistente de onboarding para una empresa ficticia. El objetivo es transformar una solicitud breve en un plan que Recursos Humanos pueda revisar y aprobar. Los datos y las acciones de negocio son simulados; las integraciones y los consumos que se muestran sí fueron reales. Este video recorre evidencias ya obtenidas, no es una ejecución continua nueva. La narración se genera con una voz local del equipo. La estudiante debe revisar los archivos y poder explicar el sistema durante la defensa.''','docs/INFORME_FINAL.md',None),
('Un folio une las integraciones', ['Telegram: una entrada en producción','n8n: coordinación y tabla privada','Pages: vista estática; voz: interfaz adicional'],
'''La arquitectura mantiene un mismo folio entre Telegram, n8n, los especialistas, la aprobación y los costos. Telegram tiene un solo receptor para evitar conflictos de webhooks. n8n conserva los estados en una tabla privada y coordina el procesamiento. Después de una decisión humana, una exportación sanitizada alimenta el panel. GitHub Actions valida esa exportación y solo publica si pasa. GitHub Pages sirve los archivos estáticos: no ejecuta los agentes. Desde ese mismo sitio, ElevenLabs consulta el registro mediante una herramienta autenticada de servidor. Las contraseñas nunca llegan al HTML.''','docs/MANUAL_REPRODUCCION.md',None),
('Cuatro especialistas, aportes distintos', ['A1 valida campos · A2 verifica fuentes','A3 calcula y aplica los skills','A4 revisa contra reglas canónicas'],
'''El orquestador es determinista: comprueba la solicitud, organiza los roles, reserva presupuesto y decide si puede continuar. El agente uno valida los seis campos del nuevo ingreso. El dos recupera políticas y actividades autorizadas. El tres construye las fechas y responsables y aplica los skills. El cuatro compara la propuesta contra un plan canónico y puede bloquearla. Compartir modelo no convierte a los agentes en copias: sus instrucciones, herramientas y salidas son diferentes. Un objeto JSON bien formado no basta; el servidor comprueba su contenido antes de pedir aprobación.''','agentes/herramientas_mica.js',None),
('Tres casos completos · 25 actividades', ['Tecnología remota: 8 actividades','Comercial híbrido: 9 · Administración: 8','KPI: 0.098 h · 75% · 100%'],
'''Se completaron tres casos distintos. Tecnología remota produjo ocho actividades; Comercial híbrido, nueve; Administración presencial, ocho. Los tres quedaron aprobados por la usuaria y registrados como simulados, versión tres. El primer caso necesitó recuperación manual de un formato de salida; los otros dos completaron su ruta sin repetirla. El panel distingue ese antecedente. La preparación media fue aproximadamente cinco minutos con cincuenta y tres segundos, incluyendo esperas. La completitud es setenta y cinco por ciento porque una solicitud incompleta también pertenece al denominador. La aprobación inicial es tres de tres. Esta muestra no prueba rendimiento empresarial.''','evidencias/lote003_cierre_casos.json',None),
('Un error no se convierte en aprobación', ['Solicitud incompleta: aclaración, sin plan','Inyección: comando rechazado, sin secretos','Dueño, versión, vencimiento y duplicados'],
'''Las pruebas negativas son parte del funcionamiento. Una solicitud incompleta real al bot recibió una aclaración y no generó un caso. Una instrucción de ignorar reglas y revelar claves fue rechazada por el parser, sin llamar al modelo. También se probaron, de forma controlada sobre el código exportado, usuario ajeno, versión incorrecta, rechazo, vencimiento y presupuesto agotado. La deduplicación evita repetir la operación del mismo evento. Ante un error controlado, el plan queda vacío y no se aprueba. Se conserva una limitación: no está demostrada la atomicidad ante solicitudes concurrentes.''','evidencias/guardrails_entrega.json','entregables/telegram_pruebas_sanitizado.png'),
('Skills cargados y loops con retorno', ['Dos SKILL.md versionados y trazables','V1 falla · V2 corrige · segundo caso reutiliza','Máximo tres iteraciones; sin repetir modelos'],
'''Hay dos skills específicos: preparar onboarding y verificar la propuesta. El adaptador lee sus archivos al compilar y aplica sus políticas en n8n; la traza registra versión y hash. El loop de calidad genera, mide, diagnostica, corrige y valida. El de seguridad y costo comprueba permisos y reserva antes de continuar. Una prueba conserva una versión uno con una actividad omitida y una versión dos corregida, con el mismo folio. Esa corrección determinista no añadió llamadas de modelos. Ambos métodos se reutilizaron después en las rutas completas de Comercial y Administración.''','evidencias/skills_loops_n8n_resultados.json',None),
('Voz real en la página publicada', ['Consulta exitosa a 0:35','Revisión exitosa a 0:39','Cierre por límite · 831 créditos'],
'''La estudiante realizó una conversación real desde el widget público. MICA se identificó como inteligencia artificial y recibió consentimiento antes de usar herramientas. El registro muestra consulta exitosa a los treinta y cinco segundos y solicitud de revisión exitosa a los treinta y nueve. La llamada terminó por el límite configurado de sesenta segundos; sus metadatos registran sesenta y uno. Consumió ochocientos treinta y un créditos: seiscientos sesenta y siete de plataforma y ciento sesenta y cuatro de modelo. El control final de micrófono y servicio caído se validó con fallos simulados, sin otra llamada pagada.''','evidencias/voz_conversacion_real_2026-11-21.json',None),
('Costo, consumo y recarga se separan', ['34 llamadas Gateway medidas','USD 0.00503595 calculados en ensayos','USD 5 reportados como recarga, no consumo'],
'''El registro reúne treinta y cuatro llamadas medidas de Gateway, incluyendo pruebas y la recuperación del primer caso. Su subtotal calculado es de aproximadamente medio centavo de dólar. No es el costo total del proyecto: faltan facturas y uso del asistente de desarrollo. La usuaria reportó una recarga de cinco dólares; no se cuenta como consumo ni se inventa el saldo restante. Los créditos de ElevenLabs se mantienen separados y no se suman dos veces. Los escenarios de cien, mil y diez mil casos incorporan planes, cuotas, minutos de voz y una ruta de mayor consumo.''','costos/RESUMEN_Y_METODO.md',None),
('Reproducir, explicar y detener', ['JSON sin secretos · manual paso a paso','Matriz P01-P14 y archivos con hashes','IA desactivada al terminar el lote'],
'''La entrega incluye workflows importables sin secretos, bases sintéticas, skills, loops, matriz de pruebas, costos, escenarios e informe. El manual explica dónde corre cada servicio y cómo volver a vincular credenciales. Para repetir un caso se registra un folio nuevo y se habilita solo ese folio con presupuesto; al finalizar se desactiva otra vez la inteligencia artificial. El panel sigue disponible para consulta y voz. La evaluación en vivo requiere mantener n8n y sus cuotas activos. Esta es una demostración académica con limitaciones declaradas; no un sistema listo para decisiones laborales reales ni una garantía de ahorro.''','docs/MANUAL_REPRODUCCION.md',None)
]
def wrap(draw,text,f,maxw):
 lines=[];line=''
 for word in text.split():
  test=(line+' '+word).strip()
  if draw.textlength(test,font=f)>maxw and line:lines.append(line);line=word
  else:line=test
 if line:lines.append(line)
 return lines
manifest=[]
for i,(title,bullets,narration,source,image) in enumerate(chapters,1):
 im=Image.new('RGB',(1280,720),'#FFF9F0');dr=ImageDraw.Draw(im)
 dr.text((44,28),'MICA / AI TOOLS / RESPALDO NARRADO',font=font(20,True),fill='#765782')
 y=82
 for line in wrap(dr,title,font(38,True),1180):dr.text((44,y),line,font=font(38,True),fill='#302B38');y+=47
 dr.line((44,y+12,1236,y+12),fill='#CDB4DB',width=2);top=y+42
 if image:
  img=Image.open(P/image).convert('RGB');img=ImageOps.contain(img,(690,390));im.paste(img,(548,top));bw=445
 else:bw=1110
 colors=['#A9D6E5','#F6B6C8','#BDE0C4'];by=top
 for j,b in enumerate(bullets):
  lines=wrap(dr,b,font(27,True),bw-42);height=max(75,len(lines)*35+24)
  dr.rounded_rectangle((44,by,44+bw,by+height),radius=18,fill=colors[j%3]);ty=by+15
  for line in lines:dr.text((64,ty),line,font=font(27,True),fill='#302B38');ty+=35
  by+=height+18
 dr.text((44,642),'Evidencia: '+source,font=font(17),fill='#584E60')
 dr.text((44,682),'© Wendy Miranda · Narración sintética local · Evidencias reales y simulaciones rotuladas',font=font(16),fill='#584E60')
 dr.text((1190,680),f'{i}/9',font=font(18,True),fill='#765782')
 png=T/f'capitulo_{i:02}.png';im.save(png)
 txt=T/f'capitulo_{i:02}.txt';txt.write_text(narration)
 audio=T/f'capitulo_{i:02}.aiff'
 if not audio.exists() or audio.stat().st_size<=4096:subprocess.run(['/usr/bin/say','-v','Paulina','-r','145','-f',str(txt),'-o',str(audio)],check=True)
 manifest.append({'titulo':title,'imagen':str(png),'audio':str(audio),'texto':narration,'minimo_segundos':36})
(T/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
(P/'docs/GUION_VIDEO_Y_DEFENSA.md').write_text('# Video de respaldo\n\nRecorrido narrado por evidencias existentes; no grabación continua de ejecuciones. Voz local de sistema, sin imitar a Wendy ni consumir ElevenLabs.\n\n'+'\n\n'.join(f'## {i}. {c[0]}\n\n{c[2]}' for i,c in enumerate(chapters,1))+'''\n\n# Defensa en vivo (hasta 12 minutos)
\n0-1: problema, alcance y tres KPI. 1-5: mostrar folio, cuatro especialistas, controles y aprobación. Si se exige caso nuevo, habilitar previamente un único folio con presupuesto explícito; no regenerar aprobados. 5-7: Pages y voz del mismo folio, solo una llamada autorizada. 7-9: entrada incompleta/inyección bloqueadas y V1-V2 del loop. 9-10: Actions fallido/corregido y exportación sanitizada. 10-12: costos, incertidumbre y modificación técnica.
\nPreguntas que debes poder explicar: por qué cuatro roles, qué valida el servidor, cómo cambiar una fecha sin violar políticas, qué ocurre si vence una propuesta, por qué 75% de completitud y qué diferencia hay entre créditos, recarga y costo consumido. No memorizar respuestas sin revisar el código. La defensa individual debe realizarla la estudiante.
''')
print('Nueve capítulos y audios locales preparados; sin APIs ni conversaciones nuevas.')
