from pathlib import Path
import json
P=Path(__file__).resolve().parents[1]
bundle=(P/'runtime/n8n_skills_bundle.js').read_text()
contexto="""const acceso=$('Validar acceso MICA').first().json;
if(!acceso.permitidos.includes(String(acceso.evento.message.from.id)))throw Error('USUARIO_NO_AUTORIZADO');
c.usuario_autorizado=true;c.usuario_seudonimo='RH-AUTORIZADO';c.objetivo='Preparar onboarding simulado de nuevo ingreso';c.limite_costo_usd=c.presupuesto.limite_usd;
"""
tool=bundle+"\nconst c=$('Reserva A3').first().json;\n"+contexto+"\nconst r=ejecutarNegocio(c);return JSON.stringify({caso_id:c.caso_id,agente:'A3',estado:'ok',resultado:r.resultado});"
control=bundle+"\nconst c=$('Reserva A3').first().json;\n"+contexto+"""
let o=$input.first().json.output;if(typeof o==='string')o=JSON.parse(o.replace(/^```(?:json)?\\s*/,'').replace(/\\s*```$/,''));
if(Array.isArray(o)&&o.length===1&&o[0]&&Object.keys(o[0]).length===1&&typeof o[0].response==='string')o=JSON.parse(o[0].response);
if(!o||JSON.stringify(Object.keys(o).sort())!==JSON.stringify(['agente','caso_id','estado','resultado'].sort())||o.caso_id!==c.caso_id||o.agente!=='A3'||o.estado!=='ok')throw Error('CONTRATO_SALIDA_INVALIDO');
const loop=loopCalidad(c,{propuesta_inicial:o.resultado});
if(!['pendiente_aprobacion','requiere_revision_rh'].includes(loop.estado))throw Error('LOOP_CALIDAD_BLOQUEADO');
if(loop.propuesta)o.resultado=loop.propuesta;
const out=validarSalida('A3',o,c);c.resultados.A3=out.resultado;
c.traza.push({...out,fuentes:{version:'1.0.0',base:'MICA sintetica'},advertencias:out.resultado.requiere_revision_fechas?['FECHAS_REQUIEREN_REVISION_RH']:[],duracion_ms:Date.now()-c.paso_inicio,consumo_ref:c.caso_id+'-A3',modo:'SIMULADO',skills_loops:{cargas:loop.cargas,estado:loop.estado,iteraciones:loop.traza.length,traza:loop.traza,consumo:loop.consumo||{tokens:'no_aplica',costo_api_usd:0,llamadas_modelo:0},nota:'Validación/corrección determinista; no duplica costo de llamada del agente.'}});
return [{json:c}];
"""
(P/'n8n/patch_skills_A3.json').write_text(json.dumps({'herramienta_A3':tool,'Control A3':control},ensure_ascii=False,indent=2)+'\n')
print('Patch A3 preparado para borrador, sin ejecutar modelos ni cambiar conexiones.')
