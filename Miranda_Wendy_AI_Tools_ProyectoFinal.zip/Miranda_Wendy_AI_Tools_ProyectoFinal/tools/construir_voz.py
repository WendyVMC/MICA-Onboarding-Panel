import json,uuid
from pathlib import Path
P=Path(__file__).resolve().parents[1]
helper=(P/'voz/servicio_casos.js').read_text();old=json.loads((P/'n8n/mica_integrado_borrador.json').read_text());nodes=[];connections={}
def add(name,t,p,x,v=2):
 n={'id':str(uuid.uuid4()),'name':name,'type':t,'parameters':p,'position':[x,0],'typeVersion':v};nodes.append(n);return n
def link(a,b,index=0):
 outs=connections.setdefault(a,{}).setdefault('main',[[]]);
 while len(outs)<=index:outs.append([])
 outs[index].append({'node':b,'type':'main','index':0})
add('Entrada voz autenticada','n8n-nodes-base.webhook',{'httpMethod':'POST','path':'mica-voz-v1','authentication':'headerAuth','responseMode':'responseNode','options':{}},0,2)
read=add('Leer casos privados','n8n-nodes-base.dataTable',{'resource':'row','operation':'get','dataTableId':{'__rl':True,'value':'T8bvKOkKmBD7At3g','mode':'id'},'returnAll':True},260,1.1);read['alwaysOutputData']=True
code=helper+"\nconst body=$('Entrada voz autenticada').first().json.body;const r=procesarVoz(body,$input.all().map(x=>x.json));return [{json:r}];"
add('Procesar solicitud de voz','n8n-nodes-base.code',{'jsCode':code},520)
add('Requiere escritura','n8n-nodes-base.if',{'conditions':{'options':{'caseSensitive':True,'leftValue':'','typeValidation':'strict','version':2},'conditions':[{'id':str(uuid.uuid4()),'leftValue':'={{ $json.escritura }}','rightValue':'','operator':{'type':'boolean','operation':'true','singleValue':True}}],'combinator':'and'},'options':{}},780,2.2)
persist=next(x for x in old['nodes'] if x['name']=='Persistir registros MICA');persist=json.loads(json.dumps(persist));persist.update(id=str(uuid.uuid4()),name='Guardar solicitud de revision',position=[1040,-140]);persist['parameters']['dataTableId']['value']='T8bvKOkKmBD7At3g'
persist['parameters']['filters']['conditions'][0]['keyValue']='={{ $json.fila.clave }}';persist['parameters']['columns']['value']={k:'={{ $json.fila.'+k+' }}'for k in ['clave','tipo','estado','payload']};nodes.append(persist)
add('Respuesta JSON voz','n8n-nodes-base.respondToWebhook',{'respondWith':'json','responseBody':"={{ $('Procesar solicitud de voz').first().json.respuesta }}",'options':{'responseCode':"={{ $('Procesar solicitud de voz').first().json.http_status }}"}},1300,1.4)
link('Entrada voz autenticada','Leer casos privados');link('Leer casos privados','Procesar solicitud de voz');link('Procesar solicitud de voz','Requiere escritura');link('Requiere escritura','Guardar solicitud de revision');link('Requiere escritura','Respuesta JSON voz',1);link('Guardar solicitud de revision','Respuesta JSON voz')
w={'name':'MICA - Herramientas voz autenticadas BORRADOR','nodes':nodes,'connections':connections,'active':False,'settings':{'executionOrder':'v1','timezone':'America/Mexico_City','executionTimeout':30,'saveDataSuccessExecution':'none','saveDataErrorExecution':'none'},'pinData':{}}
(P/'n8n/mica_voz_herramientas_borrador.json').write_text(json.dumps(w,ensure_ascii=False,indent=2)+'\n');print('Borrador generado, inactivo y pendiente de credencial Header Auth; sin modelos.')
