#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>
#import <CoreVideo/CoreVideo.h>
#import <CoreGraphics/CoreGraphics.h>
#import <ImageIO/ImageIO.h>
int main(int argc,const char *argv[]){@autoreleasepool{
 if(argc!=3)return 2;
 NSError *error=nil;NSString *manifest=@(argv[1]);NSURL *output=[NSURL fileURLWithPath:@(argv[2])];
 NSArray *chapters=[NSJSONSerialization JSONObjectWithData:[NSData dataWithContentsOfFile:manifest] options:0 error:&error];
 if(!chapters){NSLog(@"%@",error);return 3;}
 NSFileManager *fm=NSFileManager.defaultManager;
 [fm createDirectoryAtURL:output.URLByDeletingLastPathComponent withIntermediateDirectories:YES attributes:nil error:&error];
 NSURL *silent=[NSURL fileURLWithPath:[[manifest stringByDeletingLastPathComponent] stringByAppendingPathComponent:@"video_sin_audio.mp4"]];
 for(NSURL *u in @[silent,output])if([fm fileExistsAtPath:u.path])[fm removeItemAtURL:u error:nil];
 AVAssetWriter *writer=[[AVAssetWriter alloc]initWithURL:silent fileType:AVFileTypeMPEG4 error:&error];
 NSDictionary *settings=@{AVVideoCodecKey:AVVideoCodecTypeH264,AVVideoWidthKey:@1280,AVVideoHeightKey:@720,AVVideoCompressionPropertiesKey:@{AVVideoAverageBitRateKey:@900000,AVVideoExpectedSourceFrameRateKey:@1,AVVideoMaxKeyFrameIntervalKey:@30}};
 AVAssetWriterInput *input=[AVAssetWriterInput assetWriterInputWithMediaType:AVMediaTypeVideo outputSettings:settings];input.expectsMediaDataInRealTime=NO;
 NSDictionary *attrs=@{(id)kCVPixelBufferPixelFormatTypeKey:@(kCVPixelFormatType_32ARGB),(id)kCVPixelBufferWidthKey:@1280,(id)kCVPixelBufferHeightKey:@720,(id)kCVPixelBufferCGImageCompatibilityKey:@YES,(id)kCVPixelBufferCGBitmapContextCompatibilityKey:@YES};
 AVAssetWriterInputPixelBufferAdaptor *adaptor=[AVAssetWriterInputPixelBufferAdaptor assetWriterInputPixelBufferAdaptorWithAssetWriterInput:input sourcePixelBufferAttributes:attrs];
 [writer addInput:input];if(![writer startWriting]){NSLog(@"%@",writer.error);return 4;}[writer startSessionAtSourceTime:kCMTimeZero];
 int cursor=0;NSMutableArray *segments=[NSMutableArray new];
 for(NSDictionary *chapter in chapters){@autoreleasepool{
  NSURL *audioURL=[NSURL fileURLWithPath:chapter[@"audio"]];AVURLAsset *audio=[AVURLAsset URLAssetWithURL:audioURL options:nil];
  int duration=MAX([chapter[@"minimo_segundos"] intValue],(int)ceil(CMTimeGetSeconds(audio.duration))+1);
  NSURL *imageURL=[NSURL fileURLWithPath:chapter[@"imagen"]];CGImageSourceRef source=CGImageSourceCreateWithURL((__bridge CFURLRef)imageURL,NULL);CGImageRef image=CGImageSourceCreateImageAtIndex(source,0,NULL);
  CVPixelBufferRef buffer=NULL;CVReturn rv=CVPixelBufferCreate(kCFAllocatorDefault,1280,720,kCVPixelFormatType_32ARGB,(__bridge CFDictionaryRef)attrs,&buffer);if(rv!=kCVReturnSuccess)return 5;
  CVPixelBufferLockBaseAddress(buffer,0);CGColorSpaceRef space=CGColorSpaceCreateDeviceRGB();CGContextRef ctx=CGBitmapContextCreate(CVPixelBufferGetBaseAddress(buffer),1280,720,8,CVPixelBufferGetBytesPerRow(buffer),space,kCGImageAlphaNoneSkipFirst);CGContextDrawImage(ctx,CGRectMake(0,0,1280,720),image);CGContextRelease(ctx);CGColorSpaceRelease(space);CGImageRelease(image);CFRelease(source);CVPixelBufferUnlockBaseAddress(buffer,0);
  for(int i=0;i<duration;i++){while(!input.readyForMoreMediaData)[NSThread sleepForTimeInterval:.005];if(![adaptor appendPixelBuffer:buffer withPresentationTime:CMTimeMake(cursor+i,1)]){NSLog(@"%@",writer.error);return 6;}}
  CVPixelBufferRelease(buffer);[segments addObject:@{ @"audio":audioURL,@"inicio":@(cursor),@"duracion":@(duration)}];cursor+=duration;
  printf("Capitulo: %s, %d s\n",[chapter[@"titulo"] UTF8String],duration);fflush(stdout);
 }}
 [writer endSessionAtSourceTime:CMTimeMake(cursor,1)];[input markAsFinished];dispatch_semaphore_t done=dispatch_semaphore_create(0);[writer finishWritingWithCompletionHandler:^{dispatch_semaphore_signal(done);}];dispatch_semaphore_wait(done,DISPATCH_TIME_FOREVER);if(writer.status!=AVAssetWriterStatusCompleted){NSLog(@"%@",writer.error);return 7;}
 AVMutableComposition *composition=[AVMutableComposition composition];AVURLAsset *silentAsset=[AVURLAsset URLAssetWithURL:silent options:nil];AVMutableCompositionTrack *video=[composition addMutableTrackWithMediaType:AVMediaTypeVideo preferredTrackID:kCMPersistentTrackID_Invalid];
 [video insertTimeRange:CMTimeRangeMake(kCMTimeZero,CMTimeMake(cursor,1)) ofTrack:[silentAsset tracksWithMediaType:AVMediaTypeVideo].firstObject atTime:kCMTimeZero error:&error];
 AVMutableCompositionTrack *sound=[composition addMutableTrackWithMediaType:AVMediaTypeAudio preferredTrackID:kCMPersistentTrackID_Invalid];
 for(NSDictionary *segment in segments){AVURLAsset *audio=[AVURLAsset URLAssetWithURL:segment[@"audio"] options:nil];[sound insertTimeRange:CMTimeRangeMake(kCMTimeZero,audio.duration) ofTrack:[audio tracksWithMediaType:AVMediaTypeAudio].firstObject atTime:CMTimeMake([segment[@"inicio"] intValue],1) error:&error];}
 AVAssetExportSession *export=[[AVAssetExportSession alloc]initWithAsset:composition presetName:AVAssetExportPresetPassthrough];export.outputURL=output;export.outputFileType=AVFileTypeQuickTimeMovie;export.shouldOptimizeForNetworkUse=YES;
 dispatch_semaphore_t finish=dispatch_semaphore_create(0);[export exportAsynchronouslyWithCompletionHandler:^{dispatch_semaphore_signal(finish);}];dispatch_semaphore_wait(finish,DISPATCH_TIME_FOREVER);if(export.status!=AVAssetExportSessionStatusCompleted){NSLog(@"%@",export.error);return 8;}
 AVURLAsset *final=[AVURLAsset URLAssetWithURL:output options:nil];AVAssetImageGenerator *generator=[[AVAssetImageGenerator alloc]initWithAsset:final];generator.appliesPreferredTrackTransform=YES;
 for(NSNumber *sec in @[@10,@(cursor/2),@(cursor-10)]){CGImageRef cg=[generator copyCGImageAtTime:CMTimeMake(sec.intValue,1) actualTime:NULL error:&error];NSURL *u=[NSURL fileURLWithPath:[[manifest stringByDeletingLastPathComponent] stringByAppendingPathComponent:[NSString stringWithFormat:@"preview_%@.png",sec]]];CGImageDestinationRef dest=CGImageDestinationCreateWithURL((__bridge CFURLRef)u,CFSTR("public.png"),1,NULL);CGImageDestinationAddImage(dest,cg,NULL);CGImageDestinationFinalize(dest);CFRelease(dest);CGImageRelease(cg);}
 NSDictionary *result=@{@"archivo":output.path,@"duracion_segundos":@(CMTimeGetSeconds(final.duration)),@"capitulos":@(chapters.count),@"pistas_audio":@([final tracksWithMediaType:AVMediaTypeAudio].count),@"pistas_video":@([final tracksWithMediaType:AVMediaTypeVideo].count),@"metodo":@"Recorrido narrado de evidencias, voz local Paulina; no captura continua ni nuevas APIs."};NSData *data=[NSJSONSerialization dataWithJSONObject:result options:NSJSONWritingPrettyPrinted error:&error];[data writeToURL:[output.URLByDeletingLastPathComponent URLByAppendingPathComponent:@"video_metadata.json"] atomically:YES];puts([[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding].UTF8String);
 return 0;
}}
