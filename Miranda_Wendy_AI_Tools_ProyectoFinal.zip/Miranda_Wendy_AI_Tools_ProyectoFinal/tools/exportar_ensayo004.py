"""Cierre reproducible del lote autorizado: datos privados -> lista blanca pública."""
import csv, hashlib, json, os, subprocess, sys
from pathlib import Path
P=Path(__file__).resolve().parents[1]
source=P/'privado/tabla_mica_ensayo_004.csv'
if not source.exists():source=P/'privado/tabla_mica_2026-11-21.csv'
rows=list(csv.DictReader(source.open(encoding='utf-8-sig')))
legacy=json.loads((P/'privado/tabla_mica_kpi_auditada.json').read_text())
old={r['clave']:json.loads(r['payload']) for r in legacy}
ids=['MICA-TG-479895069','MICA-TG-479895074','MICA-TG-479895075','MICA-TG-479895082']
summary=[]
for row in rows:
    c=json.loads(row['payload'])
    if row['tipo']=='caso' and c.get('caso_id') in ids:
        assert c['estado']=='registrado_simulado' and c['version']==3
        assert [t['agente'] for t in c['traza']]==['orquestador','A1','A2','A3','A4']
        if c['caso_id']==ids[0]:
            previous=old[row['clave']]
            assert c['plan']==previous['plan'] and c['aprobacion']==previous['aprobacion']
            assert c['recibido_en']==previous['recibido_en']
            for k in ['primera_propuesta_revisada_en','primera_revision_humana_en','aprobado_primera_revision_sin_cambios']:
                assert c.get(k) in [None,previous[k]]
                c[k]=previous[k]
        else:
            assert all(c.get(k) for k in ['recibido_en','primera_propuesta_revisada_en','primera_revision_humana_en'])
            assert c['aprobado_primera_revision_sin_cambios'] is True
            sl=c['traza'][3]['skills_loops'];assert sl['estado']=='pendiente_aprobacion' and len(sl['cargas'])==2
            for skill in sl['cargas']:
                assert hashlib.sha256((P/skill['archivo']).read_bytes()).hexdigest()==skill['sha256']
        summary.append({'caso_id':c['caso_id'],'estado':c['estado'],'version':c['version'],'actividades':len(c['plan']['actividades']),'roles':[t['agente'] for t in c['traza']],'skills_loops':c['traza'][3].get('skills_loops'),'metricas_origen':'reconstruccion_auditada_legado' if c['caso_id']==ids[0] else 'marcas_directas_persistidas'})
    if row['tipo']=='evento' and c.get('caso_id')==ids[0] and c.get('comando')=='/nuevo':
        previous=old[row['clave']]
        assert c['update_id']==previous['update_id']
        c['recibido_en']=previous['recibido_en'];c['completa_al_recibir']=previous['completa_al_recibir']
    row['payload']=json.dumps(c,ensure_ascii=False)
assert {c['caso_id'] for c in summary}==set(ids)
enriched=P/'privado/tabla_mica_ensayo004_kpi.json'
enriched.write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
subprocess.run([sys.executable,str(P/'tools/exportar_panel.py'),str(enriched),'--corte','2026-11-21','--periodo','2026-11','--incluir-casos',*ids,'--solicitudes-completas'],check=True)
public_path=P/'panel/datos.json';d=json.loads(public_path.read_text())
d['fuente']='Cuatro casos ficticios ejecutados y aprobados por la usuaria. Exportación manual sanitizada de n8n; sin conexión de datos en vivo. Tres casos con marcas KPI directas y uno legado reconstruido y auditado.'
d['cobertura']['nota']=f"Censo del piloto autorizado de esta instancia del 16 al 21/11/2026: {len(d['solicitudes'])} solicitudes (incluye entradas incompletas), 4 propuestas y 4 primeras revisiones; excluye usuario interno 0 y la instancia anterior. Comercial, Administración y el ensayo 082 tienen marcas directas. En el primer caso de Tecnología la propuesta se reconstruye como vencimiento menos 24 h y la completitud desde su evento validado; primera aprobación contrastada con su censo y versiones. Los tiempos incluyen espera y recuperación manual. Muestra n=4: no representa todo el mes ni demuestra ahorro o desempeño empresarial."
public_path.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
evidence={'fecha_local':'2026-11-21','filas_fuente':len(rows),'fuente_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'casos':summary,'nota':'Solo metadatos sanitizados y traza determinista; sin usuarios/chats, credenciales ni conversaciones.'}
(P/'evidencias/ensayo004_cierre_casos.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2)+'\n')
print('Cuatro casos persistidos y aprobados; roles, skills y hashes verificados; exportación pública por lista blanca.')
