import json,uuid
from pathlib import Path
P=Path(__file__).resolve().parents[1]
bases={k:json.loads((P/'datos/bases_mica_v1'/f'{k}.json').read_text()) for k in ['catalogos','actividades','politicas','responsables']}
helper=(P/'agentes/herramientas_mica.js').read_text();router=(P/'n8n/telegram_router.js').read_text()
nodes=[];connections={}
def node(name,t,p,x,y,v=1):
 n={'id':str(uuid.uuid4()),'name':name,'type':t,'typeVersion':v,'parameters':p,'position':[x,y]};nodes.append(n);return n
def link(a,b):connections[a]={'main':[[{'node':b,'type':'main','index':0}]]}
creds={'telegramApi':{'id':None,'name':'MICA - Telegram'}}
t=node('Telegram MICA','n8n-nodes-base.telegramTrigger',{'updates':['message'],'additionalFields':{}},0,0,1.2);t['credentials']=creds;t['webhookId']=str(uuid.uuid4())
node('Inicio prueba sin Telegram','n8n-nodes-base.manualTrigger',{},0,260)
fixture={'update_id':900000001,'message':{'from':{'id':0},'chat':{'id':0,'type':'private'},'date':1793836800,'text':'/nuevo DEP-TEC P-TEC-01 2026-11-23 remota'}}
node('Evento sintetico','n8n-nodes-base.code',{'jsCode':'return [{json:'+json.dumps(fixture)+'}];'},220,260,2)
config='''const evento=$input.first().json;
// SOLO ID 0 para pruebas internas. Añadir aquí el ID real autorizado antes de activar.
const permitidos=['0'];
if(!evento.message||!permitidos.includes(String(evento.message.from?.id))||evento.message.chat?.type!=='private')throw Error('USUARIO_NO_AUTORIZADO');
return [{json:{evento,permitidos,bases:BASES}}];'''.replace('BASES',json.dumps(bases,ensure_ascii=False))
node('Validar acceso MICA','n8n-nodes-base.code',{'jsCode':config},460,0,2)
table={'__rl':True,'value':'TFsrcaXd5NnNmESY','mode':'id'}
get=node('Leer registros privados','n8n-nodes-base.dataTable',{'resource':'row','operation':'get','dataTableId':table,'returnAll':True},700,0,1.1);get['alwaysOutputData']=True
code=helper+'\n'+router+"\nconst c=$('Validar acceso MICA').first().json;const registros=$input.all().map(x=>x.json).filter(x=>x.clave);const r=procesarTelegram(c.evento,registros,c.bases,c.permitidos);if(r.duplicado)return [];return r.filas.map(f=>({json:{...f,chat_id:r.chat_id,respuesta:r.respuesta}}));"
node('Enrutar y deduplicar','n8n-nodes-base.code',{'jsCode':code},940,0,2)
schema=[{'id':k,'displayName':k,'required':False,'defaultMatch':False,'display':True,'type':'string','canBeUsedToMatch':True}for k in ['clave','tipo','estado','payload']]
node('Persistir registros MICA','n8n-nodes-base.dataTable',{'resource':'row','operation':'upsert','dataTableId':table,'matchType':'allConditions','filters':{'conditions':[{'keyName':'clave','condition':'eq','keyValue':'={{ $json.clave }}'}]},'columns':{'mappingMode':'defineBelow','value':{k:'={{ $json.'+k+' }}'for k in ['clave','tipo','estado','payload']},'matchingColumns':[],'schema':schema,'attemptToConvertTypes':False,'convertFieldsToString':False},'options':{}},1180,0,1.1)
response="const items=$('Enrutar y deduplicar').all();if(!items.length||Number(items[0].json.chat_id)===0)return [];return [{json:{chat_id:items[0].json.chat_id,respuesta:items[0].json.respuesta}}];"
node('Una respuesta por evento','n8n-nodes-base.code',{'jsCode':response},1420,0,2)
send=node('Responder Telegram','n8n-nodes-base.telegram',{'resource':'message','operation':'sendMessage','chatId':'={{ $json.chat_id }}','text':'={{ $json.respuesta }}','additionalFields':{'appendAttribution':False}},1660,0,1.2);send['credentials']=creds
link('Telegram MICA','Validar acceso MICA');link('Inicio prueba sin Telegram','Evento sintetico');link('Evento sintetico','Validar acceso MICA');link('Validar acceso MICA','Leer registros privados');link('Leer registros privados','Enrutar y deduplicar');link('Enrutar y deduplicar','Persistir registros MICA');link('Persistir registros MICA','Una respuesta por evento');link('Una respuesta por evento','Responder Telegram')
out={'name':'MICA - Telegram y registros v1','nodes':nodes,'connections':connections,'active':False,'settings':{'executionOrder':'v1','timezone':'America/Mexico_City'},'pinData':{},'meta':{}}
(P/'n8n/mica_telegram_registros_v1.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print('Flujo preparado sin IA, inactivo y con acceso real bloqueado hasta configurar ID autorizado.')
