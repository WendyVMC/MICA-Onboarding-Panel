"""Consolida evidencia ya obtenida. No conecta servicios ni llama modelos."""
from pathlib import Path
import json,csv,hashlib,math,datetime
P=Path(__file__).resolve().parents[1]
def read(f):return json.loads((P/f).read_text())
def write(f,v):
 p=P/f;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(v if isinstance(v,str) else json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def csvwrite(f,rows):
 with (P/f).open('w',encoding='utf-8-sig',newline='') as h:
  w=csv.DictWriter(h,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
calls=read('costos/llamadas.json');ids={x['llamada_id'] for x in calls['llamadas']}
for x in read('evidencias/ensayo_clase_004_consumo.json')['llamadas']:
 lid=f"MICA-TG-479895082-{x['rol']}-{x['run']:03}"
 if lid in ids:continue
 calls['llamadas'].append(dict(fecha_hora='2026-11-21T22:46:24-06:00',caso_id='MICA-TG-479895082',llamada_id=lid,etapa='ensayo_clase_004',agente=x['rol'],proveedor='n8n Gateway / OpenAI',modelo='gpt-4o-mini-2024-07-18',tokens_entrada=x['entrada'],tokens_salida=x['salida'],tokens_total=x['total'],tokens_cache=None,duracion_ms=None,duracion_voz_segundos=None,unidad_cobro='tokens',tarifa_ref='N8N-GW-GPT4OMINI-20261121',costo_usd_calculado=round((x['entrada']*.15+x['salida']*.6)/1e6,10),cargo_facturado_observado_usd=None,moneda='USD',estado_tecnico='exito',estado_validacion_negocio='conforme',reintento=0,origen_tokens='tokenUsage_visible_n8n_modelo_y_run_verificados',origen_costo='Calculado; hora de ejecución contenedora, factura no conciliada',evidencia='evidencias/ensayo_clase_004_consumo.json',ejecucion_id=25))
assert len({x['llamada_id'] for x in calls['llamadas']})==42==len(calls['llamadas'])
write('costos/llamadas.json',calls)
rows=list(csv.DictReader((P/'costos.csv').open(encoding='utf-8-sig')));old={r['llamada_id'] for r in rows};cols=list(rows[0])
for x in calls['llamadas']:
 if x['llamada_id'] not in old:rows.append({k:x.get(k,'') if x.get(k) is not None else '' for k in cols})
csvwrite('costos.csv',rows);csvwrite('costos/costos.csv',rows)
s=read('costos/resumen_auditable.json');s.update(corte='2026-11-26',fecha_ultima_medicion='2026-11-21',llamadas_medidas=42,subtotal_llm_n8n_calculado_usd=round(sum(x['costo_usd_calculado'] for x in calls['llamadas']),10))
s['por_caso']['MICA-TG-479895082']={'llamadas':8,'entrada':3209,'salida':1098,'usd_calculado':.00114015}
s['cuatro_casos_completos_llm_usd']=.0046362;s['promedio_llm_por_caso_usd']=.00115905;s['casos_completos']=4
write('costos/resumen_auditable.json',s)
# Recalcular únicamente la parte del escenario que depende de la muestra medida.
complete=[x for x in calls['llamadas'] if x['caso_id'] in ['MICA-TG-479895069','MICA-TG-479895074','MICA-TG-479895075','MICA-TG-479895082']]
tin=sum(x['tokens_entrada'] for x in complete)/4;tout=sum(x['tokens_salida'] for x in complete)/4
sc=read('costos/escenarios.json')
for x in sc:
 unit=s['promedio_llm_por_caso_usd'] if x['escenario']=='base' else (2*tin*.15+1.5*tout*.6)/1e6*1.025
 x['llm_n8n_usd']=round(x['casos_mes']*unit,6)
 x['subtotal_usd']=round(x['llm_n8n_usd']+x['llm_voz_usd']+x['fijo_voz_usd']+x['extra_voz_usd'],6)
 x['total_expresado']='%.2f USD + %.2f EUR/mes'%(x['subtotal_usd'],x['fijo_n8n_eur'])
 x['total_usd_si_eur_usd_1_10_supuesto']=round(x['subtotal_usd']+x['fijo_n8n_eur']*1.1,2)
write('costos/escenarios.json',sc);csvwrite('costos/escenarios.csv',sc)
method=(P/'costos/RESUMEN_Y_METODO.md').read_text().replace('**34 llamadas','**42 llamadas').replace('USD 0.00503595','USD 0.00617610').replace('Los tres casos completos suman USD 0.00349605; promedio USD 0.00116535/caso.','Los cuatro casos completos suman USD 0.00463620; promedio USD 0.00115905/caso.').replace('Los tres casos completos suman USD 0.00349605','Los cuatro casos completos suman USD 0.00463620')
method+='\n\n## Consolidación del 26/11/2026\n\nSe incorporaron una sola vez las ocho llamadas del ensayo 082 (USD 0.00114015 calculados). El total Gateway conocido es USD 0.00617610; 42 llamadas. La conversación de voz medida sigue siendo una; la voz del ensayo 082 y la prueba completa se reservan para la presentación. Los saldos y tarifas conservan su fecha histórica de observación; no se verificaron en vivo el 26/11. La estimación de desarrollo se detalla en DESARROLLO_ESTIMACION.md y no se suma a los cargos medidos.\n'
write('costos/RESUMEN_Y_METODO.md',method)
# Proxy de esfuerzo de desarrollo: inventario reproducible, no consumo atribuido al proveedor.
files=[];seen=set()
for folder in ['agentes','skills','loops','runtime','panel']:
 for f in sorted((P/folder).rglob('*')):
  if f.suffix not in ['.md','.js','.html','.css'] or '_qa' in str(f):continue
  b=f.read_bytes();h=hashlib.sha256(b).hexdigest()
  if h in seen:continue
  seen.add(h);files.append({'archivo':str(f.relative_to(P)),'caracteres':len(b.decode()),'sha256':h})
chars=sum(f['caracteres'] for f in files);tlow=math.ceil(chars/5);thigh=math.ceil(chars/3)
estimate={'fecha':'2026-11-26','tipo':'proxy_reproducible_de_contenido_no_telemetria_de_uso','archivos':files,'caracteres_unicos':chars,'tokens_salida_equivalentes_intervalo':[tlow,thigh],'supuesto':'3 a 5 caracteres por token como sensibilidad; no tokenizador del modelo del asistente','entrada_supuesto_multiplos_salida':[1,3],'tarifa_equivalente_usd_millon':{'entrada':.15,'salida':.6,'nota':'Escenario con tarifa histórica de gpt-4o-mini Gateway, no precio del asistente de desarrollo'},'costo_equivalente_intervalo_usd':[(tlow*.15+tlow*.6)/1e6,(3*thigh*.15+thigh*.6)/1e6],'no_estima_confiablemente':'Historial de prompts, respuestas descartadas, caché, modelo/plan real y cargos acumulados','cargo_desarrollo_real':None,'sumar_al_consumo_medido':False}
write('costos/desarrollo_estimacion.json',estimate)
write('costos/DESARROLLO_ESTIMACION.md',f'''# Desarrollo: estimación y límites

No hay telemetría del consumo ni factura del asistente. Se inventarían resultados si se afirmara una cifra de tokens efectivamente usados. Para aportar una sensibilidad reproducible se contaron {chars:,} caracteres únicos de {len(files)} archivos primarios de agentes, skills, loops, runtime e interfaz; se excluyeron bundles duplicados, exportaciones compiladas y capturas.

Suponiendo entre 3 y 5 caracteres por token, el contenido equivale aproximadamente a {tlow:,}–{thigh:,} tokens de salida. Es un **proxy del contenido final**, no una estimación fiable del total de la conversación. Como escenario, entradas de 1–3 veces esa salida y tarifa histórica equivalente de gpt-4o-mini 0.15/0.60 USD por millón producen USD {estimate['costo_equivalente_intervalo_usd'][0]:.6f}–{estimate['costo_equivalente_intervalo_usd'][1]:.6f}. No se afirma que el asistente haya usado ese modelo o esa tarifa.

No se suman estas cifras a consumos medidos ni se concilian contra la recarga de USD 5. Historial omitido y correcciones pueden elevar sustancialmente el uso. El inventario y las fórmulas están en desarrollo_estimacion.json. Para un cargo real hacen falta proveedor, plan y reporte de uso; el dato permanece desconocido, nunca cero.
''')
# Estado vigente, sin borrar el registro histórico de configuración.
f=P/'agentes/README.md';t=f.read_text();t=t.replace('Estado: instrucciones y contratos preparados; ejecución de los cinco roles pendiente. Guardar estos archivos no acredita agentes operativos.','Estado consolidado 26/11/2026: cinco roles ejecutados y trazados en cuatro casos completos (069, 074, 075 y 082). Evidencias en lote003_cierre_casos.json y ensayo004_cierre_casos.json. Orquestador determinista y cuatro especialistas gpt-4o-mini; generación apagada al cierre. Los apartados de selección inicial de nodos describen el diseño histórico, no la configuración vigente.');t=t.replace('Los cuatro especialistas deberán ejecutarse de manera verificable en los casos completos.','Los cuatro especialistas se ejecutaron en los casos completos registrados.');write('agentes/README.md',t)
v=read('voz/configuracion_guardada.json');v['estado']='REGISTRO_HISTORICO_DEL_2026_11_16_NO_CONFIGURACION_ACTUAL';v['referencia_vigente']='voz/CONFIGURACION_ACTUAL.md';write('voz/configuracion_guardada.json',v)
write('voz/CONFIGURACION_ACTUAL.md','''# Configuración vigente documentada

Consolidación 26/11/2026; última configuración observada 21/11, sin revisión de servicio en vivo hoy. Agente público MICA, español, voz Eric, DeepSeek Flash 4.1, consentimiento antes de herramientas. Un folio ficticio permitido: **MICA-TG-479895082**. Herramientas consultar_caso y solicitar_revision con POST /webhook/mica-voz-v1 y Header Auth x-mica-key. La contraseña se mantiene solo en almacenes de secretos.

Servidor, enum de ambas herramientas y folio del panel se cambiaron del 069 al 082. Consulta manual autenticada del 082 devolvió registrado_simulado v3. La conversación real histórica corresponde al 069: 831 créditos, dos herramientas exitosas. No se acredita todavía una conversación del 082. Límites documentados: 60 s, silencio 20 s, tres llamadas diarias y una simultánea. No se atribuyen saldos del 21/11 al día actual.

Para recrear: usar instrucciones_mica.md, base_conocimiento_mica.md y esquemas de herramientas; volver a vincular credenciales. El archivo configuracion_guardada.json es histórico. La voz del ensayo y disponibilidad se verifican en presentación.
''')
for f in ['voz/servicio_casos.js','voz/consultar_caso_pendiente_auth.json','voz/solicitar_revision_pendiente_auth.json']:
 write(f,(P/f).read_text().replace('MICA-TG-479895069','MICA-TG-479895082'))
v=read('n8n/mica_voz_herramientas_borrador.json')
for n in v['nodes']:
 if n['name']=='Procesar solicitud de voz':n['parameters']['jsCode']=(P/'privado/ensayo_voz_Procesar_solicitud_de_voz.js').read_text()
write('n8n/MICA_Voz_Consolidado.json',v)
write('docs/ESTADO_VIGENTE.md','''# Estado de entrega consolidada · 26/11/2026

La medición operativa conservada termina el 21/11/2026. Hay cuatro casos aprobados, 33 actividades y 42 llamadas medidas de modelos, USD 0.00617610 calculados. Preparación media 0.082243 h/caso, completitud 4/5=80%, aprobación inicial 4/4=100%. Tres casos con marcas directas y uno legado reconstruido y auditado. Las cifras no prueban ahorro ni representatividad.

La conversación de voz real histórica consultó el 069. El único folio de voz actual documentado es el 082; consulta autenticada probada sin audio. Su conversación y el ensayo completo se reservan para clase. IA apagada, ocho llamadas por caso y USD 0.05 en la exportación final del ensayo. Nada de esto acredita disponibilidad o saldo actual del servicio.

El video de 6:55 conserva el recorrido original de tres casos, anterior al ensayo 082. Es respaldo histórico; el informe, CSV y panel consolidan el cuarto caso. No se altera una grabación para aparentar una ejecución no realizada. Documentos de auditoría y configuraciones antiguas se conservan con fecha y no sustituyen este estado.

Para considerar completada la evaluación faltan la publicación autorizada de este paquete, la verificación de disponibilidad y acceso y la defensa de Wendy. Las pruebas locales/controladas mantienen sus rótulos. No se certifica una nota de 100 puntos.
''')
manual=(P/'docs/MANUAL_REPRODUCCION.md').read_text();manual+='''\n\n## Cierre consolidado y presentación\n\nExportación principal final: límite USD 0.05, ocho llamadas, reservas de USD 0.0125 por especialista. Si se ajusta el límite, hacerlo en Orquestador y en las cuatro reservas; comprobar el total antes de habilitar un nuevo folio. Los modelos conservan 1800 tokens de salida, timeout 30s y retry 0. No reutilizar el folio 082 para generar de nuevo. Su consulta sigue disponible si la instancia está activa.\n\nEn una copia importada, crear credenciales y reemplazar el ID autorizado; no compartir el token del bot. Para la docente: acceso bajo supervisión de Wendy por el canal privado del curso, o credenciales propias en una importación. La voz solo consulta un folio ficticio. Antes de clase revisar vigencia, cuotas y fechas. Si ha expirado n8n, detener y resolver el hosting con autorización, sin recargas automáticas. La prueba completa se hace una sola vez, después de autorización específica del presupuesto y de comprobar el saldo.\n''';write('docs/MANUAL_REPRODUCCION.md',manual)
print('Consolidación local: 42 llamadas únicas, cuatro casos, esquemas de voz 082 y documentación vigente. Sin APIs.')
