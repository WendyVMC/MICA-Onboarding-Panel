"""Prepara un export inactivo; no conecta servicios ni llama modelos."""
import json,uuid
from pathlib import Path
P=Path(__file__).resolve().parents[1]
router=(P/'n8n/telegram_router.js').read_text().replace('let respuesta,caso=null;','let respuesta,caso=null,generar=false;')
a="  }else if(cmd==='/aprobar'||cmd==='/rechazar')respuesta='La aprobación todavía no está habilitada en este flujo. Ningún plan se registró como definitivo.';"
b="""  }else if(['/generar','/aprobar','/rechazar'].includes(cmd)){
    if(parts.length!==2||!/^MICA-[A-Za-z0-9-]{1,80}$/.test(parts[0])||!/^\\d+$/.test(parts[1]))respuesta='Usa '+cmd+' FOLIO VERSION. Consulta primero /estado FOLIO.';
    else{const row=registros.find(x=>x.clave==='CASO-'+parts[0]&&x.tipo==='caso');
      try{if(!row)throw Error('CASO_NO_ENCONTRADO');caso=operarCaso(JSON.parse(row.payload),m.from.id,cmd.slice(1),Number(parts[1]));generar=cmd==='/generar';respuesta='Folio '+caso.caso_id+' · Estado: '+caso.estado.replace(/_/g,' ')+' · Versión: '+caso.version+' · Simulado.';}
      catch(err){caso=null;respuesta='Acción bloqueada: '+err.message+'. Consulta /estado FOLIO.';}
    }
  }"""
assert a in router
b=b.replace("caso=operarCaso(JSON.parse(row.payload)","if(cmd==='/generar'&&!habilitarIA)throw Error('IA_PENDIENTE_AUTORIZACION');caso=operarCaso(JSON.parse(row.payload)")
router=router.replace('bases,permitidos){','bases,permitidos,habilitarIA=false){')
router=router.replace(a,b).replace('chat_id:m.chat.id};\n}', 'chat_id:m.chat.id,generar,caso};\n}')
router=router.replace('Esta etapa registra solicitudes; el procesamiento por agentes aún no está activado.','Genera una propuesta con /generar FOLIO VERSION. Después usa /aprobar FOLIO VERSION o /rechazar FOLIO VERSION. Todo es simulado.')
(P/'n8n/telegram_router_v2.js').write_text(router)
w=json.loads((P/'n8n/mica_telegram_registros_v1.json').read_text());g=json.loads((P/'n8n/mica_ecosistema_agentes_v1.json').read_text())
ns={n['name']:n for n in w['nodes']};old=ns['Enrutar y deduplicar']['parameters']['jsCode'];helper=old.split('// Adaptador Telegram:')[0]
cycle=(P/'n8n/ciclo_caso.js').read_text()
ns['Enrutar y deduplicar']['parameters']['jsCode']=helper+'\n'+cycle+'\n'+router+"\nconst c=$('Validar acceso MICA').first().json;const registros=$input.all().map(x=>x.json).filter(x=>x.clave);const HABILITAR_IA=false;const CASO_AUTORIZADO='MICA-TG-479895066';if(c.evento.message.text.trim().startsWith('/generar ')&&!c.evento.message.text.includes(CASO_AUTORIZADO+' '))throw Error('CASO_FUERA_DEL_LOTE_AUTORIZADO');const r=procesarTelegram(c.evento,registros,c.bases,c.permitidos,HABILITAR_IA);if(r.duplicado)return [];return r.filas.map(f=>({json:{...f,chat_id:r.chat_id,respuesta:r.respuesta,generar:r.generar,caso:r.caso}}));"
def node(name,t,p):
 n={'id':str(uuid.uuid4()),'name':name,'type':t,'typeVersion':2,'parameters':p,'position':[1700,500]};w['nodes'].append(n);return n
def link(a,b):w['connections'][a]={'main':[[{'node':b,'type':'main','index':0}]]}
# Gate local: each complete pass requires an explicit switch; default closed.
node('Preparar caso para agentes','n8n-nodes-base.code',{'jsCode':"const r=$('Enrutar y deduplicar').first().json;if(!r.generar)return [];const acceso=$('Validar acceso MICA').first().json;return [{json:{...r.caso,datos:r.caso.datos,bases:acceso.bases,canal:'telegram'}}];"})
# Original response branch stays; processing branch is additional and closed by default.
w['connections']['Persistir registros MICA']['main'][0].append({'node':'Preparar caso para agentes','type':'main','index':0})
for n in g['nodes']:
 if n['name'] in ['Inicio manual','Caso sintetico']:continue
 if n['name']=='Orquestador':
  code=n['parameters']['jsCode'];code=code.replace("c.caso_id='MICA-'+String($execution.id).padStart(6,'0');","if(!/^MICA-TG-\\d+$/.test(c.caso_id)||c.estado!=='procesando')throw Error('CONTEXTO_TELEGRAM_INVALIDO');")
  code=code.replace("c.canal='prueba_manual'","c.canal='telegram'");n['parameters']['jsCode']=code
 w['nodes'].append(n)
for name,conn in g['connections'].items():
 if name not in ['Inicio manual','Caso sintetico']:w['connections'][name]=conn
link('Preparar caso para agentes','Orquestador')
node('Guardar propuesta del mismo caso','n8n-nodes-base.code',{'jsCode':cycle+"\nconst c=$('Preparar caso para agentes').first().json;const p=guardarPropuesta(c,$input.first().json);return [{json:{clave:'CASO-'+p.caso_id,tipo:'caso',estado:p.estado,payload:JSON.stringify(p),chat_id:p.chat_id,respuesta:'Propuesta simulada: '+p.caso_id+' · Versión '+p.version+' · '+p.plan.actividades.length+' actividades. Detalle: '+p.plan.actividades.map(a=>a.actividad_id+' | '+a.fecha+' | Responsable '+a.responsable_id+' | Regla '+a.regla_id).join('; ')+' · Requiere revisión RH: '+p.plan.requiere_revision_fechas+'. Aprobar: /aprobar '+p.caso_id+' '+p.version+' · Rechazar: /rechazar '+p.caso_id+' '+p.version+' · Vigencia 24 horas.'}}];"})
link('Resultado provisional','Guardar propuesta del mismo caso')
persist=json.loads(json.dumps(ns['Persistir registros MICA']));persist.update(id=str(uuid.uuid4()),name='Persistir propuesta',position=[3600,500]);w['nodes'].append(persist);link('Guardar propuesta del mismo caso','Persistir propuesta')
node('Respuesta propuesta','n8n-nodes-base.code',{'jsCode':"const r=$('Guardar propuesta del mismo caso').first().json;if(Number(r.chat_id)===0)return [];return [{json:r}];"});link('Persistir propuesta','Respuesta propuesta');link('Respuesta propuesta','Responder Telegram')
# Failures retain the case and explicitly prevent approval; no automatic retry.
node('Fallo controlado agentes','n8n-nodes-base.code',{'jsCode':"const c=$('Preparar caso para agentes').first().json;const p={...c,bases:undefined,estado:'error_controlado',version:c.version+1,plan:null,aprobacion:null,error:'No se obtuvo una propuesta verificable. Revisar ejecución antes de reintentar.'};return [{json:{clave:'CASO-'+p.caso_id,tipo:'caso',estado:p.estado,payload:JSON.stringify(p),chat_id:p.chat_id,respuesta:'Folio '+p.caso_id+' · Error controlado. No se aprobó ni registró ningún plan. Revisar ejecución antes de reintentar.'}}];"})
for n in w['nodes']:
 if n['name'] in ['Orquestador','Resultado provisional'] or n['name'].startswith(('Reserva ','Control ')) or n['type']=='@n8n/n8n-nodes-langchain.agent':
  n['onError']='continueErrorOutput'
  w['connections'].setdefault(n['name'],{}).setdefault('main',[[]]).append([{'node':'Fallo controlado agentes','type':'main','index':0}])
failpersist=json.loads(json.dumps(persist));failpersist.update(id=str(uuid.uuid4()),name='Persistir fallo',position=[3600,800]);w['nodes'].append(failpersist);link('Fallo controlado agentes','Persistir fallo')
node('Respuesta fallo','n8n-nodes-base.code',{'jsCode':"const r=$('Fallo controlado agentes').first().json;if(Number(r.chat_id)===0)return [];return [{json:r}];"});link('Persistir fallo','Respuesta fallo');link('Respuesta fallo','Responder Telegram')
w.update(name='MICA - Integracion y aprobacion BORRADOR',active=False)
(P/'n8n/mica_integrado_borrador.json').write_text(json.dumps(w,ensure_ascii=False,indent=2)+'\n')
print('Borrador inactivo preparado; IA bloqueada. No importado ni publicado.')
