"""Exportación manual sanitizada. Lee JSON/CSV descargado de MICA_registros; no usa APIs."""
import argparse,csv,json
from pathlib import Path
from datetime import datetime,timezone
P=Path(__file__).resolve().parents[1]
a=argparse.ArgumentParser();a.add_argument('entrada',type=Path);a.add_argument('--salida',type=Path,default=P/'panel/datos.json');a.add_argument('--corte',required=True,help='AAAA-MM-DD de la exportación real');a.add_argument('--periodo',required=True,help='AAAA-MM');a.add_argument('--incluir-casos',nargs='+',required=True,help='Lista explícita de folios ficticios autorizados para publicación');a.add_argument('--solicitudes-completas',action='store_true',help='Usar solo si se verificó censo de todos los eventos /nuevo del periodo, con etiquetas de validación');args=a.parse_args()
datetime.strptime(args.corte,'%Y-%m-%d');datetime.strptime(args.periodo,'%Y-%m')
rows=list(csv.DictReader(args.entrada.open())) if args.entrada.suffix.lower()=='.csv' else json.loads(args.entrada.read_text())
if isinstance(rows,dict):rows=rows.get('registros',rows.get('data',[rows]))
if not isinstance(rows,list):raise ValueError('Se requiere arreglo de registros')
bases={k:json.loads((P/'datos/bases_mica_v1'/f'{k}.json').read_text())for k in ['catalogos','actividades']};titles={x['actividad_id']:x['titulo']for x in bases['actividades']['registros']}
casos=[];solicitudes=[];eventos_nuevo=0;eventos_sin_medicion=0
for row in rows:
 row=row.get('json',row)
 try:r=json.loads(row['payload']) if isinstance(row.get('payload'),str) else row.get('payload',row)
 except (ValueError,TypeError):raise ValueError('Payload inválido; no se publica exportación parcial silenciosa')
 if row.get('tipo')=='evento' and r.get('comando')=='/nuevo':
  # Los eventos sintéticos internos no forman parte del censo de canal real.
  if str(r.get('usuario_id'))=='0':continue
  eventos_nuevo+=1
  if isinstance(r.get('completa_al_recibir'),bool) and r.get('recibido_en'):
   solicitudes.append({'solicitud_id':'SOL-TG-'+str(r['update_id']),'recibido_en':r['recibido_en'],'completa_al_recibir':r['completa_al_recibir']})
  else:eventos_sin_medicion+=1
 if r.get('caso_id') not in args.incluir_casos or row.get('tipo') not in [None,'caso']:continue
 if r.get('modo')!='SIMULADO':raise ValueError('Se rechaza un caso no simulado')
 datos=r['datos'];dep=next(x['nombre']for x in bases['catalogos']['departamentos']if x['departamento_id']==datos['departamento_id']);metricas={k:r.get(k) for k in ['recibido_en','primera_propuesta_revisada_en','primera_revision_humana_en','aprobado_primera_revision_sin_cambios']}
 # La decisión vigente no demuestra por sí sola el resultado de la primera revisión humana.
 if metricas['primera_revision_humana_en'] is None or metricas['aprobado_primera_revision_sin_cambios'] is None:metricas['primera_revision_humana_en']=None;metricas['aprobado_primera_revision_sin_cambios']=None
 fecha=r.get('fecha_recepcion_local')
 if not fecha and r.get('recibido_en'):
  from zoneinfo import ZoneInfo
  fecha=datetime.fromisoformat(r['recibido_en'].replace('Z','+00:00')).astimezone(ZoneInfo('America/Mexico_City')).date().isoformat()
 if not fecha:raise ValueError('Falta fecha de recepción del caso; completar fuente antes de exportar')
 acts=[]
 for x in (r.get('plan')or{}).get('actividades',[]):
  # Lista blanca; no se copian filas ni trazas completas.
  acts.append({**{k:x[k]for k in ['actividad_id','fecha','responsable_id','regla_id','fuente_version','vencida_al_recibir']},'titulo':titles[x['actividad_id']]})
 casos.append({'caso_id':r['caso_id'],'departamento':dep,'modalidad':datos['modalidad'],'estado':r['estado'],'version':r['version'],'actividades':acts,'solicitud':{k:datos[k]for k in ['departamento_id','puesto_id','fecha_ingreso','modalidad','tipo_incorporacion','responsable_rh_id']},'fecha_recepcion_local':fecha,'metricas':metricas})
if set(args.incluir_casos)!={c['caso_id']for c in casos}:raise ValueError('No se encontraron todos los folios autorizados')
if args.solicitudes_completas and eventos_sin_medicion:raise ValueError('No se puede afirmar cobertura completa: eventos sin medición inicial')
completa=args.solicitudes_completas and eventos_sin_medicion==0
out={'actualizado':args.corte,'fuente':'Exportación manual sanitizada del registro privado n8n. No es conexión en vivo.','casos':casos,'version_esquema':'2.0.0','zona_horaria':'America/Mexico_City','periodo_default':args.periodo,'cobertura':{'solicitudes_completa':completa,'nota':'Solo casos ficticios de la lista explícita. '+('Censo de solicitudes declarado completo por el operador.' if completa else 'Cobertura de solicitudes parcial; completitud no calculable. Marcas no registradas permanecen nulas.')},'solicitudes':solicitudes}
# El JSON se valida con herramientas del proyecto antes de reemplazar el archivo público.
import subprocess,tempfile
with tempfile.TemporaryDirectory() as tmp:
 dst=Path(tmp);(dst/'datos.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
 # Validación de datos con Node sin red; no se requiere copiar el resto del sitio.
 script="const fs=require('fs');const {validar}=require('./tools/validar_panel');const b=Object.fromEntries(['catalogos','actividades','politicas','responsables'].map(k=>[k,JSON.parse(fs.readFileSync('datos/bases_mica_v1/'+k+'.json'))]));validar(JSON.parse(fs.readFileSync(process.argv[1])),b);"
 subprocess.run(['node','-e',script,str(dst/'datos.json')],cwd=P,check=True)
 args.salida.parent.mkdir(parents=True,exist_ok=True);args.salida.write_text((dst/'datos.json').read_text())
print('Exportación sanitizada validada; casos:',len(casos),'· No se publicaron IDs privados, aprobación detallada, bases completas ni conversaciones.')
