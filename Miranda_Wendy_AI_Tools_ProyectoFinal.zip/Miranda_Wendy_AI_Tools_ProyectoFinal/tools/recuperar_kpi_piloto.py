"""Reconstrucción auditada SOLO del piloto legado; no modifica n8n ni llama APIs.

No aplicar a otros casos: requiere el censo completo y el flujo de primera
propuesta con vencimiento fijo de 24 h, sin reapertura ni sustitución del plan.
"""
import csv, hashlib, json
from datetime import datetime, timedelta
from pathlib import Path

P = Path(__file__).resolve().parents[1]
source = P / 'privado/tabla_mica_2026-11-19.csv'
rows = list(csv.DictReader(source.open(encoding='utf-8-sig')))
assert len(rows) == 9, 'El censo cambió: repetir auditoría antes de reconstruir'
items = [(r, json.loads(r['payload'])) for r in rows]
cases = [c for r, c in items if r['tipo'] == 'caso' and str(c.get('usuario_id')) != '0']
assert len(cases) == 1
c = cases[0]
assert c['caso_id'] == 'MICA-TG-479895069'
events = [e for r, e in items if r['tipo'] == 'evento' and str(e.get('usuario_id')) != '0']
new = [e for e in events if e['comando'] == '/nuevo']
reviews = [e for e in events if e['comando'] in ['/aprobar', '/rechazar']]
assert len(new) == len(reviews) == 1
assert new[0]['caso_id'] == reviews[0]['caso_id'] == c['caso_id']
assert reviews[0]['comando'] == '/aprobar'
assert c['estado'] == 'registrado_simulado' and c['version'] == 3
assert c['plan']['version_propuesta'] == 1
assert c['aprobacion']['accion'] == 'aprobar' and c['aprobacion']['version_aprobada'] == 2
assert c['revision']['dictamen'] == 'conforme'
assert len(c['plan']['actividades']) == 8
assert not c['plan'].get('requiere_revision_fechas')
# guardarPropuesta fija vence_en = ahora + 86400000 ms. La ejecución recuperada
# guardó una sola propuesta válida, versión 2; la revisión humana pasó a v3.
parse = lambda t: datetime.fromisoformat(t.replace('Z', '+00:00'))
proposal = parse(c['vence_en']) - timedelta(hours=24)
receipt, approval = parse(c['recibido_en']), parse(c['aprobacion']['fecha'])
assert receipt <= proposal <= approval < parse(c['vence_en'])
c['primera_propuesta_revisada_en'] = proposal.isoformat(timespec='milliseconds').replace('+00:00', 'Z')
c['primera_revision_humana_en'] = c['aprobacion']['fecha']
c['aprobado_primera_revision_sin_cambios'] = True
# El router crea caso_id únicamente después de validarSolicitud. Censo: una
# solicitud real autorizada, sin duplicados; el evento interno usuario 0 se excluye.
new[0]['recibido_en'] = c['recibido_en']
new[0]['completa_al_recibir'] = True
for row, payload in items:
    row['payload'] = json.dumps(payload, ensure_ascii=False)
(P / 'privado/tabla_mica_kpi_auditada.json').write_text(json.dumps(rows, ensure_ascii=False, indent=2))
evidence = {
    'caso_id': c['caso_id'], 'corte': '2026-11-19',
    'fuente_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
    'alcance': 'Censo del piloto autorizado de esta instancia; no representa toda la empresa ni el mes completo.',
    'filas_fuente': len(rows), 'solicitudes_canal': len(new), 'revisiones_humanas': len(reviews),
    'recibido_en': c['recibido_en'],
    'primera_propuesta_revisada_en': c['primera_propuesta_revisada_en'],
    'primera_revision_humana_en': c['primera_revision_humana_en'],
    'preparacion_horas': (proposal-receipt).total_seconds()/3600,
    'metodo': {
        'recepcion': 'Marca persistida de Telegram.',
        'propuesta': 'Reconstruida: vencimiento menos 24 horas según guardarPropuesta. Incluye recuperación manual del fallo A3; no es latencia pura de IA.',
        'completitud': 'Reconstruida desde evento /nuevo vinculado a caso validado; censo de la instancia sin eventos internos.',
        'primera_revision': 'Fecha persistida y único evento /aprobar, versión de propuesta 1, transición 2 a 3; sin rechazo ni reapertura en este censo.'
    },
    'limite': 'Muestra n=1. No demuestra ahorro, eficacia empresarial ni operación continua. No extrapolar estos porcentajes.'
}
(P / 'evidencias/kpis_piloto_auditados.json').write_text(json.dumps(evidence, ensure_ascii=False, indent=2)+'\n')
print('Piloto auditado: 1 solicitud y 1 primera revisión; archivo público se genera por lista blanca.')

# Exportar por la misma lista blanca y validación semántica del sitio.
import subprocess, sys
subprocess.run([sys.executable, str(P/'tools/exportar_panel.py'), str(P/'privado/tabla_mica_kpi_auditada.json'), '--corte', '2026-11-19', '--periodo', '2026-11', '--incluir-casos', c['caso_id'], '--solicitudes-completas'], check=True)
public_path = P/'panel/datos.json'
public = json.loads(public_path.read_text())
public['fuente'] = 'Piloto simulado n=1; exportación manual sanitizada de n8n. KPIs reconstruidos y auditados, no conexión en vivo.'
public['cobertura']['nota'] = 'Censo del piloto autorizado de esta instancia hasta el 19/11/2026: 1 solicitud, 1 propuesta y 1 primera revisión. Propuesta reconstruida como vencimiento menos 24 h; incluye recuperación manual del fallo A3. Completitud reconstruida desde el caso validado y su evento. Aprobación contrastada con el único evento de revisión y versiones 1/2/3. No representa el mes completo ni el rendimiento de la empresa; n=1 no permite generalizar.'
public_path.write_text(json.dumps(public, ensure_ascii=False, indent=2)+'\n')
