const fs=require('fs'),path=require('path'),assert=require('assert');
const P=path.resolve(__dirname,'..'),D=path.join(P,'datos/bases_mica_v1');
const load=f=>JSON.parse(fs.readFileSync(path.join(D,f),'utf8'));
const t=require('../agentes/herramientas_mica.js');
const bases=Object.fromEntries(['catalogos','actividades','politicas','responsables'].map(k=>[k,load(k+'.json')]));
let checks=0;function check(fn){fn();checks++;}
const fixtures=load('casos_prueba.json').registros;
for(const f of fixtures){if(f.tipo==='valido')check(()=>assert.deepStrictEqual(t.validarSolicitud(f.entrada,bases),f.entrada));else check(()=>assert.throws(()=>t.validarSolicitud(f.entrada,bases)));}
for(const j of bases.catalogos.puestos)for(const m of bases.catalogos.modalidades){
  const c={caso_id:'MICA-LOCAL-001',datos:{...fixtures[0].entrada,departamento_id:j.departamento_id,puesto_id:j.puesto_id,modalidad:m},bases,fecha_recepcion_local:'2026-11-04',resultados:{}};
  check(()=>{const a=t.recuperarFuentes(c).actividades;assert.strictEqual(a.length,m==='hibrida'?9:8);assert.strictEqual(new Set(a.map(x=>x.actividad_id)).size,a.length);});
  for(const r of ['A1','A2','A3','A4'])check(()=>{const res=t.resultadoRol(r,c);const out=t.validarSalida(r,{caso_id:c.caso_id,agente:r,estado:'ok',resultado:res},c);c.resultados[r]=out.resultado;});
  check(()=>assert.strictEqual(c.resultados.A4.registro_definitivo_permitido,false));
  const damaged=structuredClone(c);damaged.resultados.A3.actividades[0].fecha='2026-01-01';check(()=>assert.throws(()=>t.resultadoRol('A4',damaged)));
}
const c={caso_id:'MICA-LOCAL-002',datos:fixtures[0].entrada,bases,fecha_recepcion_local:'2026-11-23',resultados:{}};
check(()=>{const plan=t.calcularPlan(c);assert(plan.requiere_revision_fechas);assert(plan.actividades.find(a=>a.actividad_id==='ACT-G01').vencida_al_recibir);assert.strictEqual(plan.actividades.find(a=>a.actividad_id==='ACT-G01').fecha,'2026-11-20');});
check(()=>assert.throws(()=>t.validarSalida('A1',{caso_id:c.caso_id,agente:'A1',estado:'ok',resultado:{solicitud_validada:true}},c)));
check(()=>assert.throws(()=>t.validarSalida('A1',{caso_id:'otro',agente:'A1',estado:'ok',resultado:t.resultadoRol('A1',c)},c)));
const w=JSON.parse(fs.readFileSync(path.join(P,'n8n/mica_ecosistema_agentes_v1.json'),'utf8'));
check(()=>assert.strictEqual(w.active,false));
check(()=>assert.strictEqual(w.nodes.filter(n=>n.type.endsWith('.agent')).length,4));
check(()=>assert.strictEqual(w.nodes.filter(n=>n.type.endsWith('.toolCode')).length,4));
for(const n of w.nodes){
 if(n.type.endsWith('.code'))check(()=>new Function('$input','$','$execution',n.parameters.jsCode));
 if(n.type.endsWith('.toolCode'))check(()=>new Function('$','query',n.parameters.jsCode));
 if(n.type.endsWith('.lmChatOpenAi'))check(()=>{assert(n.credentials.openAiApi.__aiGatewayManaged);assert.strictEqual(n.parameters.options.maxRetries,0);assert(n.parameters.options.maxTokens<=1800);});
}
const report={resultado:'APROBADO_LOCAL',controles:checks,cobertura_puesto_modalidad:18,alcance:'Funciones deterministas, sintaxis y grafo. No acredita importacion o ejecucion real n8n ni llamadas IA.',fecha:'2026-11-04'};
fs.writeFileSync(path.join(P,'agentes/validacion_herramientas_local.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));
