// Funciones deterministas reutilizables en Code nodes y Code Tools de n8n.
function validarSolicitud(datos, bases) {
  const campos=['departamento_id','puesto_id','fecha_ingreso','modalidad','tipo_incorporacion','responsable_rh_id'];
  if(!datos||typeof datos!=='object'||Array.isArray(datos))throw Error('SOLICITUD_INVALIDA');
  if(Object.keys(datos).some(k=>!campos.includes(k)))throw Error('CAMPO_NO_PERMITIDO');
  if(campos.some(k=>typeof datos[k]!=='string'||!datos[k].trim()))throw Error('DATOS_INCOMPLETOS');
  const c=bases.catalogos,puesto=c.puestos.find(x=>x.puesto_id===datos.puesto_id);
  if(!puesto||puesto.departamento_id!==datos.departamento_id)throw Error('PUESTO_DEPARTAMENTO_INVALIDO');
  if(!c.modalidades.includes(datos.modalidad)||!c.tipos_incorporacion.includes(datos.tipo_incorporacion))throw Error('FUERA_DE_CATALOGO');
  if(!/^\d{4}-\d{2}-\d{2}$/.test(datos.fecha_ingreso))throw Error('FECHA_INVALIDA');
  const fecha=new Date(datos.fecha_ingreso+'T12:00:00Z');
  if(!Number.isFinite(fecha.getTime())||fecha.toISOString().slice(0,10)!==datos.fecha_ingreso)throw Error('FECHA_INVALIDA');
  const r=bases.responsables.registros.find(x=>x.responsable_id===datos.responsable_rh_id);
  if(!r||!r.activo||r.rol!=='Coordinación People & Culture')throw Error('RESPONSABLE_RH_INVALIDO');
  return {...datos};
}
function recuperarFuentes(c) {
  const d=c.datos,b=c.bases;
  const a=b.actividades.registros.filter(x=>(x.departamento_id===null||x.departamento_id===d.departamento_id)&&(x.puesto_id===null||x.puesto_id===d.puesto_id)&&x.modalidades.includes(d.modalidad));
  if(!a.length)throw Error('FUENTES_INSUFICIENTES');
  for(const x of a){
    if(!b.politicas.registros.some(r=>r.regla_id===x.regla_id)||x.fuente_version!=='1.0.0')throw Error('REFERENCIA_INVALIDA');
    const r=b.responsables.registros.find(r=>r.responsable_id===x.responsable_id);
    if(!r||!r.activo||!['TRANSVERSAL',d.departamento_id].includes(r.departamento_id))throw Error('RESPONSABLE_ACTIVIDAD_INVALIDO');
  }
  return {version_fuentes:'1.0.0',actividades:a.map(x=>({actividad_id:x.actividad_id,titulo:x.titulo,desfase_dias:x.desfase_dias,responsable_id:x.responsable_id,regla_id:x.regla_id}))};
}
function calcularPlan(c) {
  const fuente=recuperarFuentes(c);
  const day=new Date(c.datos.fecha_ingreso+'T12:00:00Z');
  return {version_propuesta:1,modo:'SIMULADO',actividades:fuente.actividades.map(a=>{
    const d=new Date(day);d.setUTCDate(d.getUTCDate()+a.desfase_dias);const fecha=d.toISOString().slice(0,10);
    return {actividad_id:a.actividad_id,fecha,responsable_id:a.responsable_id,regla_id:a.regla_id,fuente_version:fuente.version_fuentes,vencida_al_recibir:fecha<c.fecha_recepcion_local};
  }),requiere_revision_fechas:fuente.actividades.some(a=>{const d=new Date(day);d.setUTCDate(d.getUTCDate()+a.desfase_dias);return d.toISOString().slice(0,10)<c.fecha_recepcion_local;})};
}
function equivalente(a,b){
  if(a===b)return true;
  if(a===null||b===null||typeof a!=='object'||typeof b!=='object'||Array.isArray(a)!==Array.isArray(b))return false;
  const ka=Object.keys(a).sort(),kb=Object.keys(b).sort();
  return JSON.stringify(ka)===JSON.stringify(kb)&&ka.every(k=>equivalente(a[k],b[k]));
}
function resultadoRol(rol,c){
  if(rol==='A1')return {solicitud_validada:validarSolicitud(c.datos,c.bases),campos_faltantes:[]};
  if(rol==='A2')return recuperarFuentes(c);
  if(rol==='A3')return calcularPlan(c);
  if(rol==='A4'){
    const plan=calcularPlan(c);const observado=c.resultados?.A3;
    if(!equivalente(observado,plan))throw Error('PLAN_NO_CONFORME');
    return {dictamen:'conforme',requiere_revision_fechas:plan.requiere_revision_fechas,aprobacion_humana_requerida:true,registro_definitivo_permitido:false};
  }
  throw Error('ROL_NO_PERMITIDO');
}
function validarSalida(rol,raw,c){
  let o=raw;if(typeof o==='string')o=JSON.parse(o.replace(/^```(?:json)?\s*/,'').replace(/\s*```$/,''));
  const keys=Object.keys(o||{}).sort();
  if(JSON.stringify(keys)!==JSON.stringify(['caso_id','agente','estado','resultado'].sort()))throw Error('CONTRATO_SALIDA_INVALIDO');
  if(o.caso_id!==c.caso_id||o.agente!==rol||o.estado!=='ok')throw Error('IDENTIDAD_SALIDA_INVALIDA');
  if(!equivalente(o.resultado,resultadoRol(rol,c)))throw Error('RESULTADO_NO_VERIFICADO_'+rol);
  return o;
}
if(typeof module!=='undefined')module.exports={validarSolicitud,recuperarFuentes,calcularPlan,equivalente,resultadoRol,validarSalida};


// Transiciones: propietario autorizado y resultados exclusivamente simulados.
function operarCaso(caso, usuario, accion, version, ahora=new Date()) {
 const c=JSON.parse(JSON.stringify(caso));
 if(c.usuario_id!==String(usuario))throw Error('USUARIO_NO_AUTORIZADO');
 if(c.modo!=='SIMULADO')throw Error('MODO_INVALIDO');
 if(!Number.isSafeInteger(version)||version!==c.version)throw Error('VERSION_DESACTUALIZADA');
 if(accion==='generar'){
  if(c.estado!=='recibido_sin_procesar')throw Error('ESTADO_NO_GENERABLE');
  c.estado='procesando';c.version++;c.proceso_iniciado_en=ahora.toISOString();
 }else{
  if(!['aprobar','rechazar'].includes(accion))throw Error('ACCION_INVALIDA');
  if(c.estado!=='pendiente_aprobacion'||!c.plan||c.revision?.dictamen!=='conforme')throw Error('SIN_PROPUESTA_APROBABLE');
  if(!c.vence_en||!Number.isFinite(Date.parse(c.vence_en)))throw Error('VENCIMIENTO_INVALIDO');
  if(ahora.getTime()>=Date.parse(c.vence_en)){c.estado='vencido';c.version++;return c;}
  if(accion==='aprobar'&&(c.plan.requiere_revision_fechas||c.revision.requiere_revision_fechas))throw Error('FECHAS_REQUIEREN_REVISION_RH');
  c.estado=accion==='aprobar'?'registrado_simulado':'rechazado';
  if(!c.primera_revision_humana_en){c.primera_revision_humana_en=ahora.toISOString();c.aprobado_primera_revision_sin_cambios=accion==='aprobar';}
  c.aprobacion={accion,usuario_id:String(usuario),version_aprobada:version,fecha:ahora.toISOString()};c.version++;
 }
 return c;
}
function guardarPropuesta(caso, resultado, ahora=new Date()){
 if(caso.estado!=='procesando'||resultado.caso_id!==caso.caso_id||resultado.modo!=='SIMULADO')throw Error('RESULTADO_AJENO_AL_CASO');
 if(resultado.revision?.dictamen!=='conforme'||!resultado.revision.aprobacion_humana_requerida||resultado.revision.registro_definitivo_permitido!==false)throw Error('REVISION_INVALIDA');
 if(!Array.isArray(resultado.propuesta?.actividades)||!resultado.propuesta.actividades.length||resultado.traza?.length!==5)throw Error('RESULTADO_INCOMPLETO');
 return {...caso,primera_propuesta_revisada_en:caso.primera_propuesta_revisada_en||ahora.toISOString(),estado:'pendiente_aprobacion',version:caso.version+1,plan:resultado.propuesta,revision:resultado.revision,traza:resultado.traza,consumo:resultado.consumo,vence_en:new Date(ahora.getTime()+86400000).toISOString(),aprobacion:null};
}
if(typeof module!=='undefined')module.exports={operarCaso,guardarPropuesta};

// Adaptador Telegram: solo registro y consulta. No llama modelos ni aprueba planes.
function procesarTelegram(e,registros,bases,permitidos,habilitarIA=false){
  const m=e.message;if(!m||!Number.isSafeInteger(e.update_id)||!Number.isSafeInteger(m.from?.id)||!Number.isSafeInteger(m.chat?.id))throw Error('EVENTO_TELEGRAM_INVALIDO');
  if(m.chat.type!=='private'||!permitidos.includes(String(m.from.id)))throw Error('USUARIO_NO_AUTORIZADO');
  const text=m.text;if(typeof text!=='string'||!text.trim()||text.length>1500)throw Error('MENSAJE_INVALIDO');
  const eventKey='EVENTO-TG-'+e.update_id;
  if(registros.some(x=>x.clave===eventKey))return {duplicado:true,filas:[],respuesta:null,chat_id:m.chat.id};
  const parts=text.trim().split(/\s+/);const cmd=parts.shift().split('@')[0].toLowerCase();
  let respuesta,caso=null,generar=false;
  const ayuda='MICA · entorno simulado. /nuevo DEP-TEC P-TEC-01 2026-11-23 remota · /estado FOLIO. Solo nuevos ingresos. No envíes datos personales. Genera una propuesta con /generar FOLIO VERSION. Después usa /aprobar FOLIO VERSION o /rechazar FOLIO VERSION. Todo es simulado.';
  if(cmd==='/start'||cmd==='/help')respuesta=ayuda;
  else if(cmd==='/nuevo'){
    if(parts.length!==4)respuesta='Faltan datos o hay campos extra. Usa: /nuevo DEPARTAMENTO PUESTO AAAA-MM-DD MODALIDAD. Ejemplo: /nuevo DEP-TEC P-TEC-01 2026-11-23 remota';
    else {
      const datos={departamento_id:parts[0],puesto_id:parts[1],fecha_ingreso:parts[2],modalidad:parts[3],tipo_incorporacion:'nuevo_ingreso',responsable_rh_id:'RH-01'};
      try{validarSolicitud(datos,bases);const folio='MICA-TG-'+e.update_id;caso={caso_id:folio,estado:'recibido_sin_procesar',modo:'SIMULADO',version:0,datos,usuario_id:String(m.from.id),chat_id:String(m.chat.id),recibido_en:new Date((m.date||0)*1000).toISOString(),plan:null,aprobacion:null};respuesta='Solicitud simulada registrada: '+folio+'. Estado: recibida, sin procesar. Consulta /estado '+folio+'. Todavía no se ha generado ni aprobado un plan.';}
      catch(err){respuesta='No se creó el caso: '+err.message+'. Revisa los datos y usa /help.';}
    }
  }else if(cmd==='/estado'){
    if(parts.length!==1||!/^MICA-[A-Za-z0-9-]{1,80}$/.test(parts[0]))respuesta='Usa /estado FOLIO con un folio de MICA.';
    else{const row=registros.find(x=>x.clave==='CASO-'+parts[0]&&x.tipo==='caso');let value=null;try{value=row?JSON.parse(row.payload):null;}catch{throw Error('REGISTRO_CASO_INVALIDO');}respuesta=value&&value.usuario_id===String(m.from.id)?'Folio '+value.caso_id+' · Estado: '+value.estado.replace(/_/g,' ')+' · Versión: '+value.version+' · Resultado simulado.':'No hay un caso accesible con ese folio.';}
  }else if(['/generar','/aprobar','/rechazar'].includes(cmd)){
    if(parts.length!==2||!/^MICA-[A-Za-z0-9-]{1,80}$/.test(parts[0])||!/^\d+$/.test(parts[1]))respuesta='Usa '+cmd+' FOLIO VERSION. Consulta primero /estado FOLIO.';
    else{const row=registros.find(x=>x.clave==='CASO-'+parts[0]&&x.tipo==='caso');
      try{if(!row)throw Error('CASO_NO_ENCONTRADO');if(cmd==='/generar'&&!habilitarIA)throw Error('IA_PENDIENTE_AUTORIZACION');caso=operarCaso(JSON.parse(row.payload),m.from.id,cmd.slice(1),Number(parts[1]));generar=cmd==='/generar';respuesta='Folio '+caso.caso_id+' · Estado: '+caso.estado.replace(/_/g,' ')+' · Versión: '+caso.version+' · Simulado.';}
      catch(err){caso=null;respuesta='Acción bloqueada: '+err.message+'. Consulta /estado FOLIO.';}
    }
  }
  else respuesta='Comando no reconocido. Usa /help. No se ejecutó ninguna acción empresarial.';
  if(cmd==='/estado'&&parts.length===1){const row=registros.find(x=>x.clave==='CASO-'+parts[0]&&x.tipo==='caso');const v=row?JSON.parse(row.payload):null;if(v&&v.usuario_id===String(m.from.id)&&v.plan){respuesta+=' Detalle del plan: '+v.plan.actividades.map(a=>a.actividad_id+' | '+a.fecha+' | '+a.responsable_id).join('; ')+'. Requiere revisión de fechas: '+v.plan.requiere_revision_fechas+'. Aprobar: /aprobar '+v.caso_id+' '+v.version+' · Rechazar: /rechazar '+v.caso_id+' '+v.version;}}
  const filas=[{clave:eventKey,tipo:'evento',estado:'procesado',payload:JSON.stringify({update_id:e.update_id,usuario_id:String(m.from.id),comando:cmd,caso_id:caso?.caso_id||null,...(cmd==='/nuevo'?{recibido_en:new Date((m.date||0)*1000).toISOString(),completa_al_recibir:caso!==null}:{})})}];
  if(caso)filas.push({clave:'CASO-'+caso.caso_id,tipo:'caso',estado:caso.estado,payload:JSON.stringify(caso)});
  return {duplicado:false,filas,respuesta,chat_id:m.chat.id,generar,caso};
}
if(typeof module!=='undefined')module.exports={procesarTelegram};

const c=$('Validar acceso MICA').first().json;const registros=$input.all().map(x=>x.json).filter(x=>x.clave);const HABILITAR_IA=false;const CASOS_AUTORIZADOS=['MICA-TG-479895074','MICA-TG-479895075'];const comandoLote=c.evento.message.text.trim().split(/\s+/);if(comandoLote[0].split('@')[0].toLowerCase()==='/generar'&&!CASOS_AUTORIZADOS.includes(comandoLote[1]))throw Error('CASO_FUERA_DEL_LOTE_AUTORIZADO');const r=procesarTelegram(c.evento,registros,c.bases,c.permitidos,HABILITAR_IA);if(r.duplicado)return [];return r.filas.map(f=>({json:{...f,chat_id:r.chat_id,respuesta:r.respuesta,generar:r.generar,caso:r.caso}}));