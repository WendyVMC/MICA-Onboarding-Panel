// Transiciones: propietario autorizado y resultados exclusivamente simulados.
function operarCaso(caso, usuario, accion, version, ahora=new Date()) {
 const c=JSON.parse(JSON.stringify(caso));
 if(c.usuario_id!==String(usuario))throw Error('USUARIO_NO_AUTORIZADO');
 if(c.modo!=='SIMULADO')throw Error('MODO_INVALIDO');
 if(!Number.isSafeInteger(version)||version!==c.version)throw Error('VERSION_DESACTUALIZADA');
 if(accion==='generar'){
  if(c.estado!=='recibido_sin_procesar')throw Error('ESTADO_NO_GENERABLE');
  c.estado='procesando';c.version++;c.proceso_iniciado_en=ahora.toISOString();
 }else{
  if(!['aprobar','rechazar'].includes(accion))throw Error('ACCION_INVALIDA');
  if(c.estado!=='pendiente_aprobacion'||!c.plan||c.revision?.dictamen!=='conforme')throw Error('SIN_PROPUESTA_APROBABLE');
  if(!c.vence_en||!Number.isFinite(Date.parse(c.vence_en)))throw Error('VENCIMIENTO_INVALIDO');
  if(ahora.getTime()>=Date.parse(c.vence_en)){c.estado='vencido';c.version++;return c;}
  if(accion==='aprobar'&&(c.plan.requiere_revision_fechas||c.revision.requiere_revision_fechas))throw Error('FECHAS_REQUIEREN_REVISION_RH');
  c.estado=accion==='aprobar'?'registrado_simulado':'rechazado';
  if(!c.primera_revision_humana_en){c.primera_revision_humana_en=ahora.toISOString();c.aprobado_primera_revision_sin_cambios=accion==='aprobar';}
  c.aprobacion={accion,usuario_id:String(usuario),version_aprobada:version,fecha:ahora.toISOString()};c.version++;
 }
 return c;
}
function guardarPropuesta(caso, resultado, ahora=new Date()){
 if(caso.estado!=='procesando'||resultado.caso_id!==caso.caso_id||resultado.modo!=='SIMULADO')throw Error('RESULTADO_AJENO_AL_CASO');
 if(resultado.revision?.dictamen!=='conforme'||!resultado.revision.aprobacion_humana_requerida||resultado.revision.registro_definitivo_permitido!==false)throw Error('REVISION_INVALIDA');
 if(!Array.isArray(resultado.propuesta?.actividades)||!resultado.propuesta.actividades.length||resultado.traza?.length!==5)throw Error('RESULTADO_INCOMPLETO');
 return {...caso,primera_propuesta_revisada_en:caso.primera_propuesta_revisada_en||ahora.toISOString(),estado:'pendiente_aprobacion',version:caso.version+1,plan:resultado.propuesta,revision:resultado.revision,traza:resultado.traza,consumo:resultado.consumo,vence_en:new Date(ahora.getTime()+86400000).toISOString(),aprobacion:null};
}
if(typeof module!=='undefined')module.exports={operarCaso,guardarPropuesta};
