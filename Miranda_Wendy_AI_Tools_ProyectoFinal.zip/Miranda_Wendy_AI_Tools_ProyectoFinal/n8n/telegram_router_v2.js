// Adaptador Telegram: solo registro y consulta. No llama modelos ni aprueba planes.
function procesarTelegram(e,registros,bases,permitidos,habilitarIA=false){
  const m=e.message;if(!m||!Number.isSafeInteger(e.update_id)||!Number.isSafeInteger(m.from?.id)||!Number.isSafeInteger(m.chat?.id))throw Error('EVENTO_TELEGRAM_INVALIDO');
  if(m.chat.type!=='private'||!permitidos.includes(String(m.from.id)))throw Error('USUARIO_NO_AUTORIZADO');
  const text=m.text;if(typeof text!=='string'||!text.trim()||text.length>1500)throw Error('MENSAJE_INVALIDO');
  const eventKey='EVENTO-TG-'+e.update_id;
  if(registros.some(x=>x.clave===eventKey))return {duplicado:true,filas:[],respuesta:null,chat_id:m.chat.id};
  const parts=text.trim().split(/\s+/);const cmd=parts.shift().split('@')[0].toLowerCase();
  let respuesta,caso=null,generar=false;
  const ayuda='MICA · entorno simulado. /nuevo DEP-TEC P-TEC-01 2026-11-23 remota · /estado FOLIO. Solo nuevos ingresos. No envíes datos personales. Genera una propuesta con /generar FOLIO VERSION. Después usa /aprobar FOLIO VERSION o /rechazar FOLIO VERSION. Todo es simulado.';
  if(cmd==='/start'||cmd==='/help')respuesta=ayuda;
  else if(cmd==='/nuevo'){
    if(parts.length!==4)respuesta='Faltan datos o hay campos extra. Usa: /nuevo DEPARTAMENTO PUESTO AAAA-MM-DD MODALIDAD. Ejemplo: /nuevo DEP-TEC P-TEC-01 2026-11-23 remota';
    else {
      const datos={departamento_id:parts[0],puesto_id:parts[1],fecha_ingreso:parts[2],modalidad:parts[3],tipo_incorporacion:'nuevo_ingreso',responsable_rh_id:'RH-01'};
      try{validarSolicitud(datos,bases);const folio='MICA-TG-'+e.update_id;caso={caso_id:folio,estado:'recibido_sin_procesar',modo:'SIMULADO',version:0,datos,usuario_id:String(m.from.id),chat_id:String(m.chat.id),recibido_en:new Date((m.date||0)*1000).toISOString(),plan:null,aprobacion:null};respuesta='Solicitud simulada registrada: '+folio+'. Estado: recibida, sin procesar. Consulta /estado '+folio+'. Todavía no se ha generado ni aprobado un plan.';}
      catch(err){respuesta='No se creó el caso: '+err.message+'. Revisa los datos y usa /help.';}
    }
  }else if(cmd==='/estado'){
    if(parts.length!==1||!/^MICA-[A-Za-z0-9-]{1,80}$/.test(parts[0]))respuesta='Usa /estado FOLIO con un folio de MICA.';
    else{const row=registros.find(x=>x.clave==='CASO-'+parts[0]&&x.tipo==='caso');let value=null;try{value=row?JSON.parse(row.payload):null;}catch{throw Error('REGISTRO_CASO_INVALIDO');}respuesta=value&&value.usuario_id===String(m.from.id)?'Folio '+value.caso_id+' · Estado: '+value.estado.replace(/_/g,' ')+' · Versión: '+value.version+' · Resultado simulado.':'No hay un caso accesible con ese folio.';}
  }else if(['/generar','/aprobar','/rechazar'].includes(cmd)){
    if(parts.length!==2||!/^MICA-[A-Za-z0-9-]{1,80}$/.test(parts[0])||!/^\d+$/.test(parts[1]))respuesta='Usa '+cmd+' FOLIO VERSION. Consulta primero /estado FOLIO.';
    else{const row=registros.find(x=>x.clave==='CASO-'+parts[0]&&x.tipo==='caso');
      try{if(!row)throw Error('CASO_NO_ENCONTRADO');if(cmd==='/generar'&&!habilitarIA)throw Error('IA_PENDIENTE_AUTORIZACION');caso=operarCaso(JSON.parse(row.payload),m.from.id,cmd.slice(1),Number(parts[1]));generar=cmd==='/generar';respuesta='Folio '+caso.caso_id+' · Estado: '+caso.estado.replace(/_/g,' ')+' · Versión: '+caso.version+' · Simulado.';}
      catch(err){caso=null;respuesta='Acción bloqueada: '+err.message+'. Consulta /estado FOLIO.';}
    }
  }
  else respuesta='Comando no reconocido. Usa /help. No se ejecutó ninguna acción empresarial.';
  const filas=[{clave:eventKey,tipo:'evento',estado:'procesado',payload:JSON.stringify({update_id:e.update_id,usuario_id:String(m.from.id),comando:cmd,caso_id:caso?.caso_id||null,...(cmd==='/nuevo'?{recibido_en:new Date((m.date||0)*1000).toISOString(),completa_al_recibir:caso!==null}: {})})}];
  if(caso)filas.push({clave:'CASO-'+caso.caso_id,tipo:'caso',estado:caso.estado,payload:JSON.stringify(caso)});
  return {duplicado:false,filas,respuesta,chat_id:m.chat.id,generar,caso};
}
if(typeof module!=='undefined')module.exports={procesarTelegram};
