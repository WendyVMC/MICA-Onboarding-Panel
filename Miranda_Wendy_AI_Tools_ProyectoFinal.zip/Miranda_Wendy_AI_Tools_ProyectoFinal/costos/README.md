# Control de costos de MICA

Estado: estructura preparada. Sin mediciones API ni tarifas verificadas todavía.

## Antes de la primera ejecución de pago

1. Identificar proveedor, modelo exacto, plan y saldo.
2. Registrar la URL oficial de tarifas y la fecha de consulta en `tarifas.json`.
3. Acordar y configurar límites de costo, llamadas, tokens, tiempo e iteraciones.
4. Autorizar una sola prueba controlada y registrar el uso reportado.

El uso del chat de desarrollo tiene consumo económico desconocido en este registro; no se registra como cero. Las operaciones locales de preparación y validación no llamaron a modelos por API. No hay todavía costos de operación medidos.

## Registro por preparar al implementar

El archivo final será `costos.csv` con fecha_hora, caso_id, llamada_id, etapa, agente, proveedor, modelo_version, tokens_entrada, tokens_salida, tokens_cache, duracion_voz_segundos, unidad_cobro, tarifa, costo, moneda, estado, reintento, origen_dato, referencia_tarifa y referencia_evidencia.

Separar desarrollo, casos completos, errores, reintentos, plataformas, voz y publicación. Cada llamada se suma una sola vez: los skills y loops referencian sus llamadas, no las vuelven a facturar. Sin llamada a modelo, tokens = no aplica; con consumo desconocido, usar desconocido y explicar el método de estimación si se calcula.

Costo LLM sin caché = (tokens_entrada × precio_entrada + tokens_salida × precio_salida) / 1 000 000. Separar caché y otras categorías cuando apliquen. Los precios de voz, ejecución y hosting dependen del plan, no necesariamente de tokens. No usar tarifas inventadas.
