# Primera prueba propuesta · AUTORIZADA Y EJECUTADA UNA VEZ

Caso: MICA-PRUEBA-001. Una llamada del componente de recepción, usando el prompt fijo `agentes/prueba_A1_prompt.txt` y datos sintéticos DAT-01. No ejecuta el flujo completo, no crea registros definitivos ni envía mensajes.

Modelo propuesto: gpt-4o-mini vía Gateway. Fuente: https://app.n8n.cloud/service-pricing#openai, consultada el 2026-11-04. Entrada USD 0.15/millón y salida USD 0.60/millón.

Configuración objetivo: una llamada; máximo 600 tokens de salida; timeout 30 s; cero reintentos; sin búsquedas, memoria ni herramientas externas. El prompt fijo tiene tamaño pequeño; antes de ejecutar se revisará que no haya mensajes ni contexto adicional.

Referencia conservadora de 6 000 tokens de entrada + 600 de salida: (6 000 × 0.15 + 600 × 0.60)/1 000 000 = USD 0.00126. Esta cifra es una estimación de referencia condicionada a ese uso, no un costo medido ni garantía de límite facturable. Propuesta de autorización: hasta USD 0.01 del saldo existente para esa única llamada, sin recargas. Si no puede verificarse la configuración, no ejecutar.

Resultado esperado: JSON con caso_id MICA-PRUEBA-001, agente A1, estado ok, mismos seis campos, campos_faltantes vacío y resumen sin actividades ni aprobación. Guardar ejecución, salida, modelo, tokens y consumo real si el proveedor lo reporta. Si el saldo solo tiene precisión de centavos, no inferir costo cero ni atribuir una diferencia redondeada como medición exacta.

Esta prueba valida conectividad y comportamiento del componente; no acredita todavía A1 con herramientas, cinco roles completos, contratos de servidor ni P01.

Resultado: conexión exitosa; 609 tokens entrada, 81 salida; formato no conforme. Costo calculado USD 0.00013995. Autorización de esta llamada consumida. V2 preparada sin ejecutar.
