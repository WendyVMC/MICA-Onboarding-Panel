# Costos del proyecto MICA

## Medido, calculado y reportado

Se recuperaron **42 llamadas de modelos**, con identificadores únicos. El subtotal calculado n8n/Gateway es **USD 0.00617610**. Los cuatro casos completos suman USD 0.00463620; promedio USD 0.00115905/caso. Este promedio solo corresponde al LLM de n8n, no al costo integral.

La llamada de voz consumió 831 créditos: 667 plataforma y 164 LLM. El LLM se mostró como 0,0154 $. Es un desglose del uso de voz; no se suma de nuevo a los 831 créditos. No hay equivalencia de créditos a dinero verificada para esta cuenta. Los 5 USD reportados por la estudiante son una recarga, no un cargo consumido ni un saldo conciliado.

El primer ensayo A1 falló y consumió USD 0.00013995. El caso Tecnología tuvo fallo de formato en A3; las seis llamadas previas y las dos de recuperación A4 se asignan una sola vez al caso completo. No se vuelven a sumar como un caso fallido adicional. Las pruebas de componentes anteriores se conservan separadas. Las horas registradas en algunas llamadas son de su ejecución contenedora; no se inventa un instante individual.

## Fórmulas y escenarios

C_llamada=(tokens_entrada×0.15 + tokens_salida×0.60)/1,000,000. Caché no desglosada: tarifa plena de entrada, sin descuento supuesto. C_mes=plataformas fijas + consumos variables no incluidos. No se mezclan EUR y USD sin conversión declarada.

Base: tres comandos Telegram por caso; 20% de los casos añaden voz de un minuto y dos peticiones de herramienta. Ejecuciones estimadas=3.4N. Alto: cinco comandos, 50% con dos minutos de voz, 10% de una corrección parcial; ejecuciones=6.1N. Contexto LLM doble y salida 1.5 veces en alto; una corrección de un especialista en 10% añade 2.5% al costo de ocho llamadas. El valor del LLM de voz/minuto deriva de una sola conversación y se duplica en alto; no es una tarifa contractual estable.

Las tablas mantienen el fijo n8n en EUR y el resto en USD. Incluyen un total condicional con **1 EUR=1.10 USD como supuesto didáctico, no tipo de cambio vigente**. Para 61,000 ejecuciones se presupone un cupo custom de 100,000: 144 EUR + 50×2 EUR. La disponibilidad del tier debe confirmarse antes de contratar. No se atribuye operación indefinida gratuita a las pruebas actuales.

ElevenLabs: se elige entre planes mensuales sin promociones y sus minutos incluidos; solo el exceso usa 0.08 USD/min. El LLM externo se contempla por separado. No se contrata ningún plan. n8n: 2,500/10,000/50,000 ejecuciones y extensión Pro2 mensual según documentación. Los topes actuales de tres llamadas diarias y 60 s deben revisarse para estos escenarios; no prueban capacidad real a escala.

## Optimización y calidad

Optimización implementada: comprobar y corregir reglas mediante funciones deterministas en los loops. La evidencia V1 con una actividad omitida falla, V2 la restituye y pasa, con costo API adicional 0 y sin omitir controles. Alternativa hipotética de una corrección LLM de 1,000 tokens de entrada y 300 de salida: USD 0.00033; es ahorro potencial evitado, no reducción monetaria medida contra un experimento equivalente. El ensayo A1 V1→V2 mejoró calidad pero aumentó contexto/costo; se conserva para evitar afirmar que toda mejora ahorra dinero.

## Pendiente de conciliación

Tokens/cargo del asistente de desarrollo, costo de indexación, cargos de plataforma, impuestos, factura y proveedor exacto de la recarga. Se registran como desconocidos. No se ha demostrado ROI, ahorro humano ni costo total definitivo.


## Consolidación del 26/11/2026

Se incorporaron una sola vez las ocho llamadas del ensayo 082 (USD 0.00114015 calculados). El total Gateway conocido es USD 0.00617610; 42 llamadas. La conversación de voz medida sigue siendo una; la voz del ensayo 082 y la prueba completa se reservan para la presentación. Los saldos y tarifas conservan su fecha histórica de observación; no se verificaron en vivo el 26/11. La estimación de desarrollo se detalla en DESARROLLO_ESTIMACION.md y no se suma a los cargos medidos.


## Comparación offline de costo y calidad

Se reprodujeron cuatro planes históricos con la función determinista: 4/4 coincidieron con el plan validado, y una omisión ACT-G04 fue detectada en cada caso. Las ocho llamadas históricas de A3 sumaron USD 0.00182160 calculados; el replay hizo cero llamadas API adicionales. Esto acredita calidad conservada en la subfunción de cálculo, no una nueva ejecución integrada de una arquitectura más barata ni ahorro facturado. El especialista A3 se conserva en Cloud. Evidencia: evidencias/optimizacion_replay.json.
