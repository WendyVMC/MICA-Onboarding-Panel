# Registro de gastos y consumo · MICA

Actualizado: 2026-11-04. Se conservará aquí lo que reporte la estudiante y se conciliará con registros del proveedor cuando estén disponibles.

## Situación actual

| Concepto | Dato conocido | Clasificación | Cargo atribuible al proyecto |
|---|---|---|---|
| n8n Cloud | Pantalla muestra 9 días de prueba y 0/1000 ejecuciones | Observado el 2026-11-04; captura contextual, no factura | Desconocido; sin compra o recarga realizada por el asistente |
| Gateway n8n | Saldo visible USD 1.99 | Saldo disponible; no es gasto ni consumo de MICA | Aún sin medición de llamadas MICA |
| ElevenLabs | Cuenta con disponibilidad inicial, según estudiante | Declarado; cuota y plan no verificados | Pendiente informar |
| Chat de desarrollo | Uso de IA durante preparación del proyecto | Consumo no desglosado disponible | Desconocido, no cero |
| GitHub | Repositorio privado creado y organizado | No hay Actions ejecutadas por este proyecto hasta este registro | Plan y cargo atribuible pendientes verificar |

Actualización: se ejecutó una llamada aislada A1 con autorización de hasta USD 0.01. Esto no certifica que la cuenta completa no haya tenido consumos de otros usos.

## Cuando me compartas un gasto

Registraré: herramienta, fecha, importe, moneda, concepto, etapa (desarrollo/prueba/operación), origen (reportado/documentado/medido), evidencia y si es recarga, cargo fijo, consumo o extra. Si falta algo, quedará pendiente; no se inventarán detalles.

Puedes decirlo de forma sencilla: «En ElevenLabs pagué X en MXN el día Y para el plan Z». No envíes datos de tarjeta ni credenciales. Para consumo: «El saldo de Gateway pasó de X a Y después de la prueba DAT-01».

## Reglas para no contar dos veces

- Recargar saldo no equivale a consumirlo: registrar la compra y el consumo por separado.
- Una suscripción ya existente no se atribuye íntegramente a MICA sin declarar el criterio de asignación.
- Diferencias de saldo solo se atribuyen a una prueba si no hubo otros consumos y la precisión del panel es suficiente; de lo contrario son estimaciones.
- No sumar valor estimado de créditos incluidos otra vez como cargo adicional.
- Toda corrección conserva el registro anterior y su motivo; no sobrescribir evidencia histórica silenciosamente.
- El registro por llamada se completará con tokens/voz/ejecuciones y se exportará a costos.csv para la entrega. Este documento no sustituye ese detalle.

## Movimientos informados por la estudiante

Todavía no se han comunicado importes concretos. El registro estructurado está en `movimientos_reportados.json`; no contiene filas de gasto ficticias.

## Primera llamada real · 2026-11-04

MICA-PRUEBA-001 / A1-001: 609 tokens entrada + 81 salida = 690; 1389 ms; modelo gpt-4o-mini-2024-07-18. Costo calculado con tarifa Gateway: USD 0.00013995; no cargo de factura conciliado. No hay evidencia de desglose de caché, por eso queda null. Conexión exitosa, formato de negocio fallido (booleano en vez de objeto). Sin reintentos. Detalle en llamadas.json.

## Corrección A1 V2 · lote autorizado

Mismo caso MICA-PRUEBA-001, llamada A1-002. Parser explícito y prompt corregido: salida validada con los seis campos. 1336 tokens entrada + 120 salida = 1456; 1928 ms. Costo calculado USD 0.0002724; cargo final pendiente conciliar. Lote: 1/12 llamadas usadas, USD 0.0002724 de USD 0.10 calculados. Hubo un intento detenido por falta de conexión del trigger antes del modelo, conservado aparte.

## Caso integrado MICA-000031

Ocho llamadas reales (dos por especialista), 3173 tokens de entrada + 1086 de salida = 4259 tokens. Costo calculado USD 0.00112755; factura pendiente conciliar. Cuatro herramientas locales consultadas y cuatro controles de salida superados. Final pendiente_aprobacion, no ejecución empresarial. Lote acumulado: 9/12 llamadas y USD 0.00139995 calculados. Restan 3 llamadas; no ejecutar otro caso completo de ocho llamadas con este lote.

### 2026-11-16 · Migración y Telegram
Dos pruebas internas (registro y consulta) y dos comandos reales de Telegram observados. Cero llamadas de modelos; tokens no aplican. Costo de plataforma desconocido, sujeto al plan; no recargas. Evidencias en migracion_registro_consulta.json y nueva_cuenta_telegram_produccion.json.

### 2026-11-16 · Preparación ElevenLabs
Agente creado en blanco; instrucciones y fuente MICA adjuntas. La plataforma completó indexación RAG automática. Ninguna conversación ni llamada de prueba iniciada; Architect no utilizado y sin recargas. Costo/consumo de indexación desconocido; pendiente conciliar, no se registra como cero.

### 2026-11-16 · Skills y loops
41 comprobaciones locales y una ejecución n8n (ID 11, 1.764 s, dos casos) sin modelos, Telegram o escrituras en tablas. Tokenización no aplica; APIs 0 USD en estos componentes. Cuota/costo n8n y recursos locales sin monetización medida. CSV auxiliar skills_loops_validaciones.csv. Uso del asistente en desarrollo desconocido; no se asume cero.

### 2026-11-19 · Publicación Pages/Actions
Tres ejecuciones de GitHub Actions en repositorio público: inicial, falla deliberada y corrección; refs en evidencias/pages_publicacion_final.json. Cero llamadas a modelos en esos jobs, tokenización no aplica. Runners estándar; sin contratación ni recargas. Facturación exacta no conciliada. Los tokens de desarrollo del asistente son un costo distinto y siguen sin dato reportado.
