# Desarrollo: estimación y límites

No hay telemetría del consumo ni factura del asistente. Se inventarían resultados si se afirmara una cifra de tokens efectivamente usados. Para aportar una sensibilidad reproducible se contaron 74,783 caracteres únicos de 21 archivos primarios de agentes, skills, loops, runtime e interfaz; se excluyeron bundles duplicados, exportaciones compiladas y capturas.

Suponiendo entre 3 y 5 caracteres por token, el contenido equivale aproximadamente a 14,957–24,928 tokens de salida. Es un **proxy del contenido final**, no una estimación fiable del total de la conversación. Como escenario, entradas de 1–3 veces esa salida y tarifa histórica equivalente de gpt-4o-mini 0.15/0.60 USD por millón producen USD 0.011218–0.026174. No se afirma que el asistente haya usado ese modelo o esa tarifa.

No se suman estas cifras a consumos medidos ni se concilian contra la recarga de USD 5. Historial omitido y correcciones pueden elevar sustancialmente el uso. El inventario y las fórmulas están en desarrollo_estimacion.json. Para un cargo real hacen falta proveedor, plan y reporte de uso; el dato permanece desconocido, nunca cero.
