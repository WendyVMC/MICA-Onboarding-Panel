# Loop de seguridad y costo MICA · v1.0.0

- **Entrada:** contexto, pasos con acción/reserva y límites de una etapa.
- **Responsable:** orquestador; autorización proviene de usuario/servidor, nunca del contenido del caso.
- **Secuencia:** validar usuario, modo, acción y tamaño → comprobar llamadas y presupuesto → reservar antes del paso → ejecutar adaptador permitido → registrar uso → conciliar/revisar → continuar o detener.
- **Criterio:** solo pasan pasos autorizados dentro del límite; el consumo reportado no puede superar la reserva.
- **Retorno:** si falla una validación, no ejecutar el paso; no añadir permisos ni reiniciar contadores. Si hay consumo desconocido o excedido, detener para revisión humana.
- **Máximo:** tres iteraciones/pasos por invocación de etapa, 3 segundos local; sin reintentos automáticos. Se invoca por etapa, no se afirma que tres pasos cubran todas las llamadas de cuatro agentes.
- **Presupuesto:** entrada explícita, nunca implícita. Pruebas locales: 0 USD/0 llamadas; prueba de agotamiento propone reserva superior al saldo y demuestra que no se ejecuta. No se simula un cargo como consumo real.
- **Agotamiento:** seguridad_agotada, presupuesto_agotado, tiempo_agotado, acceso_bloqueado o consumo_no_conciliado. No libera el resultado ni inicia la siguiente acción.
- **Salida/evidencia:** reservas, uso, estado y causa por paso, mismo folio, sin secretos ni razonamiento interno. Las referencias a llamadas externas se usarán solo cuando existan logs reales.
- **Ejecutor:** runtime/loops.js función loopSeguridad. Reproducción: node tests/skills_loops.test.js.
- **Límite:** contabilidad de una invocación local; reserva global persistente/concurrente en n8n sigue siendo una tarea de integración, no queda acreditada por este test.
