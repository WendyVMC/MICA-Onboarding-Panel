# Loops ejecutables MICA

calidad-negocio/LOOP.md y seguridad-costo/LOOP.md describen entradas, responsables, retorno, límites y salida. Implementación en runtime/loops.js; reglas específicas cargadas desde skills/*/SKILL.md. Prueba de dos casos y bloqueos: node tests/skills_loops.test.js. La ejecución utiliza reglas locales sin modelos; las pruebas completas con modelos requieren autorización y costos propios.
