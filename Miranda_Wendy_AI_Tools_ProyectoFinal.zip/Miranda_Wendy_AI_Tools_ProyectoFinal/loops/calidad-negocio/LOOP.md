# Loop de calidad del onboarding MICA · v1.0.0

- **Entrada:** contexto validado y propuesta opcional.
- **Responsable:** orquestador; propuesta por skill de negocio, verificación por skill de calidad.
- **Secuencia:** generar/recibir → medir cobertura, fechas, responsables, referencias y flags → registrar defectos → corregir solo propuesta usando fuentes → volver a validar.
- **Criterio de salida:** propuesta canónica sin vencidas, liberable únicamente para aprobación humana.
- **Retorno:** ante PLAN_NO_CONFORME, recalcular con reglas originales. Si el problema es de fuentes, permisos o datos, detener: no inventar ni cambiar acceso.
- **Máximo:** tres iteraciones totales por caso; 3 segundos en ejecución local determinista; presupuesto API 0 USD, llamadas 0. La ejecución n8n con modelos requiere un presupuesto autorizado separado, no hereda permiso de este test.
- **Agotamiento:** calidad_agotada, sin propuesta liberada; registrar causa y número de iteraciones.
- **Solicitud tardía:** requiere_revision_rh, se conservan fechas; no repetir para hacer pasar la política.
- **Salida/evidencia:** cada versión con caso_id, hash de propuesta, dictamen, defectos y referencia al skill cargado. Las trazas de prueba incluyen V1 con omisión deliberada y V2 recalculada, declaradas pruebas locales con inyección controlada de fallo.
- **Ejecutor:** runtime/loops.js función loopCalidad. Reproducción: node tests/skills_loops.test.js desde raíz.
- **Consumo:** tokenización no aplica; duración local medida. No sumar estas validaciones como nuevas llamadas de modelo.
