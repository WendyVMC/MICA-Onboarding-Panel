# Registro de control de calidad

Fecha: 21/11/2026. Audiencia: estudiante y docente. Decisión: qué evidencia respalda la entrega y qué límites deben declararse.

| Paso | Control y evidencia | Resultado |
|---|---|---|
| Interpretar | Guía completa de 16 páginas, paquete reproducible y defensa individual | Entrega integrada; las simulaciones no se presentan como servicios reales |
| Revisar datos | Tabla privada, tres casos, llamada de voz, logs de modelos, Actions y fuentes tarifarias | Inventario y procedencia; marcas directas y reconstruidas diferenciadas |
| Diagnosticar | Tres casos completos, primer caso recuperado; error de autenticación y corrección; pruebas negativas | Éxito real y pruebas de fallo controladas separados |
| Auditar | Unicidad de llamadas, 831=667+164, recarga no equivale a consumo, reglas y hashes | Evita doble conteo y afirmaciones de ROI no medidas |
| Corregir | KPI de completitud incluye entrada incompleta; agregado de consumo legado; preflight de micrófono y mensajes | Correcciones incorporadas y revalidadas por componentes |
| Comunicar | Informe 8–12 páginas, CSV, escenarios, manual, video narrado e índice | Lenguaje académico y límites explícitos |
| Decidir | Aprobado con alertas para evaluación académica de un piloto | No listo para decisiones reales de empleo ni operación a escala |

Alertas vigentes: facturación/desarrollo sin medición completa; rechazo nativo de micrófono y caída del proveedor modelados mediante fallos simulados; deduplicación concurrente no demostrada; el archivo ZIP publicado se coteja por SHA-256. Wendy debe revisar la declaración de IA y preparar su explicación individual; mantener cuentas y cuotas activas durante la evaluación.

Verificación local final: 11 grupos de comprobaciones pasaron desde la carpeta empaquetada, sin APIs; incluye 41 comprobaciones de skills/loops, 161 de agentes, 90 del ciclo, 25 de voz y 103 de bases. PDF verificado de 10 páginas; video de 415 segundos con una pista de imagen y una de audio.

Indicadores de cierre: matriz P01–P14 con evidencia/tipo explícitos, PDF 8–12 páginas sin cortes, video 5–8 minutos, paquete sin secretos y con hashes, enlaces públicos revisados. La defensa en vivo corresponde a la estudiante.
