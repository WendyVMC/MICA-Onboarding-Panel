# Ensayo de presentación · 21/11/2026

## Recorrido realizado

1. Telegram: `/nuevo DEP-TEC P-TEC-01 2026-12-10 remota`. Folio devuelto: **MICA-TG-479895082**, recibido, sin procesar.
2. Preparación en n8n: permitido únicamente ese folio; presupuesto USD 0.05, 8 llamadas máximo, salida 1800, timeout 30s, retry 0. Reserva total USD 0.05 (cuatro × 0.0125). Publicación previa a generar.
3. Telegram: `/generar MICA-TG-479895082 0`. Llegaron estado procesando v1 y propuesta v2 de 8 actividades, del 7 al 16/12. Ejecución 25 exitosa en 16.606s; cuatro especialistas, dos llamadas cada uno. Skills y hashes contrastados desde la tabla exportada.
4. La usuaria aprobó explícitamente este plan simulado. `/aprobar MICA-TG-479895082 2` devolvió registrado_simulado v3. No se automatiza esa decisión.
5. Se apagó la generación y se publicó esa versión. Exportación real `flujo_cierre_ensayo004.json` verificada. No nuevas llamadas permitidas por este lote.
6. Voz: se cambió el único folio permitido en servidor y en ambas herramientas al 082, preservando Header Auth y secreto. Prueba manual de consultar_caso: ok, registrado_simulado, versión 3. Esta prueba no es una conversación de voz.
7. Exportación privada CSV y lista blanca pública. Pages muestra 4 casos, 33 actividades y completitud 4/5=80%. Commit de datos 300f3460c3445bc755e2572c099397c8b3292547. Se declara actualización manual.

## Conversación de voz pendiente

Desde Pages aceptar consentimiento y habilitar asistente. Iniciar una sola llamada de máximo 60 s. Decir: «Sí, acepto. Consulta el caso MICA-TG-479895082». Tras la respuesta: «Solicita una revisión humana de ese mismo caso». Debe consultar la herramienta, informar estado registrado_simulado v3 y ocho actividades, luego confirmar solicitud de revisión sin aprobar ni modificar el plan. Colgar al confirmar. Si falla, detener y diagnosticar; no iniciar otra llamada automáticamente.

## Consumo hasta este punto

Ocho llamadas, 4307 tokens (3209 entrada y 1098 salida), USD 0.00114015 calculados con tarifa Gateway 0.15/0.60 por millón. No factura conciliada. Saldo previo UI: USD 1.99. ElevenLabs previo: 3163 créditos disponibles; conversación anterior costó 831, no garantiza que esta cueste lo mismo. Sin recargas. El consumo de voz de este ensayo se registra solo después de observar la conversación.

El piloto original de tres casos y el informe principal conservan su corte; este ensayo es evidencia adicional. Al cerrar voz deben actualizarse paquete y recibo de publicación, preservando trazabilidad de la versión anterior.
