# Índice de entrega por rúbrica · v2

Los puntos son pesos máximos de la consigna, no calificaciones obtenidas. Las rutas se abren desde la raíz extraída del ZIP. El tipo de prueba se detalla en pruebas.csv.

| Criterio | Evidencia principal | Límite |
|---|---|---|
| 1. Caso e integración · 5 | output/pdf/MICA_Informe_Final.pdf, pp. 1–2; panel/datos.json | Datos ficticios y corte histórico |
| 2. Cinco roles · 15 | agentes/00_orquestador.md y 01–04; agentes/contratos.schema.json; evidencias/lote003_cierre_casos.json; evidencias/ensayo004_cierre_casos.json | Registros observables, sin razonamiento privado |
| 3. n8n/Telegram · 12 | n8n/MICA_Principal_Entrega.json; docs/MANUAL_REPRODUCCION.md; evidencias/ensayo_clase_004_consumo.json | Credenciales propias al importar; variantes adversas locales declaradas |
| 4. Pages/Actions · 10 | .github/workflows/pages.yml; tools/validar_panel.js; evidencias/pages_actions_ejecuciones_reales.json; evidencias/pages_publicacion_final.json | Despliegue final de la versión y commit en recibo externo |
| 5. Skills/loops · 10 | skills/*/SKILL.md; loops/*/LOOP.md; runtime/; docs/AUTOEVALUACION_SKILLS_LOOPS.md; evidencias/skills_loops_n8n_resultados.json | V1/V2 controlada; no se atribuye a una respuesta de modelo |
| 6. Voz y visualización · 14 | voz/CONFIGURACION_ACTUAL.md; n8n/MICA_Voz_Entrega.json; evidencias/voz_conversacion_real_2026-11-21.json; panel/; evidencias/responsive_final.json | Voz real histórica 069; 082 pendiente. Anchos medidos en iframe; fallos de micrófono simulados |
| 7. Guardrails · 12 | tests/guardrails_entrega.test.js; evidencias/guardrails_entrega.json; evidencias/entradas_negativas_reales.json | Evidencia mixta; sin garantía de atomicidad concurrente |
| 8. Costos · 10 | costos.csv; costos/resumen_auditable.json; costos/escenarios.csv; costos/DESARROLLO_ESTIMACION.md; evidencias/optimizacion_replay.json | Calculado no equivale a facturado; proxy de desarrollo separado; comparación offline |
| 9. Pruebas/reproducción · 7 | README.md; docs/MANUAL_REPRODUCCION.md; pruebas.csv; datos/bases_mica_v1/diccionario_datos.md; docs/DECLARACION_IA_Y_FUENTES.md; evidencias/verificacion_cierre_v2.json | Se requiere acceso funcional en presentación |
| 10. Defensa · 5 | output/video/MICA_Respaldo.mov; docs/GUION_VIDEO_Y_DEFENSA.md; docs/ENSAYO_CLASE_004.md | Defensa individual en vivo pendiente de Wendy |

## Enlaces de evaluación

- Panel: https://wendyvmc.github.io/MICA-Onboarding-Panel/
- Repositorio: https://github.com/WendyVMC/MICA-Onboarding-Panel
- Bloqueo Actions: https://github.com/WendyVMC/MICA-Onboarding-Panel/actions/runs/44666974987
- Recuperación Actions: https://github.com/WendyVMC/MICA-Onboarding-Panel/actions/runs/44667092748
- Actualización del ensayo: https://github.com/WendyVMC/MICA-Onboarding-Panel/actions/runs/44987005954
- Bot: https://t.me/mica_wvmc_onboarding_bot (autorización por canal privado del curso, nunca publicar token).

El recibo externo identifica commit y hash del archivo final. El código completo está organizado dentro del ZIP público; los cinco archivos del panel se publican también descomprimidos. El evaluador puede importar su copia con credenciales propias o probar bajo supervisión de Wendy, según el manual. No se entrega acceso anónimo a datos privados.
