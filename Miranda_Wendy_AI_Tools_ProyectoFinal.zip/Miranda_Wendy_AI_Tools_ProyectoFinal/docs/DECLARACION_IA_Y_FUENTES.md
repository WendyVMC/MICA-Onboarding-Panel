# Autoría, uso de IA y fuentes

Proyecto individual de Wendy Miranda. Se utilizó el asistente de desarrollo para estructurar datos sintéticos, redactar y revisar instrucciones, implementar código, diagnosticar errores, preparar pruebas y organizar documentación. La estudiante configuró sus cuentas y credenciales, hizo la conversación de voz y aprobó las propuestas simuladas. Debe revisar el informe y poder explicar o modificar la solución durante la defensa.

Los cuatro especialistas se ejecutan con gpt-4o-mini mediante n8n Gateway. ElevenLabs aporta conversación de voz, transcripción, síntesis y su modelo configurado; su consumo se registra aparte. Los modelos no toman decisiones laborales ni asignan accesos. El orquestador y los controles críticos usan funciones deterministas. No se entregan cadenas de razonamiento privadas.

La narración del video de respaldo, si se incluye, se genera localmente con una voz de sistema, no imita la voz de Wendy y no es una nueva conversación de ElevenLabs. El video es un recorrido narrado por evidencias existentes, no una grabación continua de nuevas ejecuciones. Las simulaciones de fallos están rotuladas y no se presentan como una caída real del proveedor.

Datos de negocio, reglas, cargos y responsables son ficticios creados para la actividad; las métricas proceden de pruebas reales o reconstrucciones auditadas identificadas. No se atribuyen a una empresa real ni se afirma representatividad con n=4. Se excluyen secretos, usuarios/chats, audio y transcripciones completas del paquete público.

Recursos de interfaz: HTML/CSS/JS propios con identidad ColoresPasteles. El widget se carga desde el mecanismo oficial de ElevenLabs; no se redistribuye su biblioteca ni se sustituyen sus términos. Los proveedores mantienen sus licencias y marcas. Código y documentos de este proyecto se entregan para evaluación académica; no se declara una licencia abierta no elegida por la autora. La guía docente de la Dra. Elda C. Morales se cita, pero no se redistribuye dentro del paquete.

Fuentes oficiales (consultadas al implementar; tarifas revisitadas 21/11/2026):
- n8n. Telegram Trigger: https://docs.n8n.io/integrations/builtin/trigger-nodes/n8n-nodes-base.telegramtrigger/
- n8n. Webhook: https://docs.n8n.io/integrations/builtin/core-nodes/n8n-nodes-base.webhook/
- n8n. Service pricing: https://app.n8n.cloud/service-pricing#openai
- n8n. Plans and pricing: https://n8n.io/pricing/
- n8n. More executions: https://support.n8n.io/article/can-i-add-more-executions
- GitHub. Pages: https://docs.github.com/en/pages/getting-started-with-github-pages/what-is-github-pages
- GitHub. Custom workflows: https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages
- ElevenLabs. Widget: https://elevenlabs.io/docs/eleven-agents/customization/widget
- ElevenLabs. Webhook tools: https://elevenlabs.io/docs/eleven-agents/customization/tools/webhook-tools
- ElevenLabs. Conversation flow: https://elevenlabs.io/docs/eleven-agents/customization/conversation-flow
- ElevenLabs. Pricing: https://elevenlabs.io/pricing/agents
- W3C. WCAG 2.2 quick reference: https://www.w3.org/WAI/WCAG22/quickref/
