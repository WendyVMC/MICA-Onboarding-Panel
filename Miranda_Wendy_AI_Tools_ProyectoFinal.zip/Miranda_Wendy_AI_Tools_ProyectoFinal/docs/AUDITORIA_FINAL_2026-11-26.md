# Auditoría final de cumplimiento MICA

Fecha: 26 de noviembre de 2026. Fuente de requisitos: guía docente de 16 páginas, versión 30/10/2026. Alcance: revisión documental y de archivos locales; no se ejecutaron workflows, modelos, audio ni pruebas completas. No se comprobaron en vivo saldos, disponibilidad o URLs.

## Dictamen

**Aprobado con alertas para preparación; no certificado como 100% completo ni como verificación de funcionamiento actual.** El núcleo tiene evidencia de integración real. La entrega requiere consolidación documental y validación en la presentación. No se asigna calificación docente ni se convierte una simulación en prueba integrada.

## Contraste con la rúbrica y el paquete

| Criterio (guía p. 14) | Evidencia existente | Estado y límites |
|---|---|---|
| Caso e integración (5 pts) | Caso MICA, 3 KPI, arquitectura y folio compartido en trazas | Documentado; el panel cambió de corte después del ZIP |
| Ecosistema agéntico (15) | Orquestador determinista y cuatro especialistas; contratos, herramientas y trazas; ejecuciones 18, 20 y 25 | Integración ejecutada previamente; no revalidada hoy |
| n8n y Telegram (12) | Registro, generación, persistencia, aprobaciones, mensajes y exportaciones; error A3 conservado | Ejecuciones reales; rechazo, vencimiento y acceso ajeno se respaldan principalmente con pruebas controladas del código |
| Pages y Actions (10) | Panel público, exportación por lista blanca, validación; run fallido 44666974987 y recuperación 44667092748 | Ejecutado previamente; panel y ZIP actual corresponden a cortes distintos |
| Skills y loops (10) | Dos SKILL.md, dos LOOP.md, adaptador, hashes, V1 fallida→V2 válida, reutilización, 41 comprobaciones y ejecución n8n 11 | Existe autoevaluación por cinco aspectos fuera del ZIP; incluirla explícitamente al consolidar |
| ElevenLabs y VizData (14) | Una conversación real del piloto, dos herramientas exitosas, KPI, filtros y tabla; pruebas 390/1366 documentadas mediante iframes | La conversación del ensayo 082 no está acreditada. Permiso denegado y caída se simularon en el manejador; no equivalen a incidentes reales del proveedor |
| Guardrails (12) | Control de acceso, fuentes, esquema, presupuesto, aprobación/versiones y deduplicación | Hay evidencia mixta; no se acredita atomicidad concurrente ni un segundo usuario real |
| Tokenización y costos (10) | 34 llamadas en el ZIP, una conversación de 831 créditos, tarifas y 6 escenarios; ensayo adicional de 8 llamadas medido aparte | Consolidar 42 llamadas y subtotal calculado USD 0.00617610. Desarrollo, cargos finales e indexación no conciliados. Ahorro de optimización frente a LLM es potencial, no comparación monetaria A/B medida |
| Pruebas y reproducibilidad (7) | P01–P14 y sus rutas existen; README, manual, datos y diccionario; importaciones sanitizadas | Matriz completa como inventario, con alertas. Debe poder repetirse un caso por el evaluador; aún requiere acceso y disponibilidad |
| Defensa individual (5) | Guion y video de respaldo | Demostración, explicación y modificación/pregunta técnica pendientes de Wendy |

Los puntos son pesos de la guía, no puntos obtenidos por este proyecto.

## Comprobaciones efectuadas en esta auditoría

- ZIP: 177 archivos; 176 entradas de manifiesto cotejadas, sin diferencias. Archivo íntegro.
- Informe: 10 páginas, dentro de 8–12 exigidas, sin contar anexos.
- Video: 415 segundos (6:55), una pista de video y una de audio; dentro de 5–8 minutos. Es recorrido narrado de evidencias, no ejecución continua nueva.
- Pruebas: 14 filas y ninguna ruta de evidencia referida ausente en el ZIP.
- Dos skills, dos loops, contratos de agentes, exportaciones de 38 y 6 nodos y diccionario presentes.
- No se encontraron archivos .env reales, directorio privado ni patrones de tokens de bot/API/GitHub en los archivos textuales revisados. Un escaneo por patrones no constituye garantía universal de ausencia de secretos.
- Los workflows del ZIP se importan inactivos, sin pinData; las credenciales deben volver a vincularse según el manual.

## Diferencias materiales que deben resolverse antes de enviar

1. **Corte del paquete.** ZIP publicado original: 3 casos, 4 solicitudes, 75% de completitud y 34 llamadas. Archivos actuales del panel y evidencia del ensayo: 4 casos, 5 solicitudes, 80% y 8 llamadas nuevas. El folio público de voz pasó del 069 al 082. La exportación final real del principal del ensayo existe en privado y verifica IA apagada, límite USD 0.05 y ocho llamadas. Consolidar copias sanitizadas, costos, notas de corte, ZIP, manifiesto y publicación en un mismo estado final.
2. **Autoevaluación y textos antiguos.** `docs/11_SKILLS_LOOPS_MICA.md` contiene la tabla obligatoria de cinco aspectos (18/18/18/17), pero no se incluyó en el ZIP. El informe muestra totales. Se creó una copia explícita de la tabla en `docs/AUTOEVALUACION_SKILLS_LOOPS.md` para incorporarla al cierre. `agentes/README.md` y `voz/configuracion_guardada.json` describen preparaciones antiguas; deben identificarse como históricos o actualizarse para no contradecir las ejecuciones acreditadas.
3. **Costos e incertidumbre.** Incluir las ocho llamadas del ensayo una sola vez; no sumarlas dos veces al costo del caso. Conservar USD 5 como recarga reportada, sin confundirla con gasto o saldo. Para cumplir con mayor solidez el apartado de desarrollo, obtener su consumo/cargo o agregar una estimación defendible con método y límites; no inventarla ni usar cero. Mantener separado el ahorro hipotético de un ahorro medido.
4. **Pruebas de aceptación.** P04, P07–P10 y P13 tienen componentes controlados/locales; no se afirma que toda la matriz se haya ejecutado de punta a punta en plataformas. En clase verificar las rutas necesarias con autorización y límites; no provocar una caída externa ni repetir llamadas completas por rutina. El rechazo nativo del micrófono se puede comprobar sin iniciar una conversación de pago si la interfaz lo permite.
5. **Acceso y defensa.** Confirmar disponibilidad de n8n y ElevenLabs y permisos para la docente. El 21/11 n8n mostraba 9 días de prueba; eso es un dato histórico, no certifica vigencia al presentar. No se verificaron saldos actuales. La generación estaba apagada al cerrar el ensayo. Definir el folio y modo de acceso antes de la presentación; realizar la defensa individual de hasta 12 minutos y el envío al aula.

## Registro del loop de control de calidad

| Paso | Control realizado | Resultado |
|---|---|---|
| Interpretar | Auditar requisitos sin repetir el ensayo hasta clase | Alcance limitado a documentos y archivos |
| Revisar datos | Guía completa contrastada con ZIP, manifiesto, matriz, trazas, costos y ensayo | Fuentes y cortes identificados |
| Diagnosticar | Separar integración real, pruebas controladas y pendientes | Núcleo acreditado históricamente; cierre parcial |
| Auditar | Integridad, rutas, cantidades, formatos, totales y contradicciones | Cinco grupos de alertas identificados |
| Corregir | Retirar afirmación de cumplimiento absoluto; registrar corte y tabla completa de autoevaluación | Registro actualizado; no se alteran resultados ni servicios |
| Comunicar | Tabla por rúbrica, evidencias y lista concreta de cierre | No se atribuyen notas ni pruebas inexistentes |
| Decidir | Aprobado con alertas para preparación | Cierre final después de consolidación y defensa |

Responsable de consolidación técnica: asistente con autorización vigente para archivos locales; publicación y consumo conforme a confirmación de la usuaria. Responsable de defensa y envío: Wendy. Indicador de cierre: una única versión con commit/ZIP cotejados, P01–P14 con evidencia/tipo explícitos y un caso repetible. Próxima revisión: antes del envío y el día de la presentación; sin fecha inventada.
