# Manual para importar, repetir y detener MICA

## Dónde corre cada componente

Pages sirve el panel estático; Actions valida y publica. n8n Cloud conserva la tabla, Telegram y los cuatro agentes. ElevenLabs hospeda la voz y llama al servicio autenticado de n8n. El servidor Python solo sirve la vista local; no sustituye Cloud ni debe permanecer encendido para que Pages funcione.

## Requisitos y versiones

Node 22 recomendado para las pruebas; medición local realizada también con Node 24.22.1. Python 3.9+ para exportaciones (zoneinfo) y Python con ReportLab/pypdf para reconstruir el informe. No se incluyen dependencias pesadas en el ZIP. Las versiones de tipos de nodos se conservan en los JSON exportados; no se afirma un build de n8n Cloud no observado. Modelo medido: gpt-4o-mini-2024-07-18, Chat Completions, salida máxima 1800, timeout 30000 ms, retry 0. Agentes con máximo dos iteraciones; loops hasta tres. Agente de voz v2 fue el usado en la prueba registrada; cambios posteriores del panel no implican repetir el audio.

## Importar n8n

1. Importar `n8n/MICA_Principal_Entrega.json`, `n8n/MICA_Voz_Entrega.json` y opcionalmente `n8n/mica_skills_loops_prueba.json` desde el menú Import. Permanecen inactivos al importar.
2. Crear una tabla privada con columnas string `clave`, `tipo`, `estado`, `payload`. Volver a seleccionar esta tabla en todos los nodos Data Table de ambos workflows; los IDs del proyecto original no dan acceso a otra cuenta.
3. Crear la credencial Telegram e introducir el token únicamente en n8n. Vincularla al único Telegram Trigger y al nodo de respuesta. No usar un segundo webhook o polling para el mismo bot.
4. En `Validar acceso MICA`, reemplazar `REEMPLAZAR_ID_AUTORIZADO` por el ID propio verificado. Mantener el chat privado. El usuario interno 0 solo sirve para fixtures manuales, no es acceso público.
5. Vincular Gateway credits o una credencial de modelo compatible a los cuatro nodos Modelo A1..A4. Revisar tarifa, saldo, modelos y límites antes de una llamada. Los JSON no contienen credenciales utilizables.
6. Crear Header Auth con Name `x-mica-key` y contraseña nueva larga en Value. Vincularla al webhook de voz. Guardar el mismo valor en un secreto de ElevenLabs; nunca en el código ni en el HTML.
7. Publicar el flujo principal para registro/consulta. Se entrega `HABILITAR_IA=false`. Publicar el servicio de voz solo después de revisar autenticación y el único folio ficticio permitido.

## Repetir un caso completo de evaluación

1. Elegir una fecha de ingreso futura, al menos siete días después de la defensa; las actividades anteriores al ingreso conservan su fecha y no se reprograman si ya vencieron.
2. En el bot propio, enviar `/nuevo DEP-COM P-COM-01 AAAA-MM-DD hibrida`. El registro y consulta no llaman modelos. Anotar el folio devuelto.
3. Con un presupuesto aprobado para hasta ocho llamadas, en `Enrutar y deduplicar` colocar **solo ese folio** dentro de `CASOS_AUTORIZADOS` y cambiar `HABILITAR_IA` a true. Publicar. No utilizar los folios ya cerrados para forzar otra generación.
4. Enviar `/generar FOLIO 0`. Esperar la propuesta versión 2: Comercial híbrido tiene nueve actividades. Ver la ejecución y los cuatro especialistas; revisar fuentes, fechas y responsables.
5. Solo después de revisión humana enviar `/aprobar FOLIO 2` o `/rechazar FOLIO 2`. La decisión correcta devuelve versión 3. Una propuesta pendiente vence a las 24 h al intentar la acción; no existe un barrido automático de vencimientos. `/estado FOLIO` lee persistencia.
6. Desactivar IA y publicar al terminar. Una generación nueva requiere autorización y un nuevo caso. No pulsar Execute workflow del Trigger de Telegram mientras está activo el receptor de producción.

## Recrear ElevenLabs

Crear agente vacío, español, voz disponible, sin Architect. Copiar `voz/instrucciones_mica.md`, el primer mensaje de `voz/configuracion_guardada.json` si está disponible y la base `voz/base_conocimiento_mica.md`. Adjuntar `consultar_caso` y `solicitar_revision` con POST al webhook de producción `/webhook/mica-voz-v1`, cabecera x-mica-key de tipo Secreto y su referencia. Usar los esquemas sanitizados de `voz/`; conservar enum de folio y acción, versión integer para revisión, timeout 20 s y sin URLs arbitrarias. Cambiar el único folio permitido en servidor, herramientas y panel si se desea otro caso de evaluación; no ampliar a datos privados.

Publicar el agente; incluir solo el dominio del propio Pages en allowlist. Límites de prueba: 60 s, silencio 20 s, tres llamadas diarias, una simultánea, sin ráfagas ni archivos. No extender cuotas ni comprar sin aprobación. Sustituir el identificador público del agente en `panel/app.js` por el propio; no es una API key. Crear secreto compartido desde la interfaz segura, no por este README.

## Publicar y actualizar el panel

Ejecutar `node tests/panel.test.js`, `node tests/voz_preflight.test.js`, y `node tools/validar_panel.js`. Para vista local: `python3 -m http.server 8765 --bind 127.0.0.1 --directory panel`; detener con Ctrl+C. Pages usa `.github/workflows/pages.yml` en main y Settings > Pages > GitHub Actions. El artefacto solo contiene los cinco archivos del panel. Los directorios privado y _qa no se publican.

Exportar CSV de MICA_registros con columnas del sistema hacia una carpeta privada. Usar `tools/exportar_panel.py ENTRADA --corte AAAA-MM-DD --periodo AAAA-MM --incluir-casos FOLIOS`; `--solicitudes-completas` solo con un censo comprobado de todos los /nuevo autorizados, incluidos inválidos y excluidos duplicados. No trasladar marcas de la decisión actual a una primera revisión sin evidencia. `exportar_cierre_lote003.py` reproduce únicamente la auditoría del piloto con sus fuentes privadas, que no se redistribuyen. Para otros casos usar el exportador genérico.

Hacer commit del JSON sanitizado; Actions verifica y despliega. El panel es una instantánea manual: los cambios privados posteriores no aparecen hasta la siguiente exportación y commit. Antes de evaluar, actualizar corte y esperar Actions exitoso. No repetir el fallo deliberado: ya existen enlaces y registros.

## Parada, disponibilidad y diagnóstico

Cerrar llamada en el widget o retirar consentimiento; el retiro recarga la página y cierra sus conexiones. Despublicar los workflows solo si se quiere detener Telegram/voz; IA=false detiene modelos pero mantiene consulta. Mantener activa la cuenta n8n durante la evaluación: una prueba vencida deja inaccesibles webhooks. No se conoce una fecha de evaluación distinta a la que confirme la docente.

Auth wrong: comparar las claves en los dos almacenes sin enviarlas por chat. Bot silencioso: un solo receptor, credencial y usuario permitidos. Sin saldo: detener y pedir autorización; no recargar automáticamente. Voz: aceptar primero, comprobar micrófono, no compartir datos reales, usar Telegram si se deniega o falla. API caída: timeout y error controlado, plan=null, sin aprobación; no reiniciar todo el caso por rutina. Si un modelo devuelve un envoltorio inesperado, conservar la evidencia y recuperar solo el componente validado. La deduplicación es secuencial y no prueba atomicidad concurrente.
