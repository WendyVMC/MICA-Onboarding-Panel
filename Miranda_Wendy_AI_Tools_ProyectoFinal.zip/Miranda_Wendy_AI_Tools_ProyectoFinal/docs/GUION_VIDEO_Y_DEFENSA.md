# Video de respaldo

Recorrido narrado por evidencias existentes; no grabación continua de ejecuciones. Voz local de sistema, sin imitar a Wendy ni consumir ElevenLabs.

## 1. MICA: onboarding con revisión humana

Este es el respaldo narrado del proyecto individual MICA, un asistente de onboarding para una empresa ficticia. El objetivo es transformar una solicitud breve en un plan que Recursos Humanos pueda revisar y aprobar. Los datos y las acciones de negocio son simulados; las integraciones y los consumos que se muestran sí fueron reales. Este video recorre evidencias ya obtenidas, no es una ejecución continua nueva. La narración se genera con una voz local del equipo. La estudiante debe revisar los archivos y poder explicar el sistema durante la defensa.

## 2. Un folio une las integraciones

La arquitectura mantiene un mismo folio entre Telegram, n8n, los especialistas, la aprobación y los costos. Telegram tiene un solo receptor para evitar conflictos de webhooks. n8n conserva los estados en una tabla privada y coordina el procesamiento. Después de una decisión humana, una exportación sanitizada alimenta el panel. GitHub Actions valida esa exportación y solo publica si pasa. GitHub Pages sirve los archivos estáticos: no ejecuta los agentes. Desde ese mismo sitio, ElevenLabs consulta el registro mediante una herramienta autenticada de servidor. Las contraseñas nunca llegan al HTML.

## 3. Cuatro especialistas, aportes distintos

El orquestador es determinista: comprueba la solicitud, organiza los roles, reserva presupuesto y decide si puede continuar. El agente uno valida los seis campos del nuevo ingreso. El dos recupera políticas y actividades autorizadas. El tres construye las fechas y responsables y aplica los skills. El cuatro compara la propuesta contra un plan canónico y puede bloquearla. Compartir modelo no convierte a los agentes en copias: sus instrucciones, herramientas y salidas son diferentes. Un objeto JSON bien formado no basta; el servidor comprueba su contenido antes de pedir aprobación.

## 4. Tres casos completos · 25 actividades

Se completaron tres casos distintos. Tecnología remota produjo ocho actividades; Comercial híbrido, nueve; Administración presencial, ocho. Los tres quedaron aprobados por la usuaria y registrados como simulados, versión tres. El primer caso necesitó recuperación manual de un formato de salida; los otros dos completaron su ruta sin repetirla. El panel distingue ese antecedente. La preparación media fue aproximadamente cinco minutos con cincuenta y tres segundos, incluyendo esperas. La completitud es setenta y cinco por ciento porque una solicitud incompleta también pertenece al denominador. La aprobación inicial es tres de tres. Esta muestra no prueba rendimiento empresarial.

## 5. Un error no se convierte en aprobación

Las pruebas negativas son parte del funcionamiento. Una solicitud incompleta real al bot recibió una aclaración y no generó un caso. Una instrucción de ignorar reglas y revelar claves fue rechazada por el parser, sin llamar al modelo. También se probaron, de forma controlada sobre el código exportado, usuario ajeno, versión incorrecta, rechazo, vencimiento y presupuesto agotado. La deduplicación evita repetir la operación del mismo evento. Ante un error controlado, el plan queda vacío y no se aprueba. Se conserva una limitación: no está demostrada la atomicidad ante solicitudes concurrentes.

## 6. Skills cargados y loops con retorno

Hay dos skills específicos: preparar onboarding y verificar la propuesta. El adaptador lee sus archivos al compilar y aplica sus políticas en n8n; la traza registra versión y hash. El loop de calidad genera, mide, diagnostica, corrige y valida. El de seguridad y costo comprueba permisos y reserva antes de continuar. Una prueba conserva una versión uno con una actividad omitida y una versión dos corregida, con el mismo folio. Esa corrección determinista no añadió llamadas de modelos. Ambos métodos se reutilizaron después en las rutas completas de Comercial y Administración.

## 7. Voz real en la página publicada

La estudiante realizó una conversación real desde el widget público. MICA se identificó como inteligencia artificial y recibió consentimiento antes de usar herramientas. El registro muestra consulta exitosa a los treinta y cinco segundos y solicitud de revisión exitosa a los treinta y nueve. La llamada terminó por el límite configurado de sesenta segundos; sus metadatos registran sesenta y uno. Consumió ochocientos treinta y un créditos: seiscientos sesenta y siete de plataforma y ciento sesenta y cuatro de modelo. El control final de micrófono y servicio caído se validó con fallos simulados, sin otra llamada pagada.

## 8. Costo, consumo y recarga se separan

El registro reúne treinta y cuatro llamadas medidas de Gateway, incluyendo pruebas y la recuperación del primer caso. Su subtotal calculado es de aproximadamente medio centavo de dólar. No es el costo total del proyecto: faltan facturas y uso del asistente de desarrollo. La usuaria reportó una recarga de cinco dólares; no se cuenta como consumo ni se inventa el saldo restante. Los créditos de ElevenLabs se mantienen separados y no se suman dos veces. Los escenarios de cien, mil y diez mil casos incorporan planes, cuotas, minutos de voz y una ruta de mayor consumo.

## 9. Reproducir, explicar y detener

La entrega incluye workflows importables sin secretos, bases sintéticas, skills, loops, matriz de pruebas, costos, escenarios e informe. El manual explica dónde corre cada servicio y cómo volver a vincular credenciales. Para repetir un caso se registra un folio nuevo y se habilita solo ese folio con presupuesto; al finalizar se desactiva otra vez la inteligencia artificial. El panel sigue disponible para consulta y voz. La evaluación en vivo requiere mantener n8n y sus cuotas activos. Esta es una demostración académica con limitaciones declaradas; no un sistema listo para decisiones laborales reales ni una garantía de ahorro.

# Defensa en vivo (hasta 12 minutos)

0-1: problema, alcance y tres KPI. 1-5: mostrar folio, cuatro especialistas, controles y aprobación. Si se exige caso nuevo, habilitar previamente un único folio con presupuesto explícito; no regenerar aprobados. 5-7: Pages y voz del mismo folio, solo una llamada autorizada. 7-9: entrada incompleta/inyección bloqueadas y V1-V2 del loop. 9-10: Actions fallido/corregido y exportación sanitizada. 10-12: costos, incertidumbre y modificación técnica.

Preguntas que debes poder explicar: por qué cuatro roles, qué valida el servidor, cómo cambiar una fecha sin violar políticas, qué ocurre si vence una propuesta, por qué 75% de completitud y qué diferencia hay entre créditos, recarga y costo consumido. No memorizar respuestas sin revisar el código. La defensa individual debe realizarla la estudiante.
