# Checklist de entrega · 21/11/2026

- [x] Cinco roles, folio común, cuatro especialistas y controles deterministas.
- [x] Tres casos completos con modalidades distintas y aprobación humana explícita.
- [x] Entrada única Telegram, persistencia, versiones y fallos controlados.
- [x] Dos skills y dos loops integrados; corrección V1→V2 y reutilización demostradas.
- [x] Pages con tres KPI, filtros, gráfica, tabla y accesibilidad revisada.
- [x] Actions: bloqueo por validación y recuperación reales.
- [x] ElevenLabs: conversación real, consulta y revisión del mismo folio autenticadas.
- [x] P01–P14 documentadas; fallos simulados se identifican expresamente.
- [x] Costos, recarga reportada y consumo separados; escenarios base y alto.
- [x] Informe de 10 páginas, manual reproducible, datos y declaración de IA.
- [x] Video narrado de 6:55 con evidencias; no nueva ejecución continua.
- [x] Paquete sanitizado con manifiesto SHA-256 y pruebas locales aprobadas.
- [x] Archivo final preparado para el repositorio; el recibo externo registra el commit y el cotejo de descarga al publicar.
- [ ] Wendy revisa el informe, ensaya su defensa de máximo 12 minutos y sube la entrega al aula.

Alertas: mantener disponibles n8n y ElevenLabs; las credenciales se vinculan al importar. IA apagada tras los ensayos. Facturación final y consumo del desarrollo no conciliados. No se prueban concurrencia ni permisos nativos denegados como incidentes reales.
