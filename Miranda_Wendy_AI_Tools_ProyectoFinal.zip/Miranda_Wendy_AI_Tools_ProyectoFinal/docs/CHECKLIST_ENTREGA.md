# Checklist vigente · entrega v2 · 26/11/2026

## Archivos y evidencia histórica

- [x] Cuatro casos completos con cinco roles y aprobación humana explícita.
- [x] Dos skills y dos loops; carga, corrección V1→V2, reutilización y tabla de autoevaluación de cinco aspectos.
- [x] Telegram/n8n con persistencia, comandos, errores y versiones; IA apagada en exportación final.
- [x] Panel con 4 casos, 33 actividades, completitud 80% y procedencia de cada marca.
- [x] Publicación y bloqueo por Actions acreditados históricamente.
- [x] Una conversación real del folio 069 y consulta autenticada real del folio 082; sin atribuir una nueva conversación no observada.
- [x] 42 llamadas únicas y subtotal calculado USD 0.00617610; una voz de 831 créditos; recarga USD 5 separada.
- [x] Seis escenarios, sensibilidad de desarrollo explícita y comparación offline de calidad/costo.
- [x] Informe de 10 páginas, video histórico de 6:55, manual y declaración de IA.
- [x] P01–P14 con tipos de evidencia; no se convierten pruebas simuladas en pruebas de servicio.

## Cierre externo y presentación

- [ ] Publicar v2 después de confirmación y cotejar hash/commit contra el mismo ZIP local.
- [ ] Comprobar vigencia, acceso docente y cuotas antes de presentar; saldos históricos no garantizan saldo actual.
- [ ] Ejecutar una sola prueba completa y conversación del nuevo folio el día acordado, con presupuesto autorizado.
- [ ] Comprobar las variantes de aceptación pendientes o declarar su alcance controlado ante la docente.
- [ ] Wendy revisa, explica y defiende el proyecto en máximo 12 minutos; sube el ZIP al aula.

Límites: factura y tokens reales de desarrollo no disponibles; proxy de contenido documentado, no cifra real. Atomicidad concurrente no acreditada. Consultar ESTADO_VIGENTE.md. No se garantiza puntaje docente.
