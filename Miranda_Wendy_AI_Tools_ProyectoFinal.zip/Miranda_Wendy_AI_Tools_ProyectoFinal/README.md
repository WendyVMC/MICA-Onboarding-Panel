# MICA - Proyecto final individual de AI Tools

Wendy Miranda · entrega académica · 26/11/2026 · rama main; mediciones operativas hasta el 21/11/2026.

## Abrir primero

- Índice por rúbrica: [docs/INDICE_RUBRICA.md](docs/INDICE_RUBRICA.md).

- Panel público: https://wendyvmc.github.io/MICA-Onboarding-Panel/
- Informe: [output/pdf/MICA_Informe_Final.pdf](output/pdf/MICA_Informe_Final.pdf), 10 páginas.
- Manual reproducible: [docs/MANUAL_REPRODUCCION.md](docs/MANUAL_REPRODUCCION.md).
- Registro: [costos.csv](costos.csv), [costos/RESUMEN_Y_METODO.md](costos/RESUMEN_Y_METODO.md) y [costos/escenarios.csv](costos/escenarios.csv).
- Matriz obligatoria: [pruebas.csv](pruebas.csv). Revisa la columna tipo_evidencia: hay pruebas reales, mixtas y simulaciones controladas.
- Respaldo: [output/video/MICA_Respaldo.mov](output/video/MICA_Respaldo.mov). Recorrido narrado de evidencias, no grabación continua de nuevas ejecuciones. Voz local de sistema, no clonación ni nueva llamada ElevenLabs.

## Resultado y alcance

Cuatro casos ficticios completos: Tecnología remota (8 actividades en piloto y 8 en ensayo), Comercial híbrido (9) y Administración presencial (8). Cinco roles trazables, dos skills y dos loops integrados, aprobaciones humanas explícitas, registro privado y publicación sanitizada. Una conversación real en español usó ambas herramientas del mismo folio. No hay operaciones reales de empleo, nómina ni accesos.

El KPI de completitud incluye una solicitud incompleta real: cuatro completas de cinco recibidas, 80%. Aprobación inicial 4/4; preparación media 0.082243 h/caso, que incluye esperas. Tres casos tienen marcas directas y el legado conserva reconstrucciones auditadas. No se afirma representatividad, ahorro ni ROI.

Se midieron 42 llamadas Gateway, con fallos y recuperación conservados; la voz consumió 831 créditos. El costo calculado Gateway es USD 0.00617610. El cargo final y los tokens reales del desarrollo no están disponibles; se incluye una sensibilidad reproducible separada en costos/DESARROLLO_ESTIMACION.md. La usuaria reportó una recarga de USD 5, separada del consumo. Los escenarios son proyecciones con cuotas y supuestos, no una contratación.

## Reproducir sin llamadas de pago

Node 22 recomendado; también probado con Node 24.22.1. Python 3.9+ para exportación. Desde raíz:

```sh
node tests/panel.test.js
node tests/voz_preflight.test.js
node tests/guardrails_entrega.test.js
node tests/kpi_registro.test.js
node tests/skills_loops.test.js
python3 -m http.server 8765 --bind 127.0.0.1 --directory panel
```

Abrir http://127.0.0.1:8765/; parar con Ctrl+C. Estos tests usan datos ficticios y no llaman APIs. La voz del agente publicado solo admite su host autorizado. La prueba de permisos denegados/servicio caído es una simulación del manejador real; no se presenta como un incidente externo real.

## Importar y operar

Importar `n8n/MICA_Principal_Entrega.json` y `n8n/MICA_Voz_Entrega.json`. Están inactivos y sin secretos/pinData/IDs de autorización personales. Crear tabla y volver a vincular Telegram, Gateway y Header Auth en los nodos descritos en el manual. Reemplazar `REEMPLAZAR_ID_AUTORIZADO` por el ID propio, verificado de forma privada. Un solo receptor de Telegram por bot.

El flujo se entrega con `HABILITAR_IA=false`: registrar y consultar no llama modelos. Para una ejecución nueva, registrar `/nuevo`, obtener folio, permitir solo ese folio y habilitar IA con presupuesto aprobado; publicar y enviar `/generar FOLIO 0`. Revisar la versión 2 y aprobar o rechazar explícitamente. Desactivar IA al terminar. No regenerar casos cerrados. El manual detalla fecha futura, resultado esperado, límites, parada y diagnóstico.

La tabla de esta entrega es una instantánea, no una conexión de datos en vivo. Actualizar desde CSV privado con el exportador de lista blanca, hacer commit y esperar Actions. Pages no ejecuta n8n. Las credenciales y fuentes privadas de auditoría no se entregan: para repetir la exportación se usa un CSV propio, no se inventan datos faltantes.

## Enlaces de evidencia

- Bot del proyecto: https://t.me/mica_wvmc_onboarding_bot . El acceso operativo requiere autorización privada; solicitarlo a Wendy por el canal del curso, sin enviar tokens.
- Actions correcto: https://github.com/WendyVMC/MICA-Onboarding-Panel/actions/runs/44667092748
- Actions bloqueado: https://github.com/WendyVMC/MICA-Onboarding-Panel/actions/runs/44666974987
- Actualización tres casos: https://github.com/WendyVMC/MICA-Onboarding-Panel/actions/runs/44981577796
- Índice: [evidencias/INDICE.md](evidencias/INDICE.md).

`MANIFEST_SHA256.json` identifica el árbol de entrega. La rama y el commit final se indican en el recibo de publicación externo; no se incrusta un hash autorreferencial dentro del propio archivo. El repositorio publica este mismo archivo de entrega; el código completo organizado está dentro del ZIP y el panel está además desplegado por separado. La carpeta `privado/`, tokens, claves, exportaciones completas de conversaciones y audios personales están excluidos.

## Límites, autoría y defensa

IA desactivada tras los ensayos; límites de voz 60 s/tres llamadas diarias y una simultánea. La vigencia se comprueba al intentar una acción; deduplicación secuencial sin garantía concurrente. Se necesita n8n disponible y cuotas vigentes en la evaluación. No se cambia de plan ni recarga automáticamente.

Revisar [docs/DECLARACION_IA_Y_FUENTES.md](docs/DECLARACION_IA_Y_FUENTES.md), fuentes y licencias de terceros. Datos ficticios propios para evaluación; no se declara una licencia abierta no elegida. La estudiante debe revisar el informe y realizar su defensa individual, máximo 12 minutos. El video no sustituye acceso funcional ni una explicación propia.


## Cortes y cierre

Leer docs/ESTADO_VIGENTE.md. El video es respaldo histórico de tres casos; informe y panel consolidan cuatro. La conversación real histórica consultó el 069; el único folio actual documentado es el 082, cuya voz se reserva para presentación. Los estados y saldos del servicio son observaciones históricas, no certificación actual. docs/AUTOEVALUACION_SKILLS_LOOPS.md contiene las puntuaciones por cinco aspectos. La auditoría del 26/11 documenta el estado previo a esta consolidación; el estado vigente aclara las correcciones.
