# Voz ↔ n8n · preparación 2026-11-16

## Conversación real verificada · 21/11/2026

La usuaria completó una sola llamada desde el widget público. Registro ElevenLabs `conv_1101m80kybynen8a7cf6vjnqfdv6`, agente v2: estado Exitoso, 61 s de metadatos frente a 59 s en reproductor, límite configurado de 60 s y aviso explícito de cierre por duración máxima. Transcripción inspeccionada: divulgación y consentimiento previos; `consultar_caso` Exitoso a 0:35 y `solicitar_revision` Exitoso a 0:39, ambos antes del cierre. No se repitió la conversación.

Consumo observado: 831 créditos = 667 de plataforma + 164 de LLM; seis turnos facturados. UI muestra 0,0154 $ de LLM como desglose, no cargo monetario total ni un importe adicional a sumar a los créditos. Evidencia y costos guardados en `evidencias/voz_conversacion_real_2026-11-21.json` y `costos/voz_conversaciones.csv`.

Esto valida voz interactiva en español y uso de ambas herramientas en conversación. No prueba por sí solo micrófono denegado ni nueva revisión duplicada; el servicio ya tenía una petición de revisión previa para esa versión. Siguen pendientes la prueba específica de micrófono denegado, revisión móvil de la sección nueva y los requisitos generales restantes. Las secciones siguientes son históricas.

## Widget público preparado · 21/11/2026

La configuración del agente se publicó desde el diálogo de revisión: español, fuentes MICA, dos herramientas autenticadas y límites de 60 s/llamada, cierre tras 20 s de silencio, tres llamadas/día, una concurrente, sin ráfagas, cola, adjuntos ni turno especulativo; host permitido wendyvmc.github.io. El panel público incorpora consentimiento previo por visita, carga diferida del widget, retiro del consentimiento y alternativa Telegram. La publicación del widget pasó Actions (`44979306898`).

Se comprobó carga del widget sin iniciar conversación y retiro del consentimiento (script/elemento ausentes tras recarga). Una conversación real, medición de consumo, prueba de micrófono denegado y nueva comprobación móvil de voz siguen pendientes. No se debe confundir carga del widget o pruebas manuales de herramientas con voz interactiva ya validada. Evidencia: `evidencias/voz_widget_2026-11-21.json`.

## Conexión validada · 21/11/2026

- [x] La usuaria reemplazó la contraseña de n8n y creó `MICA_N8N_KEY_V2` en ElevenLabs. No se leyó ni guardó su valor en archivos.
- [x] Ambas herramientas guardadas con cabecera `x-mica-key`, tipo Secreto, referencia `MICA_N8N_KEY_V2`.
- [x] Consulta manual real exitosa desde ElevenLabs a producción n8n: caso `MICA-TG-479895069`, `registrado_simulado`, versión 3, ocho actividades, aprobación por voz prohibida. Evidencia `evidencias/voz_consulta_real.json`.
- [x] Solicitud de revisión real ejecutada con la versión 3 obtenida de la consulta: `REVISION-VOZ-MICA-TG-479895069-v3`, `pendiente_rh`, `duplicado:false`. Respuesta confirma que no cambia el plan ni su aprobación. Evidencia `evidencias/voz_revision_real.json`.
- [x] Las dos pruebas fueron formularios de parámetros manuales; sin conversaciones, audio ni llamadas a modelos. El rechazo inicial permanece documentado; no se oculta ni reemplaza como si hubiera sido éxito.
- [ ] Voz interactiva, publicación del agente y widget con consentimiento previo: todavía pendientes. Estas pruebas de herramientas NO demuestran aún una conversación completa de voz.

Las secciones siguientes conservan la historia anterior. El estado vigente es esta sección. Plataforma: consumo/facturación de las peticiones HTTP pendiente de cotejar con el uso de la cuenta; no se presume costo cero de plataforma.

## Actualización verificada · 21/11/2026

### Publicación y primera prueba autorizadas

Servicio n8n publicado con versión `MICA voz - servicio autenticado y caso simulado`. Una consulta manual desde ElevenLabs devolvió `Authorization data is wrong!`; por tanto, **la conexión todavía no está validada**. No se repitió ni se ejecutó la escritura dependiente. Nombres de cabecera comprobados en ambos lados: `x-mica-key`. Se dejó abierto el campo privado de n8n para que la usuaria vuelva a pegar la misma contraseña; el valor nunca se leyó ni se registró. Evidencia: `evidencias/voz_prueba_2026-11-21.json`. El checklist de configuración siguiente es histórico; publicación ya completada, pruebas funcionales pendientes.

- [x] Usuario confirmó que guardó la contraseña en n8n; el webhook tiene seleccionada `Header Auth account`. No se inspeccionó el valor.
- [x] Secreto existente en ElevenLabs identificado por nombre `x-mica-key` (el usuario usó este nombre en lugar del sugerido MICA_N8N_KEY).
- [x] Cabecera `x-mica-key`, tipo Secreto, enlazada y guardada en `consultar_caso` y `solicitar_revision`. No quedan cambios sin guardar en el formulario revisado.
- [ ] Activar/publicar servicio n8n con autorización explícita.
- [ ] Pruebas reales de consulta y solicitud de revisión, acotadas y sin modelos si la interfaz ofrece entrada manual.
- [ ] Confirmar igualdad efectiva de las claves mediante autenticación real; el hecho de que ambas estén guardadas no demuestra que coincidan.
- [ ] Publicación del agente, consentimiento previo en widget y prueba de voz autorizada con registro de consumo.

No hubo llamadas a herramientas ni conversaciones durante este enlace de configuración. La evidencia de pantalla `entregables/elevenlabs_herramienta_autenticada.png` solo muestra la referencia al secreto, nunca su valor. Las notas de preparación siguientes describen el estado histórico, anterior a esta actualización.

## Guardado, sin activar

- Workflow n8n `MICA - Herramientas voz autenticadas BORRADOR`, ID `BaQKPbfECggsfWeP`, con seis nodos, sin modelos y autenticación nativa Header Auth pendiente.
- Entrada POST prevista: https://valemir.app.n8n.cloud/webhook/mica-voz-v1
- Lee tabla MICA_registros `T8bvKOkKmBD7At3g` y solo permite caso ficticio `MICA-TG-479895069`.
- `consultar_caso` devuelve plan/estado/versión sin identificadores Telegram, datos de autorización ni registros privados.
- `solicitar_revision` exige versión vigente y crea una fila de revisión pendiente de RH. No cambia el caso ni su aprobación. Deduplicación secuencial por folio y versión, sin demostrar atomicidad concurrente.
- Ambas herramientas webhook creadas y adjuntas al borrador de MICA en ElevenLabs. Cuerpo POST, enum de acción y caso; 20 s, sin redirecciones. Todavía no tienen la cabecera secreta, por lo que no se consideran conectadas ni listas para ejecutar.
- 25 comprobaciones locales de lógica, rechazo de campos/acciones/versiones y filtrado de datos privados: evidencias/validacion_voz_local.json. No acredita autenticación ni ejecución real entre plataformas.

## Paso humano pendiente

Formulario Header Auth abierto en n8n. Campo Name prellenado `x-mica-key`. La estudiante debe generar una clave nueva larga, introducirla en Value y guardar. No usar token Telegram ni claves de otros servicios. Guardar la misma clave en el almacén secreto de ElevenLabs y referenciarla desde la cabecera x-mica-key de ambas herramientas; no escribirla en prompts, archivos públicos o chat.

No se publicó el workflow ni el agente. No se escucharon eventos, hicieron peticiones HTTP de prueba o conversaciones de voz. Falta autorización de activación y pruebas acotadas después de revisar credenciales y URL.

Referencia oficial consultada: https://elevenlabs.io/docs/eleven-agents/customization/tools/webhook-tools (cabeceras secretas para autenticación).
