# Configuración vigente documentada

Consolidación 26/11/2026; última configuración observada 21/11, sin revisión de servicio en vivo hoy. Agente público MICA, español, voz Eric, DeepSeek Flash 4.1, consentimiento antes de herramientas. Un folio ficticio permitido: **MICA-TG-479895082**. Herramientas consultar_caso y solicitar_revision con POST /webhook/mica-voz-v1 y Header Auth x-mica-key. La contraseña se mantiene solo en almacenes de secretos.

Servidor, enum de ambas herramientas y folio del panel se cambiaron del 069 al 082. Consulta manual autenticada del 082 devolvió registrado_simulado v3. La conversación real histórica corresponde al 069: 831 créditos, dos herramientas exitosas. No se acredita todavía una conversación del 082. Límites documentados: 60 s, silencio 20 s, tres llamadas diarias y una simultánea. No se atribuyen saldos del 21/11 al día actual.

Para recrear: usar instrucciones_mica.md, base_conocimiento_mica.md y esquemas de herramientas; volver a vincular credenciales. El archivo configuracion_guardada.json es histórico. La voz del ensayo y disponibilidad se verifican en presentación.
