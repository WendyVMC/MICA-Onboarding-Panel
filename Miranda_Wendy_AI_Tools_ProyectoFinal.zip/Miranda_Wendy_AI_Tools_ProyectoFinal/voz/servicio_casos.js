// Solo un caso de demostración autorizado; nunca devuelve identificadores privados.
function validarPeticionVoz(body){
 if(!body||typeof body!=='object'||Array.isArray(body))throw Error('ESQUEMA_INVALIDO');
 if(JSON.stringify(body).length>600)throw Error('PETICION_EXCESIVA');
 const keys=['accion','caso_id','version'];if(Object.keys(body).some(k=>!keys.includes(k)))throw Error('CAMPO_NO_PERMITIDO');
 if(!['consultar_caso','solicitar_revision'].includes(body.accion))throw Error('ACCION_NO_PERMITIDA');
 if(body.caso_id!=='MICA-TG-479895069')throw Error('CASO_NO_ACCESIBLE');
 if(body.version!==undefined&&(!Number.isSafeInteger(body.version)||body.version<0))throw Error('VERSION_INVALIDA');
 if(body.accion==='solicitar_revision'&&body.version===undefined)throw Error('VERSION_REQUERIDA');
 return {...body};
}
function procesarVoz(peticion,filas,ahora=new Date()){
 try{
  const p=validarPeticionVoz(peticion);
  const row=filas.find(x=>x.tipo==='caso'&&x.clave==='CASO-'+p.caso_id);if(!row)throw Error('CASO_NO_ACCESIBLE');
  let c;try{c=JSON.parse(row.payload)}catch{throw Error('REGISTRO_INVALIDO')}
  if(c.caso_id!==p.caso_id||c.modo!=='SIMULADO'||!Number.isSafeInteger(c.version)||!Array.isArray(c.plan?.actividades))throw Error('REGISTRO_INVALIDO');
  if(c.plan.actividades.length>30)throw Error('REGISTRO_INVALIDO');
  const safe={caso_id:c.caso_id,modo:'SIMULADO',estado:c.estado,version:c.version,actividades:c.plan.actividades.map(a=>({actividad_id:a.actividad_id,fecha:a.fecha,responsable_id:a.responsable_id,regla_id:a.regla_id})),aprobacion_por_voz_permitida:false};
  if(p.accion==='consultar_caso')return {http_status:200,escritura:false,respuesta:{ok:true,...safe}};
  if(p.version!==c.version)throw Error('VERSION_DESACTUALIZADA');
  if(!['pendiente_aprobacion','registrado_simulado'].includes(c.estado))throw Error('ESTADO_NO_REVISABLE');
  const clave='REVISION-VOZ-'+c.caso_id+'-v'+c.version;const previo=filas.find(x=>x.clave===clave);
  const respuesta={ok:true,caso_id:c.caso_id,version:c.version,revision_id:clave,estado_revision:'pendiente_rh',duplicado:!!previo,advertencia:'Solicitud simulada de revisión. No cambia el plan ni su aprobación; requiere atención humana.'};
  if(previo)return {http_status:200,escritura:false,respuesta};
  return {http_status:200,escritura:true,respuesta,fila:{clave,tipo:'revision',estado:'pendiente_rh',payload:JSON.stringify({revision_id:clave,caso_id:c.caso_id,version_caso:c.version,canal:'voz',modo:'SIMULADO',solicitada_en:ahora.toISOString()})}};
 }catch(e){const conocidos=['ESQUEMA_INVALIDO','PETICION_EXCESIVA','CAMPO_NO_PERMITIDO','ACCION_NO_PERMITIDA','CASO_NO_ACCESIBLE','VERSION_INVALIDA','VERSION_REQUERIDA','REGISTRO_INVALIDO','VERSION_DESACTUALIZADA','ESTADO_NO_REVISABLE'];const error=conocidos.includes(e.message)?e.message:'ERROR_INTERNO';return {http_status:error==='CASO_NO_ACCESIBLE'?404:error==='VERSION_DESACTUALIZADA'?409:400,escritura:false,respuesta:{ok:false,error,accion_realizada:false}};}
}
if(typeof module!=='undefined')module.exports={validarPeticionVoz,procesarVoz};
