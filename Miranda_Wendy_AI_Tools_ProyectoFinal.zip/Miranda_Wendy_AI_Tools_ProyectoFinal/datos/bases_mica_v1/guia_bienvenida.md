# Guía de bienvenida de MICA

Versión 1.0.0 · 2026-11-04 · Información completamente ficticia

## GUI-01 · Quiénes somos

MICA es una empresa ficticia de servicios empresariales de aproximadamente 250 colaboradores. Para esta demostración se modelan Administración, Comercial y Tecnología. Esta cifra contextual no implica que exista un padrón de empleados en las bases.

## GUI-02 · Qué hace el asistente

Prepara propuestas de onboarding con actividades anteriores al ingreso, del primer día y de la primera semana, a partir de fuentes sintéticas autorizadas. Toda propuesta requiere revisión de calidad y aprobación humana antes de su registro definitivo de prueba.

## GUI-03 · Datos necesarios

Puesto y departamento del catálogo, fecha de ingreso, modalidad, tipo nuevo_ingreso y responsable de RH ficticio RH-01. El sistema asigna el folio del caso. No se necesitan nombre, documento de identidad, sueldo, domicilio o información médica.

## GUI-04 · Fechas y responsables

Las fechas usan días naturales. El día 0 es la fecha de ingreso. Las actividades pueden caer en fin de semana: es una convención de demostración, no una instrucción de jornada laboral. Los responsables son roles ficticios. Las actividades no habilitan accesos ni envían comunicaciones reales.

## GUI-05 · Aprobación y consultas

La aprobación corresponde a People & Culture mediante el canal autorizado configurado en el servidor. La voz nunca aprueba planes. Ante información insuficiente se solicita aclaración. Para consultar el estado es obligatorio recuperar el registro real del entorno de prueba; esta guía no contiene folios existentes ni estados actuales.

## GUI-06 · Límites de la voz

El agente debe identificarse como IA y solicitar consentimiento antes de la interacción de voz. Solo manejará información ficticia no sensible. Si no logra consultar la herramienta, debe reconocerlo y ofrecer la alternativa de Telegram; no afirmar que un caso se creó o aprobó sin confirmación del registro.
