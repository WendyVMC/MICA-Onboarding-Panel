# Bases sintéticas MICA · v1.0.0

## Qué incluye

- `catalogos.json`: tres departamentos, seis puestos y modalidades.
- `responsables.json`: ocho responsables ficticios, sin datos de contacto.
- `politicas.json` y `politicas_onboarding.md`: trece políticas equivalentes.
- `actividades.json` y `checklist_actividades.md`: dieciséis actividades filtrables por puesto, departamento y modalidad.
- `guia_bienvenida.md`: conocimiento de bienvenida y límites de la voz.
- `diccionario_datos.md`: campos, relaciones y reglas de selección.
- `casos_prueba.json`: diez entradas con expectativas, incluidas entradas inválidas deliberadas.
- `validacion_local.json`: resultado de controles de integridad; no evidencia de integración.
- `ejemplos_esperados.json`: planes calculados por reglas para contrastar futuras salidas de agentes; no planes aprobados.

## Qué revisar ahora

1. Leer `politicas_onboarding.md` y `checklist_actividades.md`.
2. Comprobar que los puestos, responsables y actividades son adecuados para el ejercicio.
3. Revisar los tres casos válidos y sus resultados esperados.
4. Confirmar o solicitar cambios antes de cargar archivos en plataformas.

## Uso previsto después de la revisión

Los JSON serán fuentes estructuradas del flujo n8n; los Markdown servirán como documentos de consulta. La forma exacta de carga se verificará en cada plataforma. No cargar el ZIP directamente ni todos los archivos a cada herramienta. No cargar casos de prueba, resultados esperados ni reportes como conocimiento del agente de voz. Para voz se usará únicamente el contenido público permitido, una vez revisada su configuración.

No hay modelo entrenado, agentes ejecutados ni servicios conectados en este paquete. No se requieren credenciales para abrirlo. Mantener la versión 1.0.0 en las referencias de las futuras trazas.
