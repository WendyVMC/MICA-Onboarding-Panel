# Diccionario y uso de las bases de MICA

Versión 1.0.0 · 2026-11-04 · Datos sintéticos creados para el proyecto académico.

## Relaciones y selección

`catalogos.puestos.departamento_id` → departamento existente. `actividades.regla_id` → políticas. `actividades.responsable_id` → responsables activos. Un responsable departamental solo puede actuar en su propio departamento; TRANSVERSAL puede actuar en cualquiera.

Para una solicitud válida seleccionar TODAS las actividades donde departamento_id sea null o coincida, puesto_id sea null o coincida y modalidades contenga la modalidad solicitada. Cada actividad aplicable aparece una sola vez. La selección es una operación de filtrado, no una búsqueda aproximada del modelo.

## Solicitud de negocio (objeto cerrado)

| Campo | Tipo | Validación |
|---|---|---|
| departamento_id | texto | Existe en catalogos.departamentos |
| puesto_id | texto | Existe y corresponde al departamento |
| fecha_ingreso | texto AAAA-MM-DD | Fecha real del calendario; no aceptar fechas imposibles |
| modalidad | texto | presencial, hibrida o remota |
| tipo_incorporacion | texto | nuevo_ingreso |
| responsable_rh_id | texto | RH-01 activo y rol de People & Culture |

Los seis campos son obligatorios y no aceptan null, vacío ni tipos distintos. Campos desconocidos se rechazan. El canal puede transformar nombres visibles a identificadores usando el catálogo, pero no inventarlos. El servidor añade caso_id, canal, modo, identidad autorizada y límites; no son parámetros que el usuario pueda imponer. El catálogo de responsables no es una lista de usuarios autenticados.

## Campos de actividades

| Campo | Tipo y significado |
|---|---|
| actividad_id | Texto único; conservar en planes y trazas |
| titulo | Texto descriptivo de la tarea ficticia |
| regla_id | Referencia existente a política |
| fuente_version | Versión exacta de la fuente |
| departamento_id | ID o null (todos) |
| puesto_id | ID o null (todos los puestos del ámbito) |
| modalidades | Lista no vacía de valores del catálogo |
| fase | preingreso (días negativos), primer_dia (0), primera_semana (1 a 6) |
| desfase_dias | Entero de -3 a 6; fecha resultante = fecha_ingreso + desfase_dias |
| responsable_id | Referencia a responsable activo |
| obligatoria | Booleano true: obligatoria cuando aplica |
| evidencia_esperada | Descripción de evidencia futura; no significa tarea realizada |

## Metadatos

Los JSON de registros incluyen empresa, version, naturaleza, fecha_version, tipo y registros. `catalogos.json` usa listas nombradas. Null se interpreta como alcance universal solamente en los campos de aplicabilidad indicados. Todos los documentos de conocimiento son sintéticos. Los casos adversariales no son políticas ni deben cargarse como conocimiento.

## Privacidad, límites y procedencia

No hay empleados reales ni datos descargados de internet. Los roles, políticas y actividades fueron creados para MICA en este proyecto; no representan obligaciones legales. El código generador y la versión permiten reproducir el conjunto. No hay licencias de datasets externos que atribuir. El permiso de publicación del proyecto sigue pendiente.

Las fechas de los ejemplos son fijas para reproducibilidad; no se ha definido una regla de rechazo por fecha pasada ni ventana mínima de anticipación. Regla POL-13 aprobada: comparar contra la fecha local de recepción en America/Mexico_City; conservar fechas vencidas y advertir. RH debe resolverlas antes del registro definitivo; no se reprograman automáticamente.

Estos datos no incluyen casos operativos completados, tiempos de proceso, aprobaciones, consumos ni KPI medidos. No sirven para afirmar ahorro ni para entrenar predicciones de desempeño de personas.
