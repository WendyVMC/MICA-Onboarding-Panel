# Checklist de actividades de MICA

Versión 1.0.0 · FUENTE SINTÉTICA · Equivalente a `actividades.json`.

Filtrar por departamento y puesto: `TODOS` significa universal. Incluir solo modalidades aplicables. Todas las filas aplicables son obligatorias; no se ejecutan acciones reales.

| ID | Actividad | Departamento | Puesto | Modalidad | Día | Responsable | Regla |
|---|---|---|---|---|---:|---|---|
| ACT-G01 | Revisar datos de la solicitud ficticia | TODOS | TODOS | presencial, hibrida, remota | -3 | RH-01 | POL-04 |
| ACT-G02 | Preparar agenda de bienvenida simulada | TODOS | TODOS | presencial, hibrida, remota | -1 | RH-01 | POL-04 |
| ACT-G03 | Presentar MICA y sus canales de apoyo ficticios | TODOS | TODOS | presencial, hibrida, remota | 0 | RH-01 | POL-04 |
| ACT-G04 | Realizar orientación sobre manejo de datos sintéticos | TODOS | TODOS | presencial, hibrida, remota | 0 | TI-01 | POL-04 |
| ACT-G05 | Revisar avance de incorporación de primera semana | TODOS | TODOS | presencial, hibrida, remota | 6 | RH-01 | POL-04 |
| ACT-G06 | Comprobar entorno de práctica remota sin asignar accesos reales | TODOS | TODOS | remota, hibrida | -1 | TI-01 | POL-04 |
| ACT-G07 | Compartir orientación de sede ficticia sin coordinar visitas reales | TODOS | TODOS | presencial, hibrida | -1 | RH-01 | POL-04 |
| ACT-ADM-01 | Revisar flujo administrativo con documentos ficticios | DEP-ADM | TODOS | presencial, hibrida, remota | 1 | LID-ADM | POL-05 |
| ACT-P-ADM-01 | Clasificar una muestra de documentos administrativos ficticios | DEP-ADM | P-ADM-01 | presencial, hibrida, remota | 3 | MEN-ADM | POL-05 |
| ACT-P-ADM-02 | Revisar un reporte administrativo de práctica | DEP-ADM | P-ADM-02 | presencial, hibrida, remota | 3 | MEN-ADM | POL-05 |
| ACT-COM-01 | Revisar proceso comercial y catálogo de servicios ficticios | DEP-COM | TODOS | presencial, hibrida, remota | 1 | LID-COM | POL-05 |
| ACT-P-COM-01 | Preparar una propuesta comercial ficticia sin enviarla | DEP-COM | P-COM-01 | presencial, hibrida, remota | 3 | MEN-COM | POL-05 |
| ACT-P-COM-02 | Interpretar un reporte de oportunidades sintéticas | DEP-COM | P-COM-02 | presencial, hibrida, remota | 3 | MEN-COM | POL-05 |
| ACT-TEC-01 | Revisar entorno técnico de demostración y sus límites | DEP-TEC | TODOS | presencial, hibrida, remota | 1 | LID-TEC | POL-05 |
| ACT-P-TEC-01 | Revisar un caso de sistema en entorno de demostración | DEP-TEC | P-TEC-01 | presencial, hibrida, remota | 3 | MEN-TEC | POL-05 |
| ACT-P-TEC-02 | Resolver un ticket ficticio sin modificar equipos reales | DEP-TEC | P-TEC-02 | presencial, hibrida, remota | 3 | MEN-TEC | POL-05 |
