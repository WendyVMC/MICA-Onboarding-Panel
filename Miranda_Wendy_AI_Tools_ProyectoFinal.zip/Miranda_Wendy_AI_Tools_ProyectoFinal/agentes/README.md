# Cinco roles de MICA · versión 1.0.0

Estado consolidado 26/11/2026: cinco roles ejecutados y trazados en cuatro casos completos (069, 074, 075 y 082). Evidencias en lote003_cierre_casos.json y ensayo004_cierre_casos.json. Orquestador determinista y cuatro especialistas gpt-4o-mini; generación apagada al cierre. Los apartados de selección inicial de nodos describen el diseño histórico, no la configuración vigente.

| Rol | Recibe | Aporta | Herramientas permitidas al implementar |
|---|---|---|---|
| Orquestador | Solicitud autorizada y validación del servidor | Secuencia, presupuesto, estados y cierre | Validación de contratos, registro de eventos y despacho a especialistas |
| A1 Recepción | Campos de negocio | Interpretación estructurada o faltantes | Consulta de catálogos, validador de solicitud |
| A2 Fuentes | Solicitud validada | Actividades y políticas pertinentes con referencias | Lectura filtrada de bases MICA versionadas |
| A3 Planificación | Evidencia de A2 | Propuesta de plan personalizada | Cálculo determinista de fechas y responsables |
| A4 Revisión | Solicitud, fuentes y propuesta | Dictamen con defectos concretos; puede bloquear | Comparación de cobertura, fechas, referencias y reglas |

Implementación prevista: cinco roles distinguibles dentro de n8n. El control de acceso, esquema, costos y fechas es determinista; el modelo no puede desactivarlo. Los especialistas deben invocar herramientas delimitadas y producir resultados propios. Un nodo llamado agente sin instrucciones/herramientas ni aportación verificable no cuenta como integración.

El orquestador puede coordinar mediante reglas sin una llamada LLM adicional: documentar la decisión y su traza. Los cuatro especialistas se ejecutaron en los casos completos registrados. El agente de voz es un sexto rol de interfaz, no sustituye especialistas.

La UI de n8n 2.45.7 mostró OpenAI Chat Model, Gateway credits y gpt-5-mini como selección inicial. Modelo y límites no están aún validados para operación; no ejecutar hasta confirmar tarifas y autorización. Los controles propuestos se encuentran en `limites_propuestos.json`, explícitamente no autorizados.
