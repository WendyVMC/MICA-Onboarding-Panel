# Skills específicos de MICA

Cada carpeta contiene su SKILL.md con reglas ejecutables mica-policy, versión, fuentes, ejemplos, límites y aceptación. Ejecutores: runtime/skills_adapter.js y runtime/loops.js. Fuentes incluidas en datos/bases_mica_v1; no contienen datos personales. No requieren instalación global.

Prueba reproducible sin APIs: `node tests/skills_loops.test.js`. La versión n8n se compila leyendo los archivos MD, embebe su contenido y registra hashes. Ver docs/11_SKILLS_LOOPS_MICA.md para carga, pruebas, autoevaluación y límites de integración.
