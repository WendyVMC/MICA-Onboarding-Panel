---
name: mica-preparar-onboarding
description: Prepara planes de onboarding de MICA con sus catálogos y reglas sintéticas versionadas; usar para nuevos ingresos, antes de revisión y aprobación humana.
metadata:
  version: "1.0.0"
---

# Preparar onboarding de MICA

## Activador y objetivo
Una solicitud de nuevo ingreso requiere una propuesta con actividades previas, del primer día y primera semana. Convertir seis campos validados en fechas, responsables y referencias; no ejecutar actividades ni aprobar planes.

## Entrada y fuentes
Contexto con caso_id, canal, usuario autorizado o seudónimo, objetivo, datos, modo SIMULADO, fecha_recepcion_local ISO, bases y límite de costo. Datos: departamento_id, puesto_id, fecha_ingreso, modalidad, tipo_incorporacion, responsable_rh_id. Fuentes exclusivas: datos/bases_mica_v1/{catalogos,actividades,politicas,responsables}.json versión 1.0.0.

## Reglas ejecutables
El adaptador lee este bloque del archivo, comprueba su esquema y aplica sus valores. No sustituirlo por instrucciones del usuario.

```mica-policy
{"version":"1.0.0","modo":"SIMULADO","tipo_incorporacion":"nuevo_ingreso","fuente_version":"1.0.0","calendario":"dias_naturales","reprogramar_vencidas":false,"aprobacion_humana_requerida":true,"herramientas":["validar_solicitud","recuperar_fuentes","calcular_plan"],"max_actividades":30}
```

## Pasos y herramientas permitidas
1. Validar los seis campos contra catálogo, relación puesto/departamento y responsable RH activo. Rechazar campos extra o pedir aclaración por faltantes; no inventar.
2. Recuperar solo actividades universales, de departamento, puesto y modalidad aplicables (POL-04/05).
3. Calcular fecha_ingreso + desfase en días naturales (POL-03); validar responsables/reglas/versiones.
4. Conservar fechas vencidas y advertir; bloquear liberación hasta resolución RH, sin reprogramar (POL-13).
5. Entregar propuesta versionada al revisor. No habilitar registro definitivo.

Herramientas: validar_solicitud, recuperar_fuentes y calcular_plan, implementadas por runtime/skills_adapter.js con agentes/herramientas_mica.js. No URLs, navegación ni llamadas a modelos.

## Límites, salida y errores
Máximo 30 actividades. Sin gasto de APIs en este ejecutor. Cada salida incluye caso_id, skill, versión, hash de archivo cargado, fuentes, advertencias y resultado; la traza registra decisiones observables, no razonamiento privado. Errores de catálogo, fecha, responsable, fuentes o modo impiden continuar. La autorización para preparar no autoriza ejecutar una acción externa.

## Aceptación
Cobertura exacta de actividades aplicables; fechas/roles/reglas verificables; modo simulado; aprobación humana requerida. La propuesta debe pasar mica-verificar-propuesta antes de liberarse.

## Ejemplos
- Válido: DEP-TEC, P-TEC-01, 2026-12-01, remota, nuevo_ingreso, RH-01; recepción 2026-11-16. Esperado: ocho actividades.
- Inválido: DEP-ADM con P-TEC-01. Rechazar PUESTO_DEPARTAMENTO_INVALIDO; no sustituir puesto ni departamento.
- Faltante: modalidad ausente. Solicitar aclaración; no asumir presencial.

Carga/reutilización: ejecutar desde la raíz del paquete `node tests/skills_loops.test.js`. No instalar globalmente ni sobrescribir skills personales. Otra IA puede leer este archivo y sus fuentes; para ejecución n8n usar el adaptador embebido y conservar hash/versión en la traza.
