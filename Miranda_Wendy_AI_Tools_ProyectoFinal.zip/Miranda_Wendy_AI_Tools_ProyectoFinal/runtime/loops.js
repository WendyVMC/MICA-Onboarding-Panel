'use strict';
const crypto=require('node:crypto');const {performance}=require('node:perf_hooks');
const {cargarSkill,validarContexto,ejecutarNegocio,ejecutarRevision}=require('./skills_adapter');
const hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
function loopSeguridad(c,pasos,limites={usd:0,llamadas:0,max_iteraciones:3,max_ms:3000}){
 const inicio=performance.now(),traza=[],resultados=[];let usado=0,llamadas=0,reservado=0;
 const fin=(estado,causa)=>({caso_id:c?.caso_id,estado,causa,traza,resultados:estado==='conforme'?resultados:[],consumo:{costo_api_usd:usado,llamadas_modelo:llamadas,reserva_pendiente_usd:reservado,tokenizacion:llamadas?'ver_logs_proveedor':'no_aplica'},duracion_local_ms:performance.now()-inicio});
 try{
  const s=cargarSkill('mica-verificar-propuesta');validarContexto(c,s);
  if(!Number.isFinite(limites.usd)||limites.usd<0||!Number.isSafeInteger(limites.llamadas)||limites.llamadas<0||!Number.isSafeInteger(limites.max_iteraciones)||limites.max_iteraciones<1||limites.max_iteraciones>3||!Number.isFinite(limites.max_ms)||limites.max_ms<=0||limites.max_ms>3000)throw Error('LIMITES_INVALIDOS');
  if(limites.usd>c.limite_costo_usd)throw Error('LIMITE_SUPERA_AUTORIZACION');
  if(!Array.isArray(pasos)||pasos.length===0)throw Error('PASOS_INVALIDOS');
  for(let i=0;i<pasos.length;i++){
   if(i>=limites.max_iteraciones)return fin('seguridad_agotada','MAX_ITERACIONES');
   if(performance.now()-inicio>=limites.max_ms)return fin('tiempo_agotado','MAX_TIEMPO');
   const paso=pasos[i];
   if(!s.politica.acciones_permitidas.includes(paso.accion))return fin('acceso_bloqueado','ACCION_NO_PERMITIDA');
   if(!Number.isFinite(paso.reserva_usd)||paso.reserva_usd<0||!Number.isSafeInteger(paso.llamadas_reservadas)||paso.llamadas_reservadas<0)throw Error('RESERVA_INVALIDA');
   if(usado+paso.reserva_usd>limites.usd||llamadas+paso.llamadas_reservadas>limites.llamadas){traza.push({iteracion:i+1,accion:paso.accion,decision:'bloquear_antes_de_ejecutar',causa:'PRESUPUESTO_AGOTADO',skill_cargado:s.carga});return fin('presupuesto_agotado','PRESUPUESTO_AGOTADO');}
   reservado=paso.reserva_usd;traza.push({iteracion:i+1,accion:paso.accion,decision:'reserva_aceptada',reserva_usd:reservado,llamadas_reservadas:paso.llamadas_reservadas,skill_cargado:s.carga});
   let r;try{r=paso.ejecutar()}catch(e){return fin('error_controlado',e.message)}
   const u=r?.uso;if(!u||!Number.isFinite(u.usd)||u.usd<0||!Number.isSafeInteger(u.llamadas)||u.llamadas<0||u.usd>reservado||u.llamadas>paso.llamadas_reservadas)return fin('consumo_no_conciliado','USO_DESCONOCIDO_O_EXCEDIDO');
   usado+=u.usd;llamadas+=u.llamadas;reservado=0;resultados.push(r.valor);traza.push({iteracion:i+1,accion:paso.accion,decision:'paso_conciliado',consumo_api_usd:u.usd,llamadas_modelo:u.llamadas});
   if(performance.now()-inicio>=limites.max_ms)return fin('tiempo_agotado','MAX_TIEMPO');
  }
  return fin('conforme',null);
 }catch(e){return fin('acceso_bloqueado',e.message)}
}
function loopCalidad(c,{propuesta_inicial,max_iteraciones=3,max_ms=3000,corregir=true}={}){
 const inicio=performance.now(),traza=[],cargas=[];let propuesta=propuesta_inicial;
 if(!Number.isSafeInteger(max_iteraciones)||max_iteraciones<1||max_iteraciones>3||!Number.isFinite(max_ms)||max_ms<=0||max_ms>3000)throw Error('LIMITES_INVALIDOS');
 const negocio=cargarSkill('mica-preparar-onboarding'),revisor=cargarSkill('mica-verificar-propuesta');cargas.push(negocio.carga,revisor.carga);
 for(let i=1;i<=max_iteraciones;i++){
  if(performance.now()-inicio>=max_ms)return {caso_id:c.caso_id,estado:'tiempo_agotado',traza,cargas};
  let generada;const pasos=[];if(propuesta===undefined)pasos.push({accion:i===1?'preparar_plan':'corregir_plan',reserva_usd:0,llamadas_reservadas:0,ejecutar:()=>{generada=ejecutarNegocio(c,negocio);return {valor:generada,uso:{usd:0,llamadas:0}}}});
  pasos.push({accion:'verificar_plan',reserva_usd:0,llamadas_reservadas:0,ejecutar:()=>({valor:ejecutarRevision(c,propuesta===undefined?generada.resultado:propuesta,revisor),uso:{usd:0,llamadas:0}})});
  const seguridad=loopSeguridad(c,pasos,{usd:0,llamadas:0,max_iteraciones:3,max_ms});
  if(seguridad.estado!=='conforme')return {caso_id:c.caso_id,estado:seguridad.estado,causa:seguridad.causa,traza,cargas,seguridad};
  if(propuesta===undefined)propuesta=seguridad.resultados[0].resultado;
  const revision=seguridad.resultados.at(-1);
  traza.push({caso_id:c.caso_id,iteracion:i,version:'V'+i,propuesta:JSON.parse(JSON.stringify(propuesta)),hash_propuesta:hash(propuesta),revision,seguridad:{estado:seguridad.estado,traza:seguridad.traza,consumo:seguridad.consumo},diagnostico:revision.defectos,accion_retorno:revision.liberable_para_aprobacion?'solicitar_aprobacion_humana':revision.defectos.includes('FECHAS_REQUIEREN_REVISION_RH')?'derivar_rh_sin_reprogramar':corregir?'recalcular_desde_fuentes':'sin_correccion_habilitada'});
  if(revision.liberable_para_aprobacion)return {caso_id:c.caso_id,estado:'pendiente_aprobacion',propuesta,revision,traza,cargas,consumo:{tokens:'no_aplica',costo_api_usd:0,llamadas_modelo:0},duracion_local_ms:performance.now()-inicio};
  if(revision.defectos.includes('FECHAS_REQUIEREN_REVISION_RH'))return {caso_id:c.caso_id,estado:'requiere_revision_rh',traza,cargas};
  if(corregir)propuesta=undefined;
 }
 return {caso_id:c.caso_id,estado:'calidad_agotada',causa:'MAX_ITERACIONES',traza,cargas};
}
module.exports={loopCalidad,loopSeguridad};
