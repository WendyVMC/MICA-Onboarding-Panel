'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const H=require('../agentes/herramientas_mica');
const ROOT=path.resolve(__dirname,'..');
const NOMBRES=['mica-preparar-onboarding','mica-verificar-propuesta'];
function cargarSkill(nombre){
 if(!NOMBRES.includes(nombre))throw Error('SKILL_NO_PERMITIDO');
 const archivo='skills/'+nombre+'/SKILL.md',texto=fs.readFileSync(path.join(ROOT,archivo),'utf8');
 const bloque=texto.match(/```mica-policy\s*\n([\s\S]*?)\n```/);if(!bloque)throw Error('SKILL_SIN_POLITICA');
 const politica=JSON.parse(bloque[1]);if(politica.version!=='1.0.0'||politica.modo!=='SIMULADO'||politica.fuente_version!=='1.0.0'||politica.aprobacion_humana_requerida!==true)throw Error('POLITICA_SKILL_INVALIDA');
 return {nombre,texto,politica,carga:{skill:nombre,version:politica.version,archivo,sha256:crypto.createHash('sha256').update(texto).digest('hex'),mecanismo:'lectura_SKILL_md_y_bloque_mica_policy'}};
}
function validarContexto(c,skill){
 if(!c||typeof c!=='object'||Array.isArray(c))throw Error('CONTEXTO_INVALIDO');
 if(!/^MICA-[A-Za-z0-9-]{1,80}$/.test(c.caso_id||''))throw Error('CASO_INVALIDO');
 if(c.modo!==skill.politica.modo)throw Error('MODO_INVALIDO');
 if(c.usuario_autorizado!==true)throw Error('USUARIO_NO_AUTORIZADO');
 if(typeof c.canal!=='string'||!c.canal.trim()||typeof c.usuario_seudonimo!=='string'||!c.usuario_seudonimo.trim())throw Error('METADATOS_INVALIDOS');
 if(!Number.isFinite(c.limite_costo_usd)||c.limite_costo_usd<0)throw Error('PRESUPUESTO_INVALIDO');
 if(typeof c.objetivo!=='string'||!c.objetivo.trim()||c.objetivo.length>1500)throw Error('OBJETIVO_INVALIDO');
 if(!/^\d{4}-\d{2}-\d{2}$/.test(c.fecha_recepcion_local||''))throw Error('RECEPCION_INVALIDA');
 for(const k of ['catalogos','actividades','politicas','responsables'])if(c.bases?.[k]?.version!==skill.politica.fuente_version)throw Error('VERSION_FUENTE_INVALIDA');
 H.validarSolicitud(c.datos,c.bases);
}
function ejecutarNegocio(c,skill=cargarSkill('mica-preparar-onboarding')){
 validarContexto(c,skill);const p=skill.politica;
 if(c.datos.tipo_incorporacion!==p.tipo_incorporacion||p.calendario!=='dias_naturales'||p.reprogramar_vencidas!==false)throw Error('REGLA_NEGOCIO_NO_ADMITIDA');
 if(!['validar_solicitud','recuperar_fuentes','calcular_plan'].every(x=>p.herramientas.includes(x)))throw Error('HERRAMIENTA_SKILL_NO_PERMITIDA');
 const resultado=H.calcularPlan(c);if(resultado.actividades.length>p.max_actividades)throw Error('LIMITE_ACTIVIDADES');
 return {caso_id:c.caso_id,resultado,fuentes:{version:p.fuente_version},advertencias:resultado.requiere_revision_fechas?['SOLICITUD_TARDIA_REQUIERE_RH']:[],skill_cargado:skill.carga,consumo:{tokens:'no_aplica',llamadas_modelo:0,costo_api_usd:0}};
}
function ejecutarRevision(c,propuesta,skill=cargarSkill('mica-verificar-propuesta')){
 validarContexto(c,skill);const p=skill.politica;if(p.exigir_cobertura_exacta!==true||p.bloquear_fechas_vencidas!==true||!['comparar_plan','validar_fuentes'].every(x=>p.herramientas.includes(x)))throw Error('REGLA_CALIDAD_NO_ADMITIDA');
 const esperado=H.calcularPlan(c),defectos=[];
 if(!H.equivalente(propuesta,esperado))defectos.push('PLAN_NO_CONFORME');
 if(esperado.requiere_revision_fechas)defectos.push('FECHAS_REQUIEREN_REVISION_RH');
 return {caso_id:c.caso_id,dictamen:defectos.length?'devolver_correcciones':'conforme',defectos,liberable_para_aprobacion:defectos.length===0,aprobacion_humana_requerida:true,registro_definitivo_permitido:false,skill_cargado:skill.carga};
}
module.exports={cargarSkill,validarContexto,ejecutarNegocio,ejecutarRevision};
