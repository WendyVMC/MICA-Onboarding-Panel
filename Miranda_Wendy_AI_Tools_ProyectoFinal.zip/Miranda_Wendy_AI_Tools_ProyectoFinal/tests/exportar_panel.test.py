"""Prueba con registros sintéticos: no consulta tablas ni lee credenciales."""
import json,subprocess,tempfile
from pathlib import Path
root=Path(__file__).resolve().parents[1];d=json.loads((root/'panel/datos.json').read_text());c=d['casos'][0]
r={'caso_id':c['caso_id'],'datos':c['solicitud'],'modo':'SIMULADO','estado':c['estado'],'version':c['version'],'fecha_recepcion_local':c['fecha_recepcion_local'],'recibido_en':None,'plan':{'actividades':c['actividades']},'usuario_id':'NO_PUBLICAR','chat_id':'NO_PUBLICAR','aprobacion':{'usuario_id':'NO_PUBLICAR'}}
with tempfile.TemporaryDirectory() as td:
 src=Path(td)/'privado_prueba.json';dst=Path(td)/'publico.json';src.write_text(json.dumps([{'tipo':'caso','payload':json.dumps(r)}]));subprocess.run(['python3',str(root/'tools/exportar_panel.py'),str(src),'--salida',str(dst),'--corte','2026-11-16','--periodo','2026-11','--incluir-casos',c['caso_id']],cwd=root,check=True);s=dst.read_text();assert 'NO_PUBLICAR' not in s;out=json.loads(s);assert out['casos'][0]['metricas']['primera_revision_humana_en'] is None;print('Exportador: privacidad por lista blanca y ausencias explícitas verificadas.')
