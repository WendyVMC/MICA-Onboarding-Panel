'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs');
const {comprobarMicrofono,habilitarVoz}=require('../panel/app');
const ui=(acepta=true)=>({consent:{checked:acepta},enable:{disabled:false,hidden:false},status:{textContent:''},revoke:{hidden:true}});
(async()=>{
 const r=[];let llamadasWidget=0,capturas=0,detenidas=0;
 const media={getUserMedia:async()=>{capturas++;return {getTracks:()=>[{stop:()=>detenidas++}]}}};
 const cargar=async()=>{llamadasWidget++;};
 assert.equal(await habilitarVoz(ui(false),media,cargar),'sin_consentimiento');assert.equal(capturas,0);assert.equal(llamadasWidget,0);r.push('Sin consentimiento no solicita micrófono ni carga servicio');
 const deny={getUserMedia:async()=>{const e=Error('PRIVADO_NO_REVELAR');e.name='NotAllowedError';throw e;}};
 const denied=ui();assert.equal(await habilitarVoz(denied,deny,cargar),'MICROFONO_DENEGADO');assert.equal(llamadasWidget,0);assert(denied.status.textContent.includes('Telegram'));assert(!denied.status.textContent.includes('PRIVADO'));r.push('Denegación NotAllowedError simulada: alternativa visible, sin servicio ni datos privados');
 assert.equal((await comprobarMicrofono(undefined)).codigo,'NO_COMPATIBLE');r.push('Navegador sin mediaDevices: derivación textual');
 assert.equal(await habilitarVoz(ui(),media,cargar),'widget_listo');assert.equal(detenidas,1);assert.equal(llamadasWidget,1);r.push('Permiso concedido simulado: detiene captura antes de cargar widget');
 const fallo=ui();assert.equal(await habilitarVoz(fallo,media,async()=>{throw Error('API caída simulada');}),'SERVICIO_NO_DISPONIBLE');assert(fallo.status.textContent.includes('Telegram'));r.push('Caída/timeout simulado del cargador: mensaje y Telegram, sin reintentos');
 const out={fecha:'2026-11-21',tipo:'simulacion_controlada_sin_APIs_ni_audio',resultado:'aprobado',pruebas:r,limite:'No es un rechazo real de permisos del navegador ni una caída real de ElevenLabs; verifica el manejador utilizado por el panel publicado.'};fs.writeFileSync('evidencias/voz_fallos_simulados.json',JSON.stringify(out,null,2)+'\n');console.log(JSON.stringify(out));
})().catch(e=>{console.error(e);process.exitCode=1;});
