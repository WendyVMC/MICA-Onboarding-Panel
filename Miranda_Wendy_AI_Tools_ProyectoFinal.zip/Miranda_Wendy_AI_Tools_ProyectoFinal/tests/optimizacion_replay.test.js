'use strict';
const fs=require('fs'),assert=require('node:assert/strict'),H=require('../agentes/herramientas_mica');
const d=JSON.parse(fs.readFileSync('panel/datos.json')),ledger=JSON.parse(fs.readFileSync('costos/llamadas.json'));
const bases=Object.fromEntries(['catalogos','actividades','politicas','responsables'].map(k=>[k,JSON.parse(fs.readFileSync('datos/bases_mica_v1/'+k+'.json'))]));
const pruebas=[];
for(const c of d.casos){
 const result=H.calcularPlan({datos:c.solicitud,bases,fecha_recepcion_local:c.fecha_recepcion_local});
 const original=c.actividades.map(({titulo,...a})=>a);
 assert.deepEqual(result.actividades,original);assert.equal(result.requiere_revision_fechas,false);
 const broken=result.actividades.filter(x=>x.actividad_id!=='ACT-G04');assert.equal(H.equivalente(broken,original),false);
 const calls=ledger.llamadas.filter(x=>x.caso_id===c.caso_id&&x.agente==='A3');assert.equal(calls.length,2);
 pruebas.push({caso_id:c.caso_id,actividades:original.length,calidad_base_canonica:true,calidad_replay_canonica:true,omision_detectada:true,llamadas_A3_historicas:2,costo_A3_historico_usd:calls.reduce((s,x)=>s+x.costo_usd_calculado,0),llamadas_API_replay:0,costo_API_adicional_replay:0});
}
const out={fecha:'2026-11-26',tipo:'comparacion_offline_con_planes_y_costos_historicos_medidos',resultado:'aprobado',casos:pruebas,calidad_base:pruebas.length+'/'+pruebas.length,calidad_replay:pruebas.length+'/'+pruebas.length,costo_A3_base_calculado_usd:pruebas.reduce((s,x)=>s+x.costo_A3_historico_usd,0),costo_API_adicional_replay_usd:0,alcance:'Recalcular fechas y cobertura mediante regla determinista conserva los planes canónicos y detecta la omisión ACT-G04. No se cambió ni ejecutó una variante del flujo Cloud. No mide ahorro facturado ni sustituye aportación del especialista A3; el modelo y su herramienta siguen en el diseño integrado. CPU local consumida, costo monetario no medido.'};
fs.writeFileSync('evidencias/optimizacion_replay.json',JSON.stringify(out,null,2)+'\n');console.log(JSON.stringify({resultado:out.resultado,casos:pruebas.length,calidad:out.calidad_replay,costo_base:out.costo_A3_base_calculado_usd,API_adicional:0}));
